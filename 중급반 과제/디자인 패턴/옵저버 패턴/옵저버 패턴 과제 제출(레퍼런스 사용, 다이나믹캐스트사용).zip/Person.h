#include"Observer.h"

class Person : public Observer
{
private:
	std::string m_Name;
	NewsInfomation m_CurNews;
public:
	Person();
	~Person();
	virtual void Update(const NewsInfomation& _news) override;
	virtual void Print() override;
	void Sign_Up();
};