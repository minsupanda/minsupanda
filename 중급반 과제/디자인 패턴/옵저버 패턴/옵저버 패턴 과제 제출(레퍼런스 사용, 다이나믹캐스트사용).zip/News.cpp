#include "News.h"

News* News::m_This = NULL;

News::News()
{
}

News::~News()
{
	Distroy();
	if (m_Observer.size() > 0)
	{
		for (auto iter = m_Observer.begin(); iter != m_Observer.end(); iter++)
			delete& (*iter);
	}
}

void News::Add_Obserber(Observer* _observer) // ������ ���Ϳ� personŬ���� ������ ���� �ϳ�?
{
	m_Observer.push_back(_observer);
}

void News::Update_Obserber()
{
	for (auto observer : m_Observer)
	{
		observer->Update(m_News);
	}
}

void News::News_Update()
{
	std::cout << "���ο� ��� ������ �Է��Ͻÿ�" << std::endl;
	std::cin >> m_News.m_NewsInfo;
	m_News.CreateDate = currentDateTime();
}

std::string News::currentDateTime()
{
	time_t now = time(0);
	struct tm tstruct;
	tstruct = *localtime(&now);
	char buf[80];
	strftime(buf, sizeof(buf), "%Y-%m-%d", &tstruct);
	return buf;
}

void News::ObserverInfo_Print()
{
	for (std::vector<Observer*>::iterator iter = m_Observer.begin(); iter != m_Observer.end(); iter++)
	{
		(*iter)->Print();
	}
}

void News::Distroy()
{
	if (m_This)
	{
		delete m_This;
		m_This = NULL;
	}
}
