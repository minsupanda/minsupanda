#pragma once
#include<iostream>
#include<string>
#include<conio.h>
#include<Windows.h>
#include<time.h>

#define WIDTH 30
#define HEIGHT 30
#define ESC 27

struct NewsInfomation
{
	std::string m_NewsInfo;
	std::string CreateDate;
};