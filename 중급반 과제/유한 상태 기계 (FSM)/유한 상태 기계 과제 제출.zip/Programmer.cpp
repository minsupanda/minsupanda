#include "Programmer.h"
#include "ProgrammerOwnedStates.h"
#include <cassert>

Programmer::Programmer(const int& id) :
	BaseGameEntity(id),
	m_Location(Location_Type::home),
	m_iCurProjectLevel(0),
	m_iFeeling_of_satiety(FILLING_LEVEL / 2 + 1),
	m_iFatigue(0), 
	m_bCodingError(false), // �ڵ� ����
	m_GetJob(false),
	m_pCurState(GoHomeAndRestAndGetJob::Instance()) { }

void Programmer::Update()
{
	if (m_pCurState)
	{
		m_pCurState->Excute(this);
	}
}

void Programmer::ChangeState(State* pState)
{
	assert(m_pCurState && pState);

	m_pCurState->Exit(this); 
	m_pCurState = pState;
	m_pCurState->Enter(this);
}


bool Programmer::HungryCheck() const
{
	if (HUNGRY_LEVEL > m_iFeeling_of_satiety)
		return true;
	else if (FILLING_LEVEL <= m_iFeeling_of_satiety)
		return false;
	else
	{
		if (rand() % m_iFeeling_of_satiety == HUNGRY_LEVEL)
			return true;
		else return false;
	}
}

bool Programmer::Fatigue_Thershold() const
{
	if (TIREDNESS_THRESHOLD < m_iFatigue)
	{
		return true;
	}
	return false;
}

bool Programmer::Leave_Fatigued() const
{
	if (TIREDNESS_THRESHOLD < m_iFatigue)
	{
		return true;
	}

	return false;
}

bool Programmer::Sleep_Fatigued() const
{
	if (SLEEP_TIREDNESS < m_iFatigue)
	{
		return true;
	}

	return false;
}

bool Programmer::FillingCheck() const
{
	if (FILLING_LEVEL <= m_iFeeling_of_satiety)
	{
		return true;
	}
	return false;
}