﻿#include <iostream>
#include "Miner.h"
#include "Programmer.h"
#include "ConsoleUtils.h"
#include "EntityNames.h"
#include"time.h"

int main()
{
	srand(time(NULL));
	Programmer programmer(ent_Elsa);

	for (int i = 0; 20 > i; i++)
	{
		programmer.Update();

		Sleep(1000);
	}
}