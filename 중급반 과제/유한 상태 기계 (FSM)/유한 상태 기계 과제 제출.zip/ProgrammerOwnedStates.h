#pragma once
#include<iostream>
#include"Programmer.h"

class Coding : public State
{
private:
	static Coding* m_hThis;
	Coding() {}
	Coding(const Coding&);
	Coding& operator=(const Coding&);

public:
	static Coding* Instance()
	{
		if (m_hThis == NULL)
			m_hThis = new Coding;
		return m_hThis;
	}

	virtual void Enter(Programmer*);
	virtual void Excute(Programmer*);
	virtual void Exit(Programmer*);
};

class ErrorCorrection : public State
{
private:
	static ErrorCorrection* m_hThis;
	ErrorCorrection() {}
	ErrorCorrection(const ErrorCorrection&);
	ErrorCorrection& operator=(const ErrorCorrection&);

public:
	static ErrorCorrection* Instance()
	{
		if (m_hThis == NULL)
			m_hThis = new ErrorCorrection;
		return m_hThis;
	}

	virtual void Enter(Programmer*);
	virtual void Excute(Programmer*);
	virtual void Exit(Programmer*);
};

class VisitCafeteria : public State
{
private:
	static VisitCafeteria* m_hThis;
	VisitCafeteria() {}
	VisitCafeteria(const VisitCafeteria&);
	VisitCafeteria& operator=(const VisitCafeteria&);

public:
	static VisitCafeteria* Instance()
	{
		if (m_hThis == NULL)
			m_hThis = new VisitCafeteria;
		return m_hThis;
	}

	virtual void Enter(Programmer*);
	virtual void Excute(Programmer*);
	virtual void Exit(Programmer*);
};

class GoHomeAndRestAndGetJob : public State
{
private:
	static GoHomeAndRestAndGetJob* m_hThis;
	GoHomeAndRestAndGetJob() {}
	GoHomeAndRestAndGetJob(const GoHomeAndRestAndGetJob&);
	GoHomeAndRestAndGetJob& operator=(const GoHomeAndRestAndGetJob&);

public:
	static GoHomeAndRestAndGetJob* Instance()
	{
		if (m_hThis == NULL)
			m_hThis = new GoHomeAndRestAndGetJob;
		return m_hThis;
	}

	virtual void Enter(Programmer*);
	virtual void Excute(Programmer*);
	virtual void Exit(Programmer*);
};

class DozeOff : public State
{
private:
	static DozeOff* m_hThis;
	DozeOff() {}
	DozeOff(const DozeOff&);
	DozeOff& operator=(const DozeOff&);

public:
	static DozeOff* Instance()
	{
		if (m_hThis == NULL)
			m_hThis = new DozeOff;
		return m_hThis;
	}

	virtual void Enter(Programmer*);
	virtual void Excute(Programmer*);
	virtual void Exit(Programmer*);
};

class Get_a_Job : public State
{
private:
	static Get_a_Job* m_hThis;
	Get_a_Job() {}
	Get_a_Job(const Get_a_Job&);
	Get_a_Job& operator=(const Get_a_Job&);

public:
	static Get_a_Job* Instance()
	{
		if (m_hThis == NULL)
			m_hThis = new Get_a_Job;
		return m_hThis;
	}

	virtual void Enter(Programmer*);
	virtual void Excute(Programmer*);
	virtual void Exit(Programmer*);
};