#include "Ui.h"
#include <string>

Ui::Ui()
{
}

Ui::~Ui()
{
}

void Ui::Init()
{
	m_UiImage[GameName] = BitmapMgr->Get_Image(IMAGE_TITLE_NAME);
	m_UiImage[Select] = BitmapMgr->Get_Image(IMAGE_MENU_SELECT);
	m_UiImage[Player1A] = BitmapMgr->Get_Image(IMAGE_MENU_PLAYER_A1);
	m_UiImage[Player1B] = BitmapMgr->Get_Image(IMAGE_MENU_PLAYER_A2);
	m_UiImage[Player2A] = BitmapMgr->Get_Image(IMAGE_MENU_PLAYER_B1);
	m_UiImage[Player2B] = BitmapMgr->Get_Image(IMAGE_MENU_PLAYER_B2);
	m_UiImage[Cursor] = BitmapMgr->Get_Image(IMAGE_POINT);
	m_UiImage[InterfaceBar] = BitmapMgr->Get_Image(IMAGE_INTERFACE_BAR);
	m_UiImage[LifeImage] = BitmapMgr->Get_Image(IMAGE_INTERFACE_LIFE);

	m_UiSize[GameName_Size] = m_UiImage[GameName]->Get_Size();
	m_UiSize[Select_Size] = m_UiImage[Select]->Get_Size();
	m_UiSize[Players_Size] = m_UiImage[Player1A]->Get_Size();
	m_UiSize[Cursor_Size] = m_UiImage[Cursor]->Get_Size();
	m_UiSize[InterfaceBar_Size] = m_UiImage[InterfaceBar]->Get_Size();
	m_UiSize[LifeImage_Size] = m_UiImage[LifeImage]->Get_Size();

	m_StarImage[BlueStar] = BitmapMgr->Get_Image(IMAGE_TITLE_STAR1);
	m_StarImage[RedStar] = BitmapMgr->Get_Image(IMAGE_TITLE_STAR2);
	m_StarImage[YellowStar] = BitmapMgr->Get_Image(IMAGE_TITLE_STAR3);
	m_StarSize = m_StarImage[BlueStar]->Get_Size();
	m_StarChangeTime = 0.0f;

	CursorPosition = 0.6f;
}

void Ui::Update(const float& deltaTime)
{
	m_StarChangeTime += deltaTime;
	if (m_StarChangeTime >= StarImage_ChageTime * 0.001f)
	{
		m_StarChangeTime -= StarImage_ChageTime * 0.001f;

		Bitmap* TmpImage = m_StarImage[0];
		m_StarImage[0] = m_StarImage[1];
		m_StarImage[1] = m_StarImage[2];
		m_StarImage[2] = TmpImage;
	}
}

void Ui::SetCursorPosition(int Key)
{
	switch (Key)
	{
	case VK_UP:
		CursorPosition -= 0.05f;
		if (CursorPosition < 0.6f)
			CursorPosition = 0.6f;
		break;
	
	case VK_DOWN:
		CursorPosition += 0.05f;
		if (CursorPosition > 0.75f)
			CursorPosition = 0.75f;
		break;
	}
}

void Ui::Lobby_Draw(HDC backDC)
{
	m_UiImage[GameName]->TransparentDraw(backDC, WIDTH * 0.36f, HEIGHT * 0.2f, m_UiSize[GameName_Size]->cx, m_UiSize[GameName_Size]->cy);

	int i = 0;

	for (int y = 0; y <= Star_Height_Nuber; y++)
	{
		for (int x = 0; x <= Star_Width_Number; x++)
		{
			if (y == 0 && (x > 0 && x < Star_Width_Number))
				m_StarImage[i]->TransparentDraw(backDC, WIDTH * 0.35f + (m_StarSize->cx * x), HEIGHT * 0.15f, m_StarSize->cx, m_StarSize->cy);
			else if (y == Star_Height_Nuber && (x > 0 && x < Star_Width_Number))
				m_StarImage[i]->TransparentDraw(backDC, WIDTH * 0.35f + (m_StarSize->cx * x), HEIGHT * 0.15f + (m_StarSize->cy * (y + 2)), m_StarSize->cx, m_StarSize->cy);
			else if (x == 0 && (y > 0 || y < Star_Height_Nuber))
				m_StarImage[i]->TransparentDraw(backDC, WIDTH * 0.35f, HEIGHT * 0.15f + (m_StarSize->cy * y) + m_StarSize->cy, m_StarSize->cx, m_StarSize->cy);
			else if (x == Star_Width_Number && (y > 0 || y < Star_Height_Nuber))
				m_StarImage[i]->TransparentDraw(backDC, WIDTH * 0.35f + (m_StarSize->cx * Star_Width_Number), HEIGHT * 0.15f + (m_StarSize->cy * y) + m_StarSize->cy, m_StarSize->cx, m_StarSize->cy);

			++i;
			if (i > 2) i = 0;
		}
	}

	m_UiImage[Select]->TransparentDraw(backDC, WIDTH * 0.3f, HEIGHT * 0.45f, m_UiSize[Select_Size]->cx, m_UiSize[Select_Size]->cy);

	m_UiImage[Player1A]->TransparentDraw(backDC, WIDTH * 0.35f, HEIGHT * 0.6f, m_UiSize[Players_Size]->cx, m_UiSize[Players_Size]->cy);
	m_UiImage[Player1B]->TransparentDraw(backDC, WIDTH * 0.35f, HEIGHT * 0.65f, m_UiSize[Players_Size]->cx, m_UiSize[Players_Size]->cy);
	m_UiImage[Player2A]->TransparentDraw(backDC, WIDTH * 0.35f, HEIGHT * 0.7f, m_UiSize[Players_Size]->cx, m_UiSize[Players_Size]->cy);
	m_UiImage[Player2B]->TransparentDraw(backDC, WIDTH * 0.35f, HEIGHT * 0.75f, m_UiSize[Players_Size]->cx, m_UiSize[Players_Size]->cy);
	m_UiImage[Cursor]->TransparentDraw(backDC, WIDTH * 0.35f - m_UiSize[Cursor_Size]->cx, HEIGHT * CursorPosition, m_UiSize[Cursor_Size]->cx, m_UiSize[Cursor_Size]->cy);
}

void Ui::Playing_Draw(HDC backDC, const int* totalscore, const int* bonusscore, const int* life)
{
	HFONT font = CreateFont(Pont_Size, 0, 0, 0, 0, 0, 0, 0, HANGEUL_CHARSET, 0, 0, 0, 0, TEXT("�ü�"));
	HFONT oldfont = (HFONT)SelectObject(backDC, font);
	std::wstring strUi = L"Score : " + std::to_wstring(*totalscore) + L"                          Bonus : " + std::to_wstring(*bonusscore);

	m_UiImage[InterfaceBar]->TransparentDraw(backDC, WIDTH * 0.05f, HEIGHT * 0.05f, m_UiSize[InterfaceBar_Size]->cx, m_UiSize[InterfaceBar_Size]->cy);
	TextOutW(backDC, WIDTH * 0.3f, HEIGHT * 0.09f, strUi.c_str(), strUi.length());

	SelectObject(backDC, oldfont);
	DeleteObject(font);

	for (int i = 1; i <= *life; i++)
		m_UiImage[LifeImage]->TransparentDraw(backDC, WIDTH * 0.83f + ((m_UiSize[LifeImage_Size]->cx + 5) * i), HEIGHT * 0.13f, m_UiSize[LifeImage_Size]->cx, m_UiSize[LifeImage_Size]->cy);
}