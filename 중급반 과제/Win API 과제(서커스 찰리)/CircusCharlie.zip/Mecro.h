#pragma once

#include<iostream>
#include <Windows.h>

enum SystemData
{
	WIDTH = 900,
	HEIGHT = 450,
	One_Miter = 900
};

enum Time
{
	AudienceImage_ChangeTime = 2,
	MoveImage_ChangeTime = 2,
	GoalImage_ChangeTime = 5,
	FirePotImage_ChangeTime = 2,
	FireRingImage_ChangeTime = 2,
	BonusScore_DecreaseTime = 1,
	StarImage_ChageTime = 90,
	Die_StopTime = 1,
	InputDeley_Time = 1
};

enum Speed
{
	Player_Move_Speed = 300,
	Player_Jump_Speed = 250,
	FireRing_Move_Speed = 70,
	SmallFireRing_Move_Speed = 200
};

enum Coord
{
	Character_Move_Coord = One_Miter * 9
};

enum Scene
{
	Lobby_Scene,
	Playing_Scene
};

enum Score
{
	FirePot_Score = 100,
	FireRing_Score = 100,
	Money_Score = 100,
	Bonus_Score = 50
};

enum Key
{
	UP = 72,
	DOWN = 80,
	ENTER = 27
};