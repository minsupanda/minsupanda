#pragma once
#include"Object.h"

class FirePot : public Object
{
private:
	Bitmap* m_Image[2];
	Bitmap* m_CurImage;

	float m_CurCharacterCoord;
	float m_BackGroundWidth;

	int m_Number;

	virtual void Animation(const float& deltaTime) override;

public:
	FirePot();
	~FirePot();

	virtual void Init() override;
	virtual void Update(float TotalMoveDist, float CurMoveDistance, const float& deltaTime) override;
	void Draw(HDC m_backDC);

	inline void SetNumber(int n) { m_Number = n; }
};

