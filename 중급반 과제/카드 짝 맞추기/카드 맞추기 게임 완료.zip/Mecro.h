#pragma once
#include"BitMapManager.h"
#include<iostream>
#include<Windows.h>
#include<string>
#include<stdlib.h>
#include<stdio.h>

enum SystemData
{
	WIDTH = 500,
	HEIGHT = 600,
	WINDOW_X_COORDINATE = 55,
	WINDOW_Y_COORDINATE = 5,
	SPACE_X_BETWEEN_CARDS = 10,
	SPACE_Y_BETWEEN_CARDS = 5,

	Start_Menu_X = (int)(WIDTH * 0.5f),
	Start_Menu_Y = (int)(HEIGHT * 0.3f),
	End_Menu_X = (int)(WIDTH * 0.5f),
	End_Menu_Y = (int)(HEIGHT * 0.5f),

	ALL_CARD_NUMBER = static_cast<int>((IMAGE::IMAGE_BLACK) * 2),

	Clear_Count = static_cast<int>(IMAGE::IMAGE_BLACK),
};

enum class Scene
{
	MainLobby_Scene,
	Before_GameStart_CardOpen_Scene,
	GamePlaying_Scene,
	Card_Compare_Scene,
	GameClear_Scene,
	Game_End_Scene,
	Game_Eixt_Scene,
};

enum CardSize
{
	CardSize_Width = 70,
	CardSize_Height = 100
};

enum ChoiceMenuSize
{
	ChoiceMenuSize_Width = 100,
	ChoiceMenuSize_Height = 20
};
