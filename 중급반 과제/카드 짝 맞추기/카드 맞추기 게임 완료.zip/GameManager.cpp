#include "GameManager.h"
#include "ConstValue.h"

#define CARD_CLOSE(card) card->CardClose(); card = NULL;

GameManager* GameManager::m_iThis = NULL;

GameManager::GameManager() {}


void GameManager::Init(HWND hWnd)
{
	BitMapManager::GetInstance()->Init(hWnd);

	SetTimer(hWnd, TIMER_ID, Default_Time, NULL);

	GameSystem_Init();

	int halfWidth = ChoiceMenuSize::ChoiceMenuSize_Width * 0.5f;
	ButtenRect[ButtenType::Game_Start].left = Start_Menu_X - halfWidth;
	ButtenRect[ButtenType::Game_Start].right = Start_Menu_X + halfWidth;
	ButtenRect[ButtenType::Game_Start].top = Start_Menu_Y;
	ButtenRect[ButtenType::Game_Start].bottom = Start_Menu_Y + ChoiceMenuSize::ChoiceMenuSize_Height;

	ButtenRect[ButtenType::Game_Eixt].left = End_Menu_X - halfWidth;
	ButtenRect[ButtenType::Game_Eixt].right = End_Menu_X + halfWidth;
	ButtenRect[ButtenType::Game_Eixt].top = End_Menu_Y;
	ButtenRect[ButtenType::Game_Eixt].bottom = End_Menu_Y + ChoiceMenuSize::ChoiceMenuSize_Height;

	Card_Shuffle();

	Scene_Change(Scene::MainLobby_Scene);
}
void GameManager::GameSystem_Init()
{
	m_Timer.m_iMin = 0;
	m_Timer.m_iSec = 1;

	m_CardPareCount = 0;
	m_ClickCard[0] = NULL;
	m_ClickCard[1] = NULL;

	Card_Shuffle();
}
void GameManager::Card_Shuffle()
{

	float X_Start_Coordinate = WIDTH * 0.1f;
	float Y_Start_Coordinate = HEIGHT * 0.1f;

	int LineBreak = LINE_BREAK;
	int LineBreakCount = 0;

	const int Width = static_cast<int>(CardSize_Width);
	const int Height = static_cast<int>(CardSize_Height);

	std::vector<IMAGE> img(ALL_CARD_NUMBER);
	const int size = ALL_CARD_NUMBER / 2;
	for (int i = 0; size > i; i++)
	{
		img[i] = (IMAGE)i;
		img[i + size] = (IMAGE)i;
	}

	for (int i = 0, j = 0; i < ALL_CARD_NUMBER; ++i)
	{
		if (LineBreakCount >= LineBreak)
		{
			++j;
			LineBreakCount = 0;
		}

		int index = rand() % img.size();
		IMAGE image = img[index];
		img.erase(img.begin() + index);

		m_Card[i].Init(
			image,
			X_Start_Coordinate + ((Width + SPACE_X_BETWEEN_CARDS) * LineBreakCount),
			Y_Start_Coordinate + ((Height + SPACE_Y_BETWEEN_CARDS) * j),
			Width, Height);

		++LineBreakCount;
	}
}

void GameManager::Scene_Change(Scene ChangeScene)
{
	m_CurScene = ChangeScene;
	Cur_Scene_Start_Acting();
}
void GameManager::Cur_Scene_Start_Acting() // �ش� ���� ���۵Ǿ��� �� ���õǾ�� �� �͵�
{
	switch (m_CurScene)
	{
	case Scene::Before_GameStart_CardOpen_Scene:
		m_StopTime = static_cast<int>(All_OpenCard_Time);
		All_Card_Open();
		break;

	case Scene::Card_Compare_Scene:
		m_StopTime = static_cast<int>(Not_SameCard_Time);
		break;

	case Scene::GameClear_Scene:
		m_StopTime = static_cast<int>(Game_Clear_Scene_Time);
		GameSystem_Init();
		break;

	case Scene::Game_End_Scene:
		m_StopTime = static_cast<int>(Game_End_Scene_Time);
		GameSystem_Init();
		break;

	default:break;
	}
}

void GameManager::Display_Draw(HDC hdc) // ȭ�� �׸���
{
	switch (m_CurScene)
	{

	case Scene::MainLobby_Scene:
		Menu_Draw(hdc);
		break;

	case Scene::Before_GameStart_CardOpen_Scene:
	case Scene::GamePlaying_Scene:
	case Scene::Card_Compare_Scene:
		Time_Draw(hdc);
		AllCard_Draw(hdc);
		break;

	case Scene::GameClear_Scene:
		Clear_Scene_Draw(hdc);
		break;

	case Scene::Game_End_Scene:
		End_Scene_Draw(hdc);

	default : break;
	}
}

#define DT_CUSTOM_CENTER  (DT_CENTER | DT_SINGLELINE | DT_VCENTER)
void GameManager::Menu_Draw(HDC hdc)
{
	Rectangle(hdc, ButtenRect[ButtenType::Game_Start].left, ButtenRect[ButtenType::Game_Start].top, ButtenRect[ButtenType::Game_Start].right, ButtenRect[ButtenType::Game_Start].bottom);
	DrawTextA(hdc, s_GAME_START_MENU.c_str(), s_GAME_START_MENU.length(), &ButtenRect[ButtenType::Game_Start], DT_CUSTOM_CENTER);

	Rectangle(hdc, ButtenRect[ButtenType::Game_Eixt].left, ButtenRect[ButtenType::Game_Eixt].top, ButtenRect[ButtenType::Game_Eixt].right, ButtenRect[ButtenType::Game_Eixt].bottom);
	DrawTextA(hdc, s_GAME_END_MENU.c_str(), s_GAME_END_MENU.length(), &ButtenRect[ButtenType::Game_Eixt], DT_CUSTOM_CENTER);
}
void GameManager::Time_Draw(HDC hdc)
{
	std::string CurTime = std::to_string(m_Timer.m_iMin) + ":" + std::to_string(m_Timer.m_iSec);
	TextOut(hdc, WIDTH * 0.5f, HEIGHT * 0.01f, CurTime.c_str(), CurTime.length());
}
void GameManager::AllCard_Draw(HDC hdc)
{
	for (int i = 0; i < ALL_CARD_NUMBER; i++)
	{
		m_Card[i].Draw(hdc);
	}
}

void GameManager::Clear_Scene_Draw(HDC hdc)
{
	TextOutA(hdc, 100, 100, s_GAME_CLEAR.c_str(), s_GAME_CLEAR.length());
	Scene_Change(Scene::MainLobby_Scene);
}
void GameManager::End_Scene_Draw(HDC hdc)
{
	TextOutA(hdc, 100, 100, s_GAME_END.c_str(), s_GAME_END.length());
	Scene_Change(Scene::MainLobby_Scene);
}


void GameManager::All_Card_Close()
{
	for (int i = 0; i < ALL_CARD_NUMBER; i++)
	{
		m_Card[i].CardClose();
	}
}
void GameManager::All_Card_Open()
{
	for (int i = 0; i < ALL_CARD_NUMBER; i++)
	{
		m_Card[i].CardOpen();
	}
}


void GameManager::TimerCheck()
{
	if (0 < m_StopTime)
	{
		--m_StopTime;
		if (0 >= m_StopTime)
			StopTime_Check();
	}

	switch (m_CurScene)
	{
	case Scene::GamePlaying_Scene:
	case Scene::Card_Compare_Scene:
		--m_Timer.m_iSec;
		if (m_Timer.m_iSec < 0)
		{
			m_Timer.m_iSec = 59;
			--m_Timer.m_iMin;
			if (m_Timer.m_iMin < 0)
			{
				Scene_Change(Scene::Game_End_Scene);
			}
		}
		break;
	}
}

void GameManager::StopTime_Check() // ���� �ð��� ������ �� ����Ǿ�� �� �͵�
{
	switch (m_CurScene)
	{
	case Scene::Before_GameStart_CardOpen_Scene:
		All_Card_Close();
		Scene_Change(Scene::GamePlaying_Scene);
		break;

	case Scene::Card_Compare_Scene:
		CARD_CLOSE(m_ClickCard[0]);
		CARD_CLOSE(m_ClickCard[1]);
		Scene_Change(Scene::GamePlaying_Scene);
		break;

	case Scene::Game_End_Scene:
		Scene_Change(Scene::MainLobby_Scene);
		break;

	default : break;
	}
}


bool GameManager::Click_Check(POINT point)
{
	if (m_StopTime > 0)
		return false;

	switch (m_CurScene)
	{
	case Scene::MainLobby_Scene:
		return Lobby_Menu_Click_Check(point);

	case Scene::GamePlaying_Scene:
		return Card_Click_Check(point);

	default: return false;
	}
}
bool GameManager::Lobby_Menu_Click_Check(POINT point)
{
	if (PtInRect(&ButtenRect[ButtenType::Game_Start], point))
	{
		Scene_Change(Scene::Before_GameStart_CardOpen_Scene);
		return true;
	}
	else if (PtInRect(&ButtenRect[ButtenType::Game_Eixt], point))
	{
		PostQuitMessage(0);
		return true;
	}
}
bool GameManager::Card_Click_Check(POINT point)
{
	for (int i = 0; i < ALL_CARD_NUMBER; i++)
	{
		if (m_Card[i].ColliderCheck(point) == true)
		{
			if (m_ClickCard[0] == NULL)
				m_ClickCard[0] = &m_Card[i];
			else
			{
				m_ClickCard[1] = &m_Card[i];
				if (Same_Card_Check() == true)
				{
					Game_Clear_Check();
				}
			}
			return true;
		}
	}
	return false;
}
bool GameManager::Same_Card_Check()
{
	if (m_ClickCard[0]->Get_Card_Image() != m_ClickCard[1]->Get_Card_Image())
	{
		Scene_Change(Scene::Card_Compare_Scene);
		return false;
	}
	else
	{
		m_ClickCard[0] = NULL;
		m_ClickCard[1] = NULL;
		return true;
	}
}
bool GameManager::Game_Clear_Check()
{
	++m_CardPareCount;
	if (m_CardPareCount < static_cast<int>(Clear_Count))
		return false;

	Scene_Change(Scene::GameClear_Scene);
}

GameManager::~GameManager() {}