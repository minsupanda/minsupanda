#pragma once
#include"Mecro.h"

const static std::string s_GAME_START_MENU = "���� ����";
const static std::string s_GAME_END_MENU = "����";

const static std::string s_GAME_CLEAR = "CLEAR";
const static std::string s_GAME_END = "GAME END.";
