#pragma once
#include"Mecro.h"
#include"Card.h"

#define GameMgr GameManager::Get_Instance()

#define TIMER_ID 1
#define LINE_BREAK 5

enum TimerSecond
{
	Default_Time = 1000,
	Not_SameCard_Time = 1,
	All_OpenCard_Time = 5,
	Game_End_Scene_Time = 2,
	Game_Clear_Scene_Time = 2
};

enum ButtenType
{
	Game_Start,
	Game_Eixt,

	ButtenType_END
};

struct Timer
{
	int m_iMin;
	int m_iSec;
};

class GameManager
{
private:
	GameManager();

	static GameManager* m_iThis;

	Card m_Card[ALL_CARD_NUMBER];
	Card* m_ClickCard[2];
	int m_CardPareCount;

	Timer m_Timer;
	int m_StopTime;

	Scene m_CurScene;

	RECT ButtenRect[ButtenType::ButtenType_END];

	void Card_Shuffle();
	void All_Card_Close();
	void All_Card_Open();

	void Menu_Draw(HDC hdc);
	void AllCard_Draw(HDC hdc);
	void Time_Draw(HDC hdc);
	void Clear_Scene_Draw(HDC hdc);
	void End_Scene_Draw(HDC hdc);

public:
	~GameManager();
	static GameManager* Get_Instance()
	{
		if (m_iThis == NULL)
			m_iThis = new GameManager;
		return m_iThis;
	}

	void Init(HWND hWnd);
	void GameSystem_Init();

	void Scene_Change(Scene ChangeScene);
	void Cur_Scene_Start_Acting();

	void Display_Draw(HDC hdc);

	void TimerCheck();
	void StopTime_Check();

	bool Click_Check(POINT point);
	bool Lobby_Menu_Click_Check(POINT point);
	bool Card_Click_Check(POINT point);
	bool Same_Card_Check();
	bool Game_Clear_Check();
};