#pragma once
#include "Figure.h"

class Box : public Figure
{
public:
	Box();
	~Box();

	virtual void Init(Vector2 v, Vector2 p, Vector2 f, bool move = true) override;
	virtual void Draw(HDC backDC) override;
};

