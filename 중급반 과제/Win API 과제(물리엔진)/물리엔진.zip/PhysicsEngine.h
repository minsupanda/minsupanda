#pragma once
#include<algorithm>
#include"Mecro.h"
#include"Figure.h"
#include"Circle.h"
#include"Box.h"

class PhysicsEngine
{
private:
	Vector2 m_NormalVector = { 0, 0 };

public:
	PhysicsEngine();
	~PhysicsEngine();

	void GravityApply(std::vector<Figure*> Figures, const float& deltaTime);
	void CollisionCheck(std::vector<Figure*> Figures, const float& deltaTime);
	bool CirclevsCircle(Circle* lhs, Circle* rhs);
	bool AABBvsCircle(Box* lhs, Circle* rhs);
	bool AABBvsAABB(Box* lhs, Box* rhs);
	void CollisionHanding(Figure* lhs, Figure* rhs, const float& deltatTime);
};