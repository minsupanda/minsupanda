#include "Goal.h"
#include<string>
Goal::Goal()
{
}

Goal::~Goal()
{
}

void Goal::Init()
{
	m_GoalImage = BitmapMgr->Get_Image(IMAGE_GOAL);
	GoalSize = m_GoalImage->Get_Size();

	m_fx = WIDTH;
	m_fy = DEAFULT_Y_COORD;
	m_GoalRange.left = m_fx;
	m_GoalRange.right = m_fx + GoalSize->cx;
	m_GoalRange.top = m_fy - GoalSize->cy;
	m_GoalRange.bottom = m_fy;
	m_DrawBaseX = 0;
	m_bDraw = false;
	m_BackGroundWidth = WIDTH * 0.3f;
}

void Goal::Update(float AllMoveDistance, float CurMoveDsitance)
{
	if (AllMoveDistance + m_BackGroundWidth >= Character_Move_Coord)
	{
		m_bDraw = true;

		if (Character_Move_Coord <= AllMoveDistance) AllMoveDistance = Character_Move_Coord;

		while (AllMoveDistance > m_BackGroundWidth)
			AllMoveDistance -= m_BackGroundWidth;

		m_DrawBaseX = -AllMoveDistance;
	}
	else m_bDraw = false;
}

void Goal::Draw(HDC& m_backDC)
{

	if (m_bDraw == true)
	{
		std::wstring dist = L"�� ���� mfx :" + std::to_wstring(m_fx) + L"  DrawBase:" + std::to_wstring(m_DrawBaseX) + L"  m_BackGroundWidth : " + std::to_wstring(m_BackGroundWidth);
		TextOutW(m_backDC, 200, 1, dist.c_str(), dist.length());
		m_GoalImage->TransparentDraw(m_backDC, GoalSize->cx + m_fx + m_DrawBaseX, m_fy, GoalSize->cx, GoalSize->cy);
	}
}

