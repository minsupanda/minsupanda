#pragma once
#include <iostream>
#include <Windows.h>

class GameManager
{
private:
	GameManager();
	static GameManager* m_This;

	HBITMAP MyCreateDIBSection(HDC hdc, int width, int height);

	HWND m_hWnd;
	HDC m_forntDC;
	HDC m_backDC;

public:
	~GameManager();
	void Release();
	void Destory();

	static GameManager* Get_Instance()
	{
		if (m_This == NULL)
			m_This = new GameManager;
		return m_This;
	}

	void Init(HWND hWnd);
	void Draw();
	void Update(const float& deltaTime);
};

