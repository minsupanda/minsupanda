#pragma once
#include"Mecro.h"
#include"BitmapManager.h"

#define DEAFULT_X_COORD WIDTH * 0.8f
#define DEAFULT_Y_COORD HEIGHT * 0.69f

class Goal
{
private:
	Bitmap* m_GoalImage;
	const SIZE* GoalSize;
	RECT m_GoalRange;

	float m_fx;
	float m_fy;
	float m_DrawBaseX;
	bool m_bDraw;
	float m_BackGroundWidth;

public:
	Goal();
	~Goal();

	void Init();
	void Draw(HDC& m_backDC);
	void DrawCheck(const float& MoveDistance);
	void Update(float AllMoveDistance, float CurMoveDsitance);
};

