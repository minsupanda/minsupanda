#include "BackGround.h"

BackGround::BackGround()
{
}

BackGround::~BackGround()
{
}

void BackGround::Init()
{

}

void BackGround::Draw(HDC& m_backDC)
{

}
