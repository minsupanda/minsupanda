#pragma once
#include"Mecro.h"
#include"BitmapManager.h"

enum class RingSpeed
{
	Move_Speed = 300
};

enum RingImage
{
	LeftRing = 0,
	RightRing = 1
};

class FireRing
{
private:
	Bitmap* m_FireRingImage[2][2];
	Bitmap* m_CurImage[2];

	SIZE m_Size;
	RECT m_CollisionRect;

	float m_fx;
	float m_fy;

	float m_ImageChangeTime = 0.0f;

	void Animation(const float& deltaTime);

public:
	FireRing();
	~FireRing();

	const RECT* Get_Rect() { return &m_CollisionRect; }

	void Init();
	void Draw(HDC m_backDC);
	void Update(float CurMoveDistance, const float& deltaTime);
};

