#include "FirePot.h"

FirePot::FirePot()
{
}

FirePot::~FirePot()
{
}

void FirePot::Init()
{
	m_FirePotImage[0] = BitmapMgr->Get_Image(IMAGE_FIRE_1);
	m_FirePotImage[1] = BitmapMgr->Get_Image(IMAGE_FIRE_2);
	m_CurImage = m_FirePotImage[0];

	m_Size = *m_FirePotImage[0]->Get_Size();

	m_DrawBaseX = 0;
	m_BackGroundWidth = WIDTH;

	m_fx = WIDTH * 0.6f;
	m_fy = HEIGHT * 0.69f;

	m_CollisionRect.left = m_fx;
	m_CollisionRect.right = m_fx + m_Size.cx;
	m_CollisionRect.top = m_fy;
	m_CollisionRect.bottom = m_fy + m_Size.cy; 

}

void FirePot::Draw(HDC m_backDC)
{
	for (int i = 0; i <= 1; i++) // i : �׷����� �ϴ� ��ġ
	{
		m_CurImage->TransparentDraw(m_backDC, m_fx + m_DrawBaseX + (m_BackGroundWidth * i), m_fy, m_Size.cx, m_Size.cy);
		// DC��, ����Ʈ x��ǥ + �̵��� �Ÿ�(���� ��ǥ) + (�̹����� �����̴� ���� * i), �⺻ y��, cx, cy
		Rectangle(m_backDC, m_CollisionRect.left, m_CollisionRect.top, m_CollisionRect.right, m_CollisionRect.bottom);
	}
}

void FirePot::Update(float TotalMoveDistance, const float& deltaTime)
{
	Animation(deltaTime);

	if (Character_Move_Coord <= TotalMoveDistance) TotalMoveDistance = Character_Move_Coord;

	while (TotalMoveDistance > m_BackGroundWidth)
		TotalMoveDistance -= m_BackGroundWidth;

	m_DrawBaseX = -(TotalMoveDistance);
	m_CollisionRect.left = m_fx + m_DrawBaseX;
	m_CollisionRect.right = m_fx + m_Size.cx + m_DrawBaseX;
}

void FirePot::Animation(const float& deltaTime)
{
	m_ImageChangeTime += deltaTime;

	if (m_ImageChangeTime >= FirePotImage_ChangeTime * 0.1f)
	{
		if (m_CurImage == m_FirePotImage[0])
			m_CurImage = m_FirePotImage[1];
		else
			m_CurImage = m_FirePotImage[0];

		m_ImageChangeTime -= FirePotImage_ChangeTime * 0.1f;
	}
}