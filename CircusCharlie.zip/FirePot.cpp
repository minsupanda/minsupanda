#include "FirePot.h"

FirePot::FirePot()
{
}

FirePot::~FirePot()
{
}

void FirePot::Init()
{
	m_Image[0] = BitmapMgr->Get_Image(IMAGE_FIRE_1);
	m_Image[1] = BitmapMgr->Get_Image(IMAGE_FIRE_2);
	m_CurImage = m_Image[0];

	m_Size = *m_Image[0]->Get_Size();

	m_fx = WIDTH * 0.6f;
	m_fy = HEIGHT * 0.69f;

	m_CollisionRect.left = m_fx;
	m_CollisionRect.right = m_fx + m_Size.cx;
	m_CollisionRect.top = m_fy;
	m_CollisionRect.bottom = m_fy + m_Size.cy; 

	m_ScoreRect.left = m_fx;
	m_ScoreRect.right = m_fx + m_Size.cx;
	m_ScoreRect.top = 0;
	m_ScoreRect.bottom = HEIGHT;
}

void FirePot::Draw(HDC m_backDC)
{
	m_CurImage->TransparentDraw(m_backDC, m_fx, m_fy, m_Size.cx, m_Size.cy);
	// DC��, ����Ʈ x��ǥ + �̵��� �Ÿ�(���� ��ǥ) + �̹����� �����̴� ����, �⺻ y��, cx, cy
	Rectangle(m_backDC, m_CollisionRect.left, m_CollisionRect.top, m_CollisionRect.right, m_CollisionRect.bottom);
}

void FirePot::Update(float CurMoveDistance, const float& deltaTime)
{
	Animation(deltaTime);

	m_fx -= CurMoveDistance; 

	if (m_fx > WIDTH) // �ڷ� �� �� �������� �ٽ� ȭ�ΰ� ���;� �ϱ� ����
		m_fx = (m_Size.cx * -3) + (m_fx - WIDTH);
	if (m_Size.cx * -3 >= m_fx)
		m_fx = WIDTH;

	m_CollisionRect.left = m_fx;
	m_CollisionRect.right = m_fx + m_Size.cx;
	m_ScoreRect.left = m_fx;
	m_ScoreRect.right = m_fx + m_Size.cx;
}


void FirePot::Animation(const float& deltaTime)
{
	m_ImageChangeTime += deltaTime;

	if (m_ImageChangeTime >= FirePotImage_ChangeTime * 0.1f)
	{
		if (m_CurImage == m_Image[0])
			m_CurImage = m_Image[1];
		else
			m_CurImage = m_Image[0];

		m_ImageChangeTime -= FirePotImage_ChangeTime * 0.1f;
	}
}

