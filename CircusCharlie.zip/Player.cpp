#include "Player.h"

Player::Player() {}
Player::~Player() {}

void Player::Init()
{
	m_PlayerImage = BitmapMgr->Get_Image(IMAGE_PLAYER_RUN1);

	m_ix = 0;
	m_iy = 0;
	m_width = WIDTH * 0.2f;
	m_height = HEIGHT * 0.2f;
}

void Player::Draw(HDC& m_backDC)
{
	m_PlayerImage->TransparentDraw(m_backDC, m_ix, m_iy, m_width, m_height);
}

