#pragma once
#include"Mecro.h"
#include"BitmapManager.h"

#define DEFAULT_SPEED 500
#define DEFAULT_X WIDTH * 0.03f
#define GOAL_X WIDTH * 0.8f
#define DEFAULT_Y HEIGHT * 0.66f

enum Direction
{
	None = 0,
	Right = 1,
	Left = -1
};
class Player
{
private:
	Bitmap* m_PlayerImage;

	float m_fx;
	float m_fy;

	Direction dir = Direction::None;
	int m_Speed;
	float m_MoveDistance;
	bool m_MoveDraw;
	// �÷��̾ �� �̵��� �Ÿ��� �ʿ��ϴ�

	float CoordChange(const float MoveDistance, float& m_DrawBaseX, Direction direction);
	void Character_X_Check();

public:
	Player();
	~Player();

	void Init();
	float Update(const float& deltaTime);
	void Draw(HDC& m_backDC);
	void DrawCheck();

	bool Get_MoveDraw() { return m_MoveDraw; }

	void Input(const float& deltaTime);
};

