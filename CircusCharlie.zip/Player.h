#pragma once
#include"Mecro.h"
#include"BitmapManager.h"

#define DEFAULT_SPEED 500
#define DEFAULT_X WIDTH * 0.03f
#define GOAL_X WIDTH * 0.8f
#define DEFAULT_Y HEIGHT * 0.66f
#define MAX_Y DEFAULT_Y - 30.0f

enum Direction
{
	None = 0,
	Right = 1,
	Left = -1
};
class Player
{
private:
	Bitmap* m_PlayerImage;

	float m_fx;
	float m_fy;

	Direction dir = Direction::None;
	int m_Speed;
	float m_MoveDistance;
	float m_CurMoveDistance;
	bool m_Jump = false;
	float m_Y_Increase = 0.0f;

	void Input(const float& deltaTime);
	void Jump(float Half_CurMoveDistance);

public:
	Player();
	~Player();

	void Init();
	float Update(const float& deltaTime);
	void Draw(HDC& m_backDC);

	const float Get_MoveDistance() { return m_MoveDistance; }
};

