#pragma once
#include"Mecro.h"
#include"BitmapManager.h"

#define DEAFULT_X_COORD 0.03f
#define DEAFULT_Y_COORD 0.66f
#define GOAL_COORD 0.8f
#define MAX_Y_COORD 100.0f

enum Direction
{
	None = 0,
	Right = 1,
	Left = -1,
	Up = -1,
	Down = 1
};

enum Speed
{
	Move_Speed = 500,
	Jump_Speed = 300
};

enum Time
{
	MoveImage_ChangeTime = 200,
	GoalImage_ChangeTime = 500
};

enum PlayerImage
{
	Default = 0,
	Back = 1,
	Run = 2,
	Goal1 = 3,
	Goal2 = 4,
	Die = 5,
};

class Player
{
private:
	Bitmap* m_PlayerImage[6];
	Bitmap* m_CurPlayerImage;

	float m_fx;
	float m_fy;

	float m_DefaultX;
	float m_DefaultY;
	float m_MaxY;
	float m_GoalX;

	Direction m_DirX = Direction::None;
	Direction m_DirY = Direction::None;

	float m_MoveDistance;
	float m_CurMoveDistance;

	int m_ImageChangeTime = 0;

	bool m_Goal = false;
	bool m_Jump = false;

	void Input(const float& deltaTime);
	void Jump(const float& deltaTime);
	void GoalCheck();
	void ImageChange(const float& deltaTime);

public:
	Player();
	~Player();

	void Init();
	float Update(const float& deltaTime);
	void Draw(HDC& m_backDC);

	const float Get_MoveDistance() { return m_MoveDistance; }
};

