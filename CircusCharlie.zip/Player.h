#pragma once
#include"Mecro.h"
#include"BitmapManager.h"

#define DEAFULT_X_COORD WIDTH * 0.03f
#define DEAFULT_Y_COORD HEIGHT * 0.66f
#define GOAL_COORD WIDTH * 0.8f
#define MAX_Y_COORD 100.0f

enum Direction
{
	None = 0,
	Right = 1,
	Left = -1,
	Up = -1,
	Down = 1
};

enum Speed
{
	Move_Speed = 500,
	Jump_Speed = 300
};

enum PlayerImage
{
	Default = 0,
	Back = 1,
	Run = 2,
	Goal1 = 3,
	Goal2 = 4,
	Die = 5,
};

class Player
{
private:
	Bitmap* m_PlayerImage[6];
	Bitmap* m_CurPlayerImage;

	RECT m_PlayerRect;
	const SIZE* m_PlayerSize;
	
	float m_fx;
	float m_fy;

	float m_DefaultX;
	float m_DefaultY;
	float m_MaxY;
	float m_GoalX;

	Direction m_DirX = Direction::None;
	Direction m_DirY = Direction::None;

	float m_MoveDistance;
	float m_CurMoveDistance;

	float m_ImageChangeTime = 0.0f;

	bool m_Goal = false;
	bool m_Jump = false;
	bool m_isDie = false;
	bool m_UpScore = false;

	void Input(const float& deltaTime);
	void Jump(const float& deltaTime, int& score);
	void Animation(const float& deltaTime);

public:
	Player();
	~Player();

	void Init();
	void Draw(HDC& m_backDC);
	float Update(const float& deltaTime, int& score);
	bool GoalCheck(const RECT* goalrect, const RECT* firepotrect);

	const float Get_MoveDistance() { return m_MoveDistance; }
	const bool Get_Goal() { return m_Goal; }
	const bool Get_die() { return m_isDie; }
};

