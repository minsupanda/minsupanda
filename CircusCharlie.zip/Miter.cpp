#include "Miter.h"
#include<string>

Miter::Miter() {}
Miter::~Miter() {}

void Miter::Init()
{
	m_MiterImage = BitmapMgr->Get_Image(IMAGE_INTERFACE_METER);
	MiterSize = *m_MiterImage->Get_Size();

	m_DrawBaseX = 0;
	m_BackGroundWidth = WIDTH;
}

void Miter::Draw(HDC m_backDC)
{
	int miter = 0;
	std::wstring CurMiter;

	for (int i = 0; i <= 1; i++) // i : ���ͱⰡ �׷����� �ϴ� ��ġ
	{
		SetBkMode(m_backDC, TRANSPARENT);
		SetTextColor(m_backDC, RGB(255, 255, 255));
		
		miter = 100 - (10 * (m_MiterCount + i));
		if (miter <= 10)
			miter = 10;
		CurMiter = std::to_wstring(miter);

		m_MiterImage->TransparentDraw(m_backDC, m_DrawBaseX + (m_BackGroundWidth * i) + (WIDTH * 0.03f), DEAFULT_Y_COORD, MiterSize.cx, MiterSize.cy);
		// DC��, �̵��� �Ÿ�(���� ��ǥ) + (�̹����� �����̴� ���� * i) + (�ణ ���� ��), �⺻ y��, cx, cy
		TextOutW(m_backDC, m_DrawBaseX + (m_BackGroundWidth * i) + (WIDTH * 0.03f) + (MiterSize.cx * 0.3f), DEAFULT_Y_COORD + (MiterSize.cy * 0.2f), CurMiter.c_str(), CurMiter.length());
	}
}

//************************�����ϱ�
void Miter::Update(float TotalMoveDistance)
{
	if (Character_Move_Coord <= TotalMoveDistance) TotalMoveDistance = Character_Move_Coord;

	m_MiterCount = TotalMoveDistance / WIDTH;

	while (TotalMoveDistance > m_BackGroundWidth)
		TotalMoveDistance -= m_BackGroundWidth;

	m_DrawBaseX = -(TotalMoveDistance);
}
