#pragma once
#include"Mecro.h"
#include"BitmapManager.h"

enum BackGroundImage
{
	Ground,
	Dark_Audience,
	light_Audience,

	ImageEnd
};

enum ColliderImage
{
	Money,
	GroundFire,
	FireRing,
	Goal,

	ImageEnd
};

class BackGround
{
private:
	Bitmap* m_BackGorundImage[BackGroundImage::ImageEnd];

public:
	BackGround();
	~BackGround();

	void Init();
	void Draw(HDC& m_backDC);
};

