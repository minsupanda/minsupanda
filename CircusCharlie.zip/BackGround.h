#pragma once
#include"Mecro.h"
#include"BitmapManager.h"

#define BACKGROUND_IAMGE_NUMBER 15

enum BackGroundImage
{
	Ground,
	Dark_Audience,
	light_Audience,
	Elephant,

	ImageEnd
};

class BackGround
{
private:
	Bitmap* m_BackGorundImage[BackGroundImage::ImageEnd];
	const SIZE* ImageSize[BackGroundImage::ImageEnd];
	int m_BackGroundWidth;
	float m_DrawBaseX;

public:
	BackGround();
	~BackGround();

	void Init();
	void Update(const float CurMoveDistance);
	void Draw(HDC& m_backDC, float& DrawBaseY);
};

