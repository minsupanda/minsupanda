#include "FireRing.h"
#include<string>

FireRing::FireRing()
{
}

FireRing::~FireRing()
{
}

void FireRing::Init()
{
	m_Image[0][LeftRing] = BitmapMgr->Get_Image(IMAGE_RING_LEFT1);
	m_Image[0][RightRing] = BitmapMgr->Get_Image(IMAGE_RING_RIGHT2);
	m_Image[1][LeftRing] = BitmapMgr->Get_Image(IMAGE_RING_LEFT2);
	m_Image[1][RightRing] = BitmapMgr->Get_Image(IMAGE_RING_RIGHT2);
	
	m_CurImage[LeftRing] = m_Image[0][LeftRing];
	m_CurImage[RightRing] = m_Image[0][RightRing];

	//m_Size = *m_Image[0][0]->Get_Size();

	m_fx = WIDTH;
	m_fy = HEIGHT * 0.4f;

	//m_CollisionRect.left = m_fx;
	//m_CollisionRect.right = m_fx + m_Size.cx * 2;
	//m_CollisionRect.top = m_fy + m_Size.cy * 0.7f;
	//m_CollisionRect.bottom = m_fy + m_Size.cy;

	//m_ScoreRect.left = m_fx;
	//m_ScoreRect.right = m_fx + m_Size.cx * 2;
	//m_ScoreRect.top = 0;
	//m_ScoreRect.bottom = m_fy + m_Size.cy;

	score = 100;

}

void FireRing::SetSize(float x)
{
	m_Size = *m_Image[0][0]->Get_Size();
	
	m_Size.cx *= x;
	m_Size.cy *= x;

	m_CollisionRect.left = m_fx;
	m_CollisionRect.right = m_fx + m_Size.cx * 2;
	m_CollisionRect.top = m_fy + m_Size.cy * 0.7f;
	m_CollisionRect.bottom = m_fy + m_Size.cy;

	m_ScoreRect.left = m_fx;
	m_ScoreRect.right = m_fx + m_Size.cx * 2;
	m_ScoreRect.top = 0;
	m_ScoreRect.bottom = m_fy + m_Size.cy;
}

void FireRing::Draw(HDC m_backDC)
{
	for (int i = 0; i < 2; i++) // 0 : ���� �� , 1 : ������ ��
	{
		m_CurImage[i]->TransparentDraw(m_backDC, m_fx + (i * m_Size.cx), m_fy, m_Size.cx, m_Size.cy);
	}
	// DC��, ���� ���� x��ǥ + (i * ���� ���� ũ��), �⺻ y��, cx, cy
	Rectangle(m_backDC, m_CollisionRect.left, m_CollisionRect.top, m_CollisionRect.right, m_CollisionRect.bottom);
}

void FireRing::Update(float AllMoveDistance, float CurMoveDistance, const float& deltaTime)
{
	Animation(deltaTime);

	m_fx -= (float)(m_Speed)*deltaTime + CurMoveDistance; // ���� x��ǥ = (���� ���ǵ� * �ɸ� �ð�) + �ɸ��ð� ��ŭ ĳ���Ͱ� ������ �Ÿ�

	if (m_Size.cx * -3 >= m_fx) // �� ������ ũ�� * x : �� �ٱ����� ���� ���� >= ���� ���� ��ġ 
		m_fx = WIDTH; // �� ��ġ �ʱ�ȭ

	m_CollisionRect.left = m_fx;
	m_CollisionRect.right = m_fx + m_Size.cx * 2;

	m_ScoreRect.left = m_fx;
	m_ScoreRect.right = m_fx + m_Size.cx * 2;
}

void FireRing::Animation(const float& deltaTime)
{
	m_ImageChangeTime += deltaTime;

	if (m_ImageChangeTime >= FireRingImage_ChangeTime * 0.1f)
	{
		if (m_CurImage[LeftRing] == m_Image[1][LeftRing])
		{
			m_CurImage[LeftRing] = m_Image[0][LeftRing];
			m_CurImage[RightRing] = m_Image[0][RightRing];
		}
		else
		{
			m_CurImage[LeftRing] = m_Image[1][LeftRing];
			m_CurImage[RightRing] = m_Image[1][RightRing];
		}

		m_ImageChangeTime -= FireRingImage_ChangeTime * 0.1f;
	}
}