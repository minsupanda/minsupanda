#include "FireRing.h"
#include<string>

FireRing::FireRing()
{
}

FireRing::~FireRing()
{
}

void FireRing::Init()
{
	m_Image[0][LeftRing] = BitmapMgr->Get_Image(IMAGE_RING_LEFT1);
	m_Image[0][RightRing] = BitmapMgr->Get_Image(IMAGE_RING_RIGHT2);
	m_Image[1][LeftRing] = BitmapMgr->Get_Image(IMAGE_RING_LEFT2);
	m_Image[1][RightRing] = BitmapMgr->Get_Image(IMAGE_RING_RIGHT2);
	m_MoneyImage = BitmapMgr->Get_Image(IMAGE_CASH);

	m_CurImage[LeftRing] = m_Image[0][LeftRing];
	m_CurImage[RightRing] = m_Image[0][RightRing];

	m_MoneySize = *m_MoneyImage->Get_Size();

	m_fx = WIDTH;
	m_fy = HEIGHT * 0.4f;

	score = FireRing_Score;
	m_Time = 0.0f;

	MoneyDraw = true;
}

void FireRing::SetSize(float x, RingType type, int num)
{
	m_Size = *m_Image[0][0]->Get_Size();
	
	m_Size.cx *= x;
	m_Size.cy *= x;

	m_CollisionRect.left = m_fx;
	m_CollisionRect.right = m_fx + m_Size.cx * 2;
	m_CollisionRect.top = m_fy + m_Size.cy * 0.7f;
	m_CollisionRect.bottom = m_fy + m_Size.cy;

	m_ScoreRect.left = m_fx;
	m_ScoreRect.right = m_fx + m_Size.cx * 2;
	m_ScoreRect.top = 0;
	m_ScoreRect.bottom = m_fy + m_Size.cy;

	Type = type;
	AddWidth = m_Size.cx * num;
}

void FireRing::Draw(HDC m_backDC)
{
	for (int i = 0; i < 2; i++) // 0 : ���� �� , 1 : ������ ��
	{
		m_CurImage[i]->TransparentDraw(m_backDC, m_fx + (i * m_Size.cx), m_fy, m_Size.cx, m_Size.cy);
	}

	if (MoneyDraw == true && Type == Small)
		m_MoneyImage->TransparentDraw(m_backDC, m_fx + 6.0f, m_fy + 12.0f, m_MoneySize.cx, m_MoneySize.cy);
	// DC��, ���� ���� x��ǥ + (i * ���� ���� ũ��), �⺻ y��, cx, cy
	//Rectangle(m_backDC, m_CollisionRect.left, m_CollisionRect.top, m_CollisionRect.right, m_CollisionRect.bottom);
}

void FireRing::Update(float TotalMoveDist, float CurMoveDistance, const float& deltaTime)
{
	m_Time += deltaTime;

	Animation(deltaTime);

	m_fx -= (float)(m_Speed)*deltaTime + CurMoveDistance; // ���� x��ǥ = (���� ���ǵ� * �ɸ� �ð�) + �ɸ��ð� ��ŭ ĳ���Ͱ� ������ �Ÿ�

	if (-AddWidth >= m_fx) // �� ������ ũ�� * x : �� �ٱ����� ���� ���� >= ���� ���� ��ġ 
		m_fx = WIDTH; // �� ��ġ �ʱ�ȭ

	m_CollisionRect.left = m_fx;
	m_CollisionRect.right = m_fx + m_Size.cx * 2;

	m_ScoreRect.left = m_fx;
	m_ScoreRect.right = m_fx + m_Size.cx * 2;
}

void FireRing::Animation(const float& deltaTime)
{
	m_ImageChangeTime += deltaTime;

	if (m_ImageChangeTime >= FireRingImage_ChangeTime * 0.1f)
	{
		if (m_CurImage[LeftRing] == m_Image[1][LeftRing])
		{
			m_CurImage[LeftRing] = m_Image[0][LeftRing];
			m_CurImage[RightRing] = m_Image[0][RightRing];
		}
		else
		{
			m_CurImage[LeftRing] = m_Image[1][LeftRing];
			m_CurImage[RightRing] = m_Image[1][RightRing];
		}

		m_ImageChangeTime -= FireRingImage_ChangeTime * 0.1f;
	}
}