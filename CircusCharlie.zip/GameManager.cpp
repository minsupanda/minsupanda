#include "GameManager.h"

GameManager* GameManager::m_This = NULL;

GameManager::GameManager() {}

void GameManager::Init(HWND hWnd)
{
	m_hWnd = hWnd;

	m_forntDC = GetDC(m_hWnd);	
	m_backDC = CreateCompatibleDC(m_forntDC);


}

void GameManager::Draw()
{

}

void GameManager::Update(const float& deltaTime)
{
}

HBITMAP GameManager::MyCreateDIBSection(HDC hdc, int width, int height)
{
	return HBITMAP();
}

GameManager::~GameManager()
{
}

void GameManager::Release()
{
	DeleteDC(m_backDC);
	ReleaseDC(m_hWnd, m_forntDC);
}

void GameManager::Destory()
{
	if (m_This)
	{
		delete m_This;
		m_This = NULL;
	}
}