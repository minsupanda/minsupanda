#pragma once
#include"Mecro.h"
#include"BitmapManager.h"

#define DEAFULT_X_COORD WIDTH * 0.03f
#define DEAFULT_Y_COORD HEIGHT * 0.83f

class Miter
{
private:
	Bitmap* m_MiterImage;
	SIZE MiterSize;

	int m_MiterCount = 0;

	float m_fx;
	float m_fy;
	
	float m_BackGroundWidth;
	float m_DrawBaseX;

public:
	Miter();
	~Miter();

	void Init();
	void Draw(HDC m_backDC);
	void Update(float TotalMoveDistance);
};

