#pragma once
#include"Mecro.h"
#include"BitmapManager.h"

class Object abstract
{
protected:

	SIZE m_Size;
	RECT m_CollisionRect;
	RECT m_ScoreRect;

	float m_fx;
	float m_fy;

	float m_ImageChangeTime = 0.0f;

	int score = 0;

	virtual void Animation(const float& deltaTime) abstract;

public:
	Object();
	virtual ~Object();

	virtual void Init() abstract;
	virtual void Draw(HDC m_backDC) abstract;
	virtual void Update(float CurMoveDistance, const float& deltaTime) abstract;

	const RECT* Get_ColliderRect() { return &m_CollisionRect; }
	const RECT* Get_ScoreRect() { return &m_ScoreRect; }

	bool ColliderCheck(const RECT* playerRect);
	bool ScoreUpCheck(const RECT* playerRect);

	int GetScore() const { return score; }
};

