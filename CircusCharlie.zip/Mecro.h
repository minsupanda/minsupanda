#pragma once

#include<iostream>
#include <Windows.h>

#define CHARACTER_MOVE_COORD 1000

enum SystemData
{
	WIDTH = 900,
	HEIGHT = 450,
};

enum Time
{
	AudienceImage_ChangeTime = 2,
	MoveImage_ChangeTime = 2,
	GoalImage_ChangeTime = 5
};