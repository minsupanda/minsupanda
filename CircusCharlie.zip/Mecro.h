#pragma once

#include<iostream>
#include <Windows.h>

enum SystemData
{
	WIDTH = 900,
	HEIGHT = 450,
};

enum Time
{
	AudienceImage_ChangeTime = 2,
	MoveImage_ChangeTime = 2,
	GoalImage_ChangeTime = 5
};

enum Coord
{
	Character_Move_Coord = WIDTH * 9
};