#pragma once

#include<iostream>
#include <Windows.h>

#define CHARACTER_MOVE_COORD 3000

enum SystemData
{
	WIDTH = 900,
	HEIGHT = 450,
};