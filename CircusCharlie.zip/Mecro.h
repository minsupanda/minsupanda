#pragma once

#include<iostream>
#include <Windows.h>

enum SystemData
{
	WIDTH = 900,
	HEIGHT = 450,
};

enum Time
{
	AudienceImage_ChangeTime = 2,
	MoveImage_ChangeTime = 2,
	GoalImage_ChangeTime = 5,
	FirePotImage_ChangeTime = 2,
	FireRingImage_ChangeTime = 2
};

enum Speed
{
	Player_Move_Speed = 500,
	Player_Jump_Speed = 300,
	FireRing_Move_Speed = 100,
	SmallFireRing_Move_Speed = 300
};

enum Coord
{
	Character_Move_Coord = WIDTH * 9
};