#pragma once

#include<iostream>
#include <Windows.h>

enum SystemData
{
	WIDTH = 900,
	HEIGHT = 450,
};