#pragma once
#include"Object.h"

class FirePot : public Object
{
private:
	Bitmap* m_Image[2];
	Bitmap* m_CurImage;

	virtual void Animation(const float& deltaTime) override;

public:
	FirePot();
	~FirePot();

	virtual void Init() override;
	virtual void Draw(HDC m_backDC) override;
	virtual void Update(float CurMoveDistance, const float& deltaTime) override;
};

