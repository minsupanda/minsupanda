#pragma once
#include"Mecro.h"
#include"BitmapManager.h"

class FirePot
{
private:
	Bitmap* m_FirePotImage[2];
	Bitmap* m_CurImage;
	
	SIZE m_Size;
	RECT m_CollisionRect;
	RECT m_ScroeRect;

	float m_fx;
	float m_fy;

	float m_ImageChangeTime = 0.0f;

	void Animation(const float& deltaTime);

public:
	FirePot();
	~FirePot();

	const RECT* Get_ColliderRect() { return &m_CollisionRect; }
	const RECT* Get_ScoreRect() { return &m_ScroeRect; }

	void Init();
	void Draw(HDC m_backDC);
	void Update(float CurMoveDistance, float TotalMoveDistance, const float& deltaTime);
};

