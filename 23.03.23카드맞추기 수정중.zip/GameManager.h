#pragma once
#include"Mecro.h"
#include"Card.h"
#include"Timer.h"
#include<time.h>

#define GameMgr GameManager::Get_Instance()
#define ALL_CARD_NUMBER static_cast<int>((IMAGE::IMAGE_BLACK) * 2)

#define TIMER_ID 1
#define DEFAULT_TIME 1000
#define NOT_SAME_CARD_TIME 3000
#define ALL_OPEN_CARD_TIME 5000

#define START_MENU_X WIDTH * 0.5f
#define START_MENU_Y HEIGHT * 0.5f 
#define END_MENU_X WIDTH * 0.5f
#define END_MENU_Y HEIGHT * 0.5f 

#define LINE_BREAK 5
#define GAME_CLEAR_COUNT 5

enum TimerSecond
{
	Default_Time = 1,
	Not_SameCard_Time = 3,
	All_OpenCard_Time = 5
};

struct Timer
{
	int m_iMin;
	int m_iSec;
};

class GameManager
{
private:
	GameManager();
	static GameManager* m_iThis;

	Card m_Card[ALL_CARD_NUMBER];
	Card* m_ClickCard[2];
	Timer m_Timer;
	int m_StopTime;
	Scene m_CurScene;
	int m_CardPareCount;
	RECT m_StartMenuRect;
	RECT m_EndMenuRect;

	void All_Card_Close();
	void All_Card_Open();

	void Menu_Draw(HDC hdc);
	void AllCard_Draw(HDC hdc);
	void Time_Draw(HDC hdc);

	void Card_Shuffle();
public:
	~GameManager();
	static GameManager* Get_Instance()
	{
		if (m_iThis == NULL)
			m_iThis = new GameManager;
		return m_iThis;
	}

	void Init(HWND hWnd);
	void Cur_Scene_Start_Acting();

	void Display_Draw(HDC hdc);

	void TimerCheck();
	void StopTime_Check();

	bool Click_Check(POINT point);
	bool Lobby_Menu_Click_Check(POINT point);
	bool Card_Click_Check(POINT point);
	bool Same_Card_Check();
	bool Game_Clear_Check();
};