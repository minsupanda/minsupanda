#include "GameManager.h"
#include "ConstValue.h"

#define CARD_CLOSE(card) card->CardClose(); card = NULL;

GameManager* GameManager::m_iThis = NULL;

GameManager::GameManager() {}


void GameManager::Init(HWND hWnd)
{
	BitMapManager::GetInstance()->Init(hWnd);

	SetTimer(hWnd, TIMER_ID, DEFAULT_TIME, NULL);

	m_Timer.m_iMin = 5;
	m_Timer.m_iSec = 0;

	int halfWidth = StartMenuSize_Width * 0.5f;
	m_StartMenuRect.left = START_MENU_X - halfWidth;
	m_StartMenuRect.right = START_MENU_X + halfWidth;
	m_StartMenuRect.top = START_MENU_Y;
	m_StartMenuRect.bottom = START_MENU_Y + StartMenuSize_Height;

	m_EndMenuRect.left = END_MENU_X;
	m_EndMenuRect.right = END_MENU_X + EndMenuSize_Width;
	m_EndMenuRect.top = END_MENU_Y;
	m_EndMenuRect.bottom = END_MENU_Y + EndMenuSize_Height;

	m_ClickCard[0] = NULL;
	m_ClickCard[1] = NULL;

	float X_Start_Coordinate = WIDTH * 0.1f;
	float Y_Start_Coordinate = HEIGHT * 0.1f;

	int LineBreak = LINE_BREAK;
	int LineBreakCount = 0;

	const int Width = static_cast<int>(CardSize_Width);
	const int Height = static_cast<int>(CardSize_Height);

	std::vector<IMAGE> img(ALL_CARD_NUMBER);
	for (int i = 0; 10 > i; i++)
	{
		img[i] = (IMAGE)i;
		img[i + 10] = (IMAGE)i;
	}

	for (int i = 0, j = 0; i < ALL_CARD_NUMBER; ++i)
	{
		if (LineBreakCount >= LineBreak)
		{
			++j;
			LineBreakCount = 0;
		}

		int index = rand() % img.size();
		IMAGE image = img[index];
		img.erase(img.begin() + index);

		m_Card[i].Init(
			image,
			X_Start_Coordinate + ((Width + SPACE_X_BETWEEN_CARDS) * LineBreakCount),
			Y_Start_Coordinate + ((Height + SPACE_Y_BETWEEN_CARDS) * j),
			Width, Height);

		++LineBreakCount;
	}

	m_CurScene = Scene::MainLobby_Scene;

	Cur_Scene_Start_Acting();
}

void GameManager::Cur_Scene_Start_Acting() // �ش� ���� ���۵Ǿ��� �� ���õǾ�� �� �͵�
{
	switch (m_CurScene)
	{
	case Scene::Before_GameStart_CardOpen_Scene:
		Card_Shuffle();
		m_StopTime = static_cast<int>(All_OpenCard_Time);
		All_Card_Open();
		break;

	default:break;
	}
}

void GameManager::Card_Shuffle()
{

}

void GameManager::Display_Draw(HDC hdc) // ȭ�� �׸���
{
	switch (m_CurScene)
	{

	case Scene::MainLobby_Scene:
		Menu_Draw(hdc);
		break;

	case Scene::Before_GameStart_CardOpen_Scene:
	case Scene::GamePlaying_Scene:
	case Scene::Card_Compare_Scene:
		Time_Draw(hdc);
		AllCard_Draw(hdc);
		break;

	case Scene::Game_End_Scene:
		break;
	}
}

void GameManager::Menu_Draw(HDC hdc)
{
	Rectangle(hdc, m_StartMenuRect.left, m_StartMenuRect.top, m_StartMenuRect.right, m_StartMenuRect.bottom);
	DrawTextA(hdc, s_GAME_START_MENU.c_str(), s_GAME_START_MENU.length(), &m_StartMenuRect, DT_CENTER | DT_SINGLELINE | DT_VCENTER);
	//TextOut(hdc, START_MENU_X, START_MENU_Y, s_GAME_START_MENU.c_str(), s_GAME_START_MENU.length());
	TextOut(hdc, END_MENU_X, END_MENU_Y, s_GAME_END_MENU.c_str(), s_GAME_END_MENU.length());
}
void GameManager::Time_Draw(HDC hdc)
{
	std::string CurTime = std::to_string(m_Timer.m_iMin) + ":" + std::to_string(m_Timer.m_iSec);
	TextOut(hdc, WIDTH * 0.5f, HEIGHT * 0.01f, CurTime.c_str(), CurTime.length());
}
void GameManager::AllCard_Draw(HDC hdc)
{
	for (int i = 0; i < ALL_CARD_NUMBER; i++)
	{
		m_Card[i].Draw(hdc);
	}
}


void GameManager::All_Card_Close()
{
	for (int i = 0; i < ALL_CARD_NUMBER; i++)
	{
		m_Card[i].CardClose();
	}
}
void GameManager::All_Card_Open()
{
	for (int i = 0; i < ALL_CARD_NUMBER; i++)
	{
		m_Card[i].CardOpen();
	}
}


void GameManager::TimerCheck()
{
	if (0 < m_StopTime)
	{
		--m_StopTime;
		if (0 >= m_StopTime)
			StopTime_Check();
	}

	switch (m_CurScene)
	{
	case Scene::GamePlaying_Scene:
	case Scene::Card_Compare_Scene:
		--m_Timer.m_iSec;
		if (m_Timer.m_iSec < 0)
		{
			m_Timer.m_iSec = 59;
			--m_Timer.m_iMin;
			if (m_Timer.m_iMin < 0)
			{
				// ���� �й�
			}
		}
		break;
	}
}
void GameManager::StopTime_Check() // ���� �ð��� ������ �� ����Ǿ�� �� �͵�
{
	switch (m_CurScene)
	{
	case Scene::Before_GameStart_CardOpen_Scene:
		All_Card_Close();
		m_CurScene = Scene::GamePlaying_Scene;
		break;

	case Scene::Card_Compare_Scene:
		CARD_CLOSE(m_ClickCard[0]);
		CARD_CLOSE(m_ClickCard[1]);
		m_CurScene = Scene::GamePlaying_Scene;
		break;

	default : break;
	}
}


bool GameManager::Click_Check(POINT point)
{
	if (m_StopTime > 0)
		return false;

	switch (m_CurScene)
	{
	case Scene::MainLobby_Scene:
		return Lobby_Menu_Click_Check(point);

	case Scene::GamePlaying_Scene:
		return Card_Click_Check(point);

	default: return false;
	}
}
bool GameManager::Lobby_Menu_Click_Check(POINT point)
{
	if (PtInRect(&m_StartMenuRect, point))
	{
		m_CurScene = Scene::Before_GameStart_CardOpen_Scene;
		return true;
	}
	else if (PtInRect(&m_EndMenuRect, point))
	{
		m_CurScene = Scene::Game_End_Scene;
		return true;
	}
}
bool GameManager::Card_Click_Check(POINT point)
{
	for (int i = 0; i < ALL_CARD_NUMBER; i++)
	{
		if (m_Card[i].ColliderCheck(point) == true)
		{
			if (m_ClickCard[0] == NULL)
				m_ClickCard[0] = &m_Card[i];
			else
			{
				m_ClickCard[1] = &m_Card[i];
				if (Same_Card_Check() == true)
				{
					Game_Clear_Check();
				}
			}
			return true;
		}
	}
	return false;
}
bool GameManager::Same_Card_Check()
{
	if (m_ClickCard[0]->Get_Card_Image() != m_ClickCard[1]->Get_Card_Image())
	{
		m_StopTime = static_cast<int>(Not_SameCard_Time);
		m_CurScene = Scene::Card_Compare_Scene;
		return false;
	}
	else
	{
		m_ClickCard[0] = NULL;
		m_ClickCard[1] = NULL;
		return true;
	}
}
bool GameManager::Game_Clear_Check()
{
	++m_CardPareCount;
	if (m_CardPareCount < GAME_CLEAR_COUNT)
		return false;

	m_CurScene = Scene::Game_End_Scene;
}

GameManager::~GameManager() {}