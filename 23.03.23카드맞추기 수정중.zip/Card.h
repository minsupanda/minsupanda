#pragma once
#include"BitMap.h"
#include"BitMapManager.h"

enum CARD
{
	CARD_FRONT,
	CARD_REAR,
	CARD_END
};

class Card
{
private:
	CARD m_eCardState;
	BitMap* m_pBitMap[CARD_END];
	int m_ix;
	int m_iy;
	int m_iWidth;
	int m_iHeight;
	RECT m_BitMapRect;
public:
	Card();
	~Card();
	
	const BitMap* Get_Card_Image() { return m_pBitMap[CARD_FRONT]; }

	void Init(IMAGE Index, int x, int y, int w, int h);
	void Draw(HDC hdc);
	bool ColliderCheck(POINT point);
	bool CardOpenCheck(POINT point);
	inline void CardOpen()
	{
		m_eCardState = CARD_FRONT;
	}
	inline void CardClose()
	{
		m_eCardState = CARD_REAR;
	}
};

