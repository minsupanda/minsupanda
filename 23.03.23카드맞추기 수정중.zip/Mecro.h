#pragma once
#include<iostream>
#include<Windows.h>
#include<string>
#include<stdlib.h>
#include<stdio.h>

#define WIDTH 500
#define HEIGHT 600
#define WINDOW_X_COORDINATE 55
#define WINDOW_Y_COORDINATE 5
#define SPACE_X_BETWEEN_CARDS 10
#define SPACE_Y_BETWEEN_CARDS 5

enum class Scene
{
	MainLobby_Scene,
	Before_GameStart_CardOpen_Scene,
	GamePlaying_Scene,
	Card_Compare_Scene,
	Game_End_Scene
};

enum CardSize
{
	CardSize_Width = 70,
	CardSize_Height = 100
};

enum StartMenuSize
{
	StartMenuSize_Width = 200,
	StartMenuSize_Height = 100
};

enum EndMenuSize
{
	EndMenuSize_Width = 20,
	EndMenuSize_Height = 10
};