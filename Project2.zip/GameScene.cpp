#include "GameScene.h"
#include "Phone.h"
#include "InputManager.h"
#include "ResourceManager.h"
#include "GameManager.h"

GameScene::GameScene()
{
}

GameScene::~GameScene()
{
}

void GameScene::Initialize()
{
	player = new Player;
	player->Initialize();
	InteractionFurniture = new Phone;
	InteractionFurniture->Initialize();

	PrintTextUI = false;
	messageTimer = 0.0f;

	ResourceMgr->Load("base_panel.bmp");

	uiImage = UIMgr->AddUI<UIImage>("base_panel");
	uiImage->Initialize("base_panel.bmp", DrawType::Transparent);
	uiImage->SetPosition(SceneMgr->GetWidth() * 0.5f, SceneMgr->GetHeight() * 0.5f, true);
	uiImage->SetEnable(false);

	text = UIMgr->AddUI<UILabel>("Text_Ui", uiImage);
	text->Initialize("None", (0, 0, 50));
	text->SetLocalPosition(uiImage->GetSize().cx * 0.5f, uiImage->GetSize().cy * 0.5f - 100, true);
}

void GameScene::Update(const float& deltaTime)
{
	switch (player->GetState())
	{
	case Player::State::Idle:
	case Player::State::Move:
		
		if (player->GetpressInteractionKey()) // ��ȣ�ۿ� Ű�� �������� ��
			if (CheckInteraction()) break; // ��ȣ�ۿ��� �Ǿ����� update ����(���� ����)

		player->Update(deltaTime);
		InteractionFurniture->Update(deltaTime);

		break;

	case Player::State::Quiz:
		if(InputMgr->GetKeyDown(VK_ESCAPE) || InteractionFurniture->GetQuizClear()) // ��� Ǯ�ٰ� esc�� �����ų�, �̹� �Ϸ�� ������ ��
		{
			InteractionFurniture->QuizEnd();
			player->StateChange(Player::State::Idle);
			player->pressKeyChange();
			break;
		}

		InteractionFurniture->Update(deltaTime);

		if (InteractionFurniture->GetQuizClear() && !InteractionFurniture->GetAcquireItem()) // ����� Ŭ�����ϰ� �������� ȹ������ �ʾ��� ��
			SetTextUi();

		break;
	}

	CheckTextUiTime(deltaTime);
}

void GameScene::SetTextUi()
{
	PrintTextUI = true;
	player->AcquireItem(InteractionFurniture->GetItem()); // �÷��̾� ������ ȹ��

	std::string str;
	std::vector<ItemType> getItem = InteractionFurniture->GetItem();
	int i = 1;

	for (auto item = getItem.begin(); item != getItem.end(); item++, i++)
	{
		if (i < getItem.size())
			str += GameMgr->getName(*item) + "��(��) ";
		else
			str += GameMgr->getName(*item);
	}
	str += "��(��) ȹ���Ͽ����ϴ�!";

	text->SetText(str);
	uiImage->SetEnable(true);
	messageTimer = MassageTime;
}

void GameScene::CheckTextUiTime(const float& deltaTime)
{
	if (PrintTextUI)
	{
		messageTimer -= deltaTime;
		if (messageTimer <= 0)
		{
			PrintTextUI = false;
			uiImage->SetEnable(false);
		}
	}
}

bool GameScene::CheckInteraction()
{
	RECT lprcDst;
	if (IntersectRect(&lprcDst, player->GetRect(), InteractionFurniture->GetRect())) // ĳ���Ϳ� �繰���� �浹�ߴ��� üũ : ��ȣ�ۿ��ϱ� ����(���� ����)
	{
		switch (player->GetDir())
		{
		case Player::Direction::Left:
			if (player->GetPos().x > InteractionFurniture->GetPos().x) return CheckQuizStart();

			else return false;
		
		case Player::Direction::Right:
			if (player->GetPos().x < InteractionFurniture->GetPos().x) return CheckQuizStart();
		
			else return false;

		case Player::Direction::Up:
			if (player->GetPos().y > InteractionFurniture->GetPos().y) return CheckQuizStart();
	
			else return false;

		case Player::Direction::Down:
			if (player->GetPos().y < InteractionFurniture->GetPos().y) return CheckQuizStart();
			
			else return false;


		default: return false;
		}
	}
}

bool GameScene::CheckQuizStart()
{
	if (InteractionFurniture->GetQuizClear() == false)
	{
		InteractionFurniture->QuizStart();
		player->StateChange(Player::State::Quiz);
		return true;
	}
	else return false;
}


void GameScene::Draw()
{
	player->Draw();
	InteractionFurniture->Draw();
	Rectangle(SceneMgr->GetBackDC(), InteractionFurniture->GetRect()->left, InteractionFurniture->GetRect()->top, InteractionFurniture->GetRect()->right, InteractionFurniture->GetRect()->bottom);
}

void GameScene::Release()
{
	REL_DEL(player);
	REL_DEL(InteractionFurniture);
}
