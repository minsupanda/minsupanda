#include "Quiz.h"
#include"SceneManager.h"
#include"InputManager.h"

Quiz::Quiz()
{
	Renderer = nullptr;
	isClear = false;
}


void Quiz::Initialize(std::string fileName, std::string answer)
{
	Renderer = new SpriteRenderer(fileName.c_str());
	Renderer->SetPivot(Pivot::Left | Pivot::Bottom);
	Renderer->SetScale(transform->scale.x, transform->scale.y);
	transform->position = { 300, 400 }; // �ʱ� ��ġ ����
	AddComponent(Renderer); // gameObject�� ������Ʈ�� �߰��Ǳ� ������ gameObject �Ҹ��ڿ����� �����Ҵ��� ������ �ȴ�
	
	Answer = answer;
}


void Quiz::Update(const FLOAT& deltaTime)
{
	Operate(this);

	if (InputMgr->GetKeyDown(VK_RETURN))
	{
		if (inputAnswer == Answer) isClear = true;
		else inputAnswer.clear();
	}
	else if (InputMgr->GetKeyDown(VK_BACK))
	{
		if (!inputAnswer.empty())
			inputAnswer.pop_back();
	}
	else inputAnswer += InputMgr->GetChar();

}

void Quiz::Draw()
{
	Renderer->Draw();
	TextOutA(SceneMgr->GetBackDC(), 300, 600, inputAnswer.c_str(), inputAnswer.length());
}

void Quiz::Release()
{
}

Quiz::~Quiz()
{

}