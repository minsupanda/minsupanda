#include "Box.h"

Box::Box() {}

Box::~Box() {}

void Box::Init(Vector2 v, Vector2 p, Vector2 f, bool move)
{
	m_Type = FigureType::Box;

	m_HalfSize = v * 0.5f;
	m_Velocity = f;
	m_Position = p;

	m_e = 0.3f;

	m_Mass = v.x * v.y;
	m_Inv_Mass = m_Mass * 0.1f;

	m_bMove = move;
}

void Box::Draw(HDC backDC)
{
	Rectangle(backDC, m_Position.x - m_HalfSize.x, m_Position.y - m_HalfSize.y, m_Position.x + m_HalfSize.x, m_Position.y + m_HalfSize.y);
}
