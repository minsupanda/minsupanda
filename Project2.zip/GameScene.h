#pragma once
#include "Player.h"
#include "Phone.h"
#include "SceneManager.h"

#ifndef GAEME_SCENE_H
#define GAEME_SCENE_H

using namespace ENGINE;

class GameScene : public Scene
{
private:

	enum Data { MaxFurinture = 5 };

	Bitmap* background = nullptr;

	Player* player = nullptr;

	Furniture* Furnitures[MaxFurinture];
	Furniture* InteractionFurniture = nullptr; // ���� ��ȣ�ۿ� ���� ����

public:
	GameScene();
	~GameScene();

	// Scene��(��) ���� ��ӵ�
	virtual void Initialize() override;
	virtual void Release() override;
	virtual void Update(const float& deltaTime) override;
	virtual void Draw() override;

	void CheckInteraction();
};


#endif