#pragma once
#include "EngineMecro.h"
#include "Components/SpriteRenderer.h"
#include <fstream>

#ifndef GAME_MANAGER_H
#define GAME_MANAGER_H

using namespace ENGINE;

struct Item
{
	SpriteRenderer* Renderer;
	std::string name;
};

class GameManager
{
private:
	enum SystemData { ItemMax = 5, Battery = 0, SafeHint = 1, TableHint = 2, CabinetHint1 = 3, CabinetHint2 = 4, EscapeKey = 5};

	Item items[ItemMax];

public:
	GameManager();
	~GameManager();

	void Init();
};

#endif