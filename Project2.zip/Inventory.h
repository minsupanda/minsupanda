#pragma once
#include "EngineMecro.h"
#include "GameManager.h"
#include "Components/SpriteRenderer.h"
#include <vector>

#ifndef Inventory_H
#define Inventory_H

using namespace ENGINE;

class Inventory : public GameObject
{
private:
	SpriteRenderer* Renderer;
	std::vector<ItemType> items;

public:
	Inventory();
	~Inventory();

	void Initialize(std::string fileName);
	void Update(const FLOAT& deltaTime, std::vector<ItemType>& playerItems);
	void Draw();
};

#endif