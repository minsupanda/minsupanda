#include "Circle.h"

Circle::Circle() {}

Circle::~Circle() {}

void Circle::Init(Vector2 v, Vector2 p)
{
	m_Type = CireCle;

	m_HalfSize = v * 0.5f;
	m_Velocity = { 0.0f, 0.0f };
	m_Position = p;

	m_e = 0.8f;
	m_Mass = v.x * v.y * 3.14;
	m_Inv_Mass = m_Mass * 0.1f;


}

void Circle::Draw(HDC backDC)
{
	Ellipse(backDC, m_Position.x, m_Position.y, m_Position.x + m_HalfSize.x * 2.0f, m_Position.y + m_HalfSize.y * 2.0f);
}
