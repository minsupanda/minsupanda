#include "GameManager.h"
#include "ResourceManager.h"
#include "Component.h"

GameManager::GameManager()
{
}

GameManager::~GameManager()
{
}

void GameManager::Initizlize()
{
	ResourceMgr->Load("Battery.bmp");
	items[(int)ItemType::Battery].Renderer = { new SpriteRenderer("Battery.bmp")};
	items[(int)ItemType::Battery].Renderer->SetPivot(Pivot::Left | Pivot::Bottom);
	items[(int)ItemType::Battery].Renderer->SetScale(items[(int)ItemType::Battery].GetTransform()->scale.x, items[(int)ItemType::Battery].GetTransform()->scale.y);
	items[(int)ItemType::Battery].itemData.interactionType = FurnitureType::Clock;
	items[(int)ItemType::Battery].itemData.name = "Battery";

	ResourceMgr->Load("EscapeKey.bmp");
	items[(int)ItemType::EscapeKey].Renderer = { new SpriteRenderer("EscapeKey.bmp") };
	items[(int)ItemType::EscapeKey].Renderer->SetPivot(Pivot::Left | Pivot::Bottom);
	items[(int)ItemType::EscapeKey].Renderer->SetScale(items[(int)ItemType::EscapeKey].GetTransform()->scale.x, items[(int)ItemType::EscapeKey].GetTransform()->scale.y);
	items[(int)ItemType::EscapeKey].itemData.interactionType = FurnitureType::Clock;
	items[(int)ItemType::EscapeKey].itemData.name = "EscapeKey";

}

void GameManager::Draw(ItemType item)
{
}
