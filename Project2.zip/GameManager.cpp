#include "GameManager.h"
#include "ResourceManager.h"
#include "Component.h"
GameManager::GameManager()
{
}

GameManager::~GameManager()
{
}

void GameManager::Init()
{
	ResourceMgr->Load("Abocado.bmp");
	new SpriteRenderer("Apple.bmp");
	items[Battery] = { new SpriteRenderer("Apple.bmp"), "Battery"};
	items[Battery].Renderer->SetPivot(Pivot::Left | Pivot::Bottom);
	//items[Battery].Renderer->SetScale(transform->scale.x, transform->scale.y);
}