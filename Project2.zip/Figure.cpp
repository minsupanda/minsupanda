#include "Figure.h"

Figure::Figure() {}

Figure::~Figure() {}

void Figure::Init(Vector2 v, Vector2 p, Vector2 f, bool move) {}

void Figure::Draw(HDC backDC) {}

void Figure::AddForce(Vector2 force)
{
	if (m_bMove == true)
		m_Velocity += force;
}

void Figure::Update(const float& deltaTime)
{
	if(m_bMove == true)
		m_Position += m_Velocity * deltaTime;
}
