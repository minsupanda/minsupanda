#include "Furniture.h"

Furniture::Furniture()
{
	Renderer = nullptr;
	quizStart = false;
}


void Furniture::Release()
{
}

Furniture::~Furniture()
{

}