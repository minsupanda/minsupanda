#include "Player.h"
#include "ResourceManager.h"
#include "SceneManager.h"

Player::Player()
{
    state = State::Idle;
    Dir = Direction::Right;
    pressInteractionKey = false;

    ResourceMgr->Load("Player.bmp");

    Renderer = new SpriteRenderer("Player.bmp", SpritesX, SpritesY);
    Renderer->SetPivot(Pivot::Left | Pivot::Bottom);
    Renderer->SetScale(transform->scale.x, transform->scale.y);
    AddComponent(Renderer);
    AddComponent(Anim = new SpriteAnimation(SpritesX, SpritesY));

    SIZE Charactersize = Renderer->GetDrawSize();

    minBounds.x = 0;
    minBounds.y = Charactersize.cy;
    maxBounds.x = SceneMgr->GetWidth() - Charactersize.cx;
    maxBounds.y = SceneMgr->GetHeight();

    InputComponent* input = new InputComponent;
    input->AddBinding(VK_LEFT, [&]() { Dir = Direction::Left; state = State::Move; }, [&]() { state = State::Idle; });
    input->AddBinding(VK_RIGHT, [&]() { Dir = Direction::Right; state = State::Move; }, [&]() { state = State::Idle; });
    input->AddBinding(VK_UP, [&]() { Dir = Direction::Up; state = State::Move; }, [&]() { state = State::Idle; });
    input->AddBinding(VK_DOWN, [&]() { Dir = Direction::Down; state = State::Move; }, [&]() { state = State::Idle; });
    input->AddBinding(VK_SPACE, [&]() { pressInteractionKey = true; }, [&]() { pressInteractionKey = false; });
    AddComponent(input);
}


void Player::Initialize()
{
    transform->position = { 600, 800 }; // ĳ���� �ʱ� ��ġ ����
}

void Player::Update(const FLOAT& deltaTime)
{
    Operate(this); /* *************** �ݵ�� �־����*/

    switch (state)
    {
    case State::Move: Move(deltaTime); break;
    case State::Quiz: break; // ���� update �Լ� �۵� �ǵ���
    default: Anim->Stop(); break;
    }
}

void Player::Move(const float& deltaTime)
{
    switch (Dir)
    {
    case Direction::Right:Anim->Play(0); transform->position.x += Speed * deltaTime; break;
    case Direction::Left:Anim->Play(1); transform->position.x -= Speed * deltaTime; break;
    // �� �Ʒ��� ���� �̹��� ��� ��� ��ü�س�
    case Direction::Up:Anim->Play(0); transform->position.y -= Speed * deltaTime; break; 
    case Direction::Down:Anim->Play(1); transform->position.y += Speed * deltaTime; break;
    }

    if (Bounds[Left].x > transform->position.x) transform->position.x = Bounds[Left].x; // ���� ���ٵ� ��� ���� ���� �ٲ��ֱ�
    if (Bounds[Right].x < transform->position.x) transform->position.x = Bounds[Right].x;
    // minm, mix ���� 2���� ���� �ϱ�
    if (Bounds[Top].y > transform->position.y) transform->position.y = Bounds[Top].y; // ���� ���ٵ� ��� ���� ���� �ٲ��ֱ�
    if (Bounds[Bottom].y < transform->position.y) transform->position.y = Bounds[Bottom].y;

    

}

void Player::ChangeItem()
{
}


void Player::Draw()
{
    Renderer->Draw(); /* renderer draw�� �ݵ�� ���� ȣ������� ��*/


#ifdef _DEBUG //ifndef : ���� _DEBUG�� ���ԵǾ� ���� �ʴٸ� => ���� ��Ȳ������ ���� �ڵ尡 ��Ȱ��ȭ �ȴ�
     // ------------------------------------------------------------------------------------------------
    // ------------------------------------------�����------------------------------------------------
    Vector2 plyaerVec = GetPos();
    RECT playerRect = *GetRect();
    Rectangle(SceneMgr->GetBackDC(), playerRect.left, playerRect.top, playerRect.right, playerRect.bottom);

    std::wstring s = std::to_wstring(transform->position.x) + L"   " + std::to_wstring(transform->position.y);
    TextOut(SceneMgr->GetBackDC(), 1, 1, s.c_str(), s.length());

    std::wstring s2 = std::to_wstring(playerRect.left) + L"   " + std::to_wstring(playerRect.top) + L"  " + std::to_wstring(playerRect.right) + L"  " + std::to_wstring(playerRect.bottom);
    TextOut(SceneMgr->GetBackDC(), 20, 20, s2.c_str(), s2.length());

    // ------------------------------------------------------------------------------------------------
#endif
}


void Player::Release()
{
}

Player::~Player()
{
}