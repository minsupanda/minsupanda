#include "GameScene.h"
#include "Phone.h"
#include "InputManager.h"

GameScene::GameScene()
{
}

GameScene::~GameScene()
{
}

void GameScene::Initialize()
{
	player = new Player;
	player->Initialize();
	InteractionFurniture = new Phone;
	InteractionFurniture->Initialize();

}

void GameScene::Update(const float& deltaTime)
{
	switch (player->GetState())
	{
	case Player::State::Idle:
	case Player::State::Move:
		
		if (player->GetpressInteractionKey()) // ��ȣ�ۿ� Ű�� �������� ��
			if (CheckInteraction()) break; // ��ȣ�ۿ��� �Ǿ����� update ����(���� ����)

		player->Update(deltaTime);
		InteractionFurniture->Update(deltaTime);

		break;

	case Player::State::Quiz:
		if(InputMgr->GetKeyDown(VK_ESCAPE))
		{
			InteractionFurniture->QuizEnd();
			player->StateChange(Player::State::Idle);
			player->pressKeyChange();
		}
		InteractionFurniture->Update(deltaTime);
		
		break;
	}
}

bool GameScene::CheckInteraction()
{
	RECT lprcDst;
	if (IntersectRect(&lprcDst, player->GetRect(), InteractionFurniture->GetRect())) // ĳ���Ϳ� �繰���� �浹�ߴ��� üũ : ��ȣ�ۿ��ϱ� ����(���� ����)
	{
		switch (player->GetDir())
		{
		case Player::Direction::Left:
			if (player->GetPos().x > InteractionFurniture->GetPos().x)
			{
				InteractionFurniture->QuizStart();
				player->StateChange(Player::State::Quiz);
			}
			return true;
		
		case Player::Direction::Right:
			if (player->GetPos().x < InteractionFurniture->GetPos().x)
			{
				InteractionFurniture->QuizStart();
				player->StateChange(Player::State::Quiz);
			}
			return true;

		case Player::Direction::Up:
			if (player->GetPos().y > InteractionFurniture->GetPos().y)
			{
				InteractionFurniture->QuizStart();
				player->StateChange(Player::State::Quiz);
			}
			return true;

		case Player::Direction::Down:
			if (player->GetPos().y < InteractionFurniture->GetPos().y)
			{
				InteractionFurniture->QuizStart();
				player->StateChange(Player::State::Quiz);
			}
			return true;

		default: return false;
		}
	}
}

void GameScene::Draw()
{
	player->Draw();
	InteractionFurniture->Draw();
	Rectangle(SceneMgr->GetBackDC(), InteractionFurniture->GetRect()->left, InteractionFurniture->GetRect()->top, InteractionFurniture->GetRect()->right, InteractionFurniture->GetRect()->bottom);
}

void GameScene::Release()
{
	REL_DEL(player);
	REL_DEL(InteractionFurniture);
}
