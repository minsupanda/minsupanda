#pragma once
#include "EngineMecro.h"
#include "Components/SpriteRenderer.h"
#include "Quiz.h"
#include "GameManager.h"
#include <vector>


#ifndef Furniture_H
#define Furniture_H

using namespace ENGINE;

class Furniture abstract : public GameObject
{
protected:
	SpriteRenderer* Renderer;
	Quiz* quiz;
	bool quizStart;
	std::vector<ItemType> items;
	bool isAcquireItem;

public:
	Furniture();
	virtual ~Furniture();
	
	virtual void Initialize() abstract; // ���� �̹���, ������ �̹��� �ҷ�����, ������Ʈ �߰���Ű��
	virtual void Release();
	virtual void Update(const FLOAT & deltaTime) abstract; // ��ȣ�ۿ� �Ǵ� �� Ȯ�� �� �� ������Ʈ 
	virtual void Draw() abstract;
	// bool isInteraction(Item * EquipItem)

	void QuizStart() { quizStart = true; }
	void QuizEnd() { quizStart = false; quiz->ClearinputAnswer(); }

	RECT* GetRect() { return Renderer->GetRect(); }
	Vector2 GetPos() { return Renderer->GetPos(); }
	bool GetQuizStart() { return quizStart; }
	bool GetQuizClear() { return quiz->GetisClear(); }
	bool GetAcquireItem() { return isAcquireItem; }
	std::vector<ItemType> GetItem() { return items; }
};

#endif 