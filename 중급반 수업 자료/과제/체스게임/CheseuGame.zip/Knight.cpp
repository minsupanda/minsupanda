#include "Knight.h"
#include "GameBoardManager.h"

Knight::Knight(PieceColor color)
{
	m_piece = PieceType::Knight;
	m_color = color;
	m_pieceImage = BitmapMgr->Get_Image((int)PieceType::Knight + (int)color);
}

Knight::~Knight()
{
}

void Knight::MoveCheck(std::vector<TileIndex>& m_MoveblePosition)
{
	m_MoveblePosition.clear(); // Ȥ�� �� ������ �����ϱ� ���� clear
	int x =	GetCX();
	int y = GetCY();

	int CheckX = x + 1;
	int CheckY = y - 2;
	if (CheckX >= 0 && CheckX < 8 && CheckY >= 0 && CheckY < 8)
		MoveRectSave(CheckX, CheckY, m_MoveblePosition);

	CheckX = x - 1;
	CheckY = y - 2;
	if (CheckX >= 0 && CheckX < 8 && CheckY >= 0 && CheckY < 8)
		MoveRectSave(CheckX, CheckY, m_MoveblePosition);

	CheckX = x + 1;
	CheckY = y + 2;
	if (CheckX >= 0 && CheckX < 8 && CheckY >= 0 && CheckY < 8)
		MoveRectSave(CheckX, CheckY, m_MoveblePosition);

	CheckX = x - 1;
	CheckY = y + 2;
	if (CheckX >= 0 && CheckX < 8 && CheckY >= 0 && CheckY < 8)
		MoveRectSave(CheckX, CheckY, m_MoveblePosition);

	CheckX = x + 2;
	CheckY = y + 1;
	if (CheckX >= 0 && CheckX < 8 && CheckY >= 0 && CheckY < 8)
		MoveRectSave(CheckX, CheckY, m_MoveblePosition);
	
	CheckX = x + 2;
	CheckY = y - 1;
	if (CheckX >= 0 && CheckX < 8 && CheckY >= 0 && CheckY < 8)
		MoveRectSave(CheckX, CheckY, m_MoveblePosition);

	CheckX = x - 2;
	CheckY = y + 1;
	if (CheckX >= 0 && CheckX < 8 && CheckY >= 0 && CheckY < 8)
		MoveRectSave(CheckX, CheckY, m_MoveblePosition);

	CheckX = x - 2;
	CheckY = y - 1;
	if (CheckX >= 0 && CheckX < 8 && CheckY >= 0 && CheckY <= 8)
		MoveRectSave(CheckX, CheckY, m_MoveblePosition);
}

void Knight::MoveRectSave(int x, int y, std::vector<TileIndex>& m_MoveblePosition)
{
	TileCoord* Tile = GameBoardMgr->Get_Tile(x, y);
	if (Tile->piece != NULL)
	{
		if (Tile->piece->Get_Color() != m_color)
			m_MoveblePosition.push_back({ x, y });
	}
	else
		m_MoveblePosition.push_back({ x, y });
}
