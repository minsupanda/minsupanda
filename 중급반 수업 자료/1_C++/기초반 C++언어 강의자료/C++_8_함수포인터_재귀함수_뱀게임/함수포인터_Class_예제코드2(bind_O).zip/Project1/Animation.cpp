#include "Animation.h"
#include"Character.h"

void Animation::SetAnimation(std::string _strAnimationName, std::function<void()> _callbackFunc)
{
	m_callBackFunction = _callbackFunc;
	m_strAnimationName = _strAnimationName;
}

void Animation::Play()
{
	int oldClock = clock();
	cout << m_strAnimationName << "���ϸ��̼� ������..." << endl;
	while (clock() - oldClock < 1000);
	m_callBackFunction();
}
