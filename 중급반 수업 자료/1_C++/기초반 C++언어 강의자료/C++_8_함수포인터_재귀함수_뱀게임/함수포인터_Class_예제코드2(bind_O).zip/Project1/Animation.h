#pragma once
#include<iostream>
#include<functional>
#include<time.h>
using namespace std;

class Character;
class Animation
{
private:
	std::string	m_strAnimationName;
	std::function<void()> m_callBackFunction;
public:
	void SetAnimation(std::string _strAnimationName, std::function<void()> _callbackFunc);
	void Play();
};

