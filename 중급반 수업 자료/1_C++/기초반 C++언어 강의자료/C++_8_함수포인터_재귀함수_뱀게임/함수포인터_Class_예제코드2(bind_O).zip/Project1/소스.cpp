#include"Character.h"
#include"Monster.h"


void main()
{
	Character character1;

	character1.BuffAnimation();
	character1.AttackAnimation();
	character1.HitbyAnimation(100);

	Monster monster;
	monster.AttackAnimation();
	monster.BuffAnimation();
	monster.HitbyAnimation(200);
	return;
}
