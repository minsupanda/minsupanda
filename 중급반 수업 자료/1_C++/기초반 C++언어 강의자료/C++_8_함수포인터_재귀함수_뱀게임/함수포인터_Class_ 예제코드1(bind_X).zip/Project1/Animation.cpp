#include "Animation.h"
#include"Character.h"

void Animation::SetAnimation(std::string _strAnimationName, std::function<void(Character&)> _callbackFunc, Character* _pPlayer)
{
	m_callBackFunction = _callbackFunc;
	m_strAnimationName = _strAnimationName;
	m_pPlayer = _pPlayer;
}

void Animation::Play()
{
	int oldClock = clock();
	cout << m_strAnimationName << "���ϸ��̼� ������..." << endl;
	while (clock() - oldClock < 1000);
	m_callBackFunction(*m_pPlayer);
}
