#pragma once
#include"Animation.h"

class Character
{
private:
	int m_iHP;
	int m_iDamage;
	int m_iCurHitDamage;
	Animation m_animHitBy;
	Animation m_animAttack;
	Animation m_animBuff;
	void HitBy();
	void Buff();
	void Attack();
public:
	Character();
	~Character();

	void AttackAnimation();
	void BuffAnimation();
	void HitbyAnimation(int _iHitDamage);
};

