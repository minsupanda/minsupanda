#include"Character.h"


void main()
{
	Character character1;

	character1.BuffAnimation();
	character1.AttackAnimation();
	character1.HitbyAnimation(100);

	Character character2;

	character2.BuffAnimation();
	character2.BuffAnimation();
	character2.AttackAnimation();
	character2.HitbyAnimation(300);
	return;
}
