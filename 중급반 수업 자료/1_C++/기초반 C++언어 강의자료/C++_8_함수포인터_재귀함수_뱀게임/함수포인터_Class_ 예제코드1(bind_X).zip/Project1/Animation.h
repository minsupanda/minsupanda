#pragma once
#include<iostream>
#include<functional>
#include<time.h>
using namespace std;

class Character;
class Animation
{
private:
	std::string	m_strAnimationName;
	std::function<void(Character&)> m_callBackFunction;
	Character* m_pPlayer;
public:
	void SetAnimation(std::string _strAnimationName, std::function<void(Character&)> _callbackFunc,Character* _pPlayer);
	void Play();
};

