#include "GameScene.h"

GameScene::GameScene()
{
}

GameScene::~GameScene()
{
}

void GameScene::Initialize()
{
	player = new Player;
	player->Initialize();
}

void GameScene::Update(const float& deltaTime)
{
	player->Update(deltaTime);

}

void GameScene::Draw()
{
	player->Draw();

	//InteractionFurniture
}

void GameScene::Release()
{
	REL_DEL(player);
}
