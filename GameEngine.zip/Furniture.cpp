#include "Furniture.h"

Furniture::Furniture()
{
}

Furniture::~Furniture()
{
}
