#pragma once
#ifndef ENGINE_MECRO_H
#define ENGINE_MECRO_H
#pragma comment(lib, "msimg32.lib")
#include <crtdbg.h>
#include <windows.h>
#include <time.h>
#include <algorithm>
#include "Component.h"

#ifndef DEL
#define DEL(a) if(a) {delete a; a = nullptr;} // delete ��ũ�� �Լ� 
#endif // ! DEL

#ifndef REL_DEL
#define REL_DEL(a) if(a) {a->Release(); delete a; a= nullptr;} // Release() �Լ�
#endif // !REL_DEL

namespace ENGINE
{
	enum // ����(no name) enum, ���� ������ ���Ǵ� ���� �⺻ ������ ���� 
	{
		ClientSize_Width = 800,
		ClientSize_Height = 600,
		ClientSize_Per_X = 50,
		ClientSize_Per_Y = 50, /* 0 ~ 100% */
		FPS = 120
	};

	__interface Scene
	{
		void Initialize();
		void Release();
		void Update(const float& deltaTime);
		void Draw();
	};
}

#endif // !ENGINE_MECRO_H