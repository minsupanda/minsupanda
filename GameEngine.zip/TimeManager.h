#pragma once
#include "Singleton.h"
#ifndef TIME_MANAGER_H
#define TIME_MANAGER_H

namespace ENGINE
{
	class TimeManager : public Singleton<TimeManager>
	{
	private:
		UINT32 FPS;
		float elapseTime; // ��� �ð�
		ULONGLONG currTime, lastTime, elapsed;
		TimeManager() : FPS(0), elapseTime(0.0f), currTime(0), lastTime(0) {}
	public:
		void Initialize(UINT32 FPS);
		bool Update();
		float DeltaTime() CONST { return elapseTime; }

		friend Singleton;
	};
#define TimeMgr TimeManager::GetInstance()
}

#endif // !TIME_MANAGER_H
