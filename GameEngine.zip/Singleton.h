#pragma once
#include "EngineMecro.h"
#ifndef SINGLETON.H
#define SINGLETON.H
template<typename T>
class Singleton
{
private:
	static T* instacne;
protected:
	Singleton() {}

public:
	static T* GetInstance()
	{
		if (nullptr == instance) instance = new T;
		return instance;
	}
	static void Destroy() { DEL(instance); }
	template<typename T>T* Singleton<T>::instance = nullptr
};
#endif // !SINGLETON.H
