#include "SceneManager.h"
#include "TimeManager.h"
namespace ENGINE
{
	SceneManager::~SceneManager() { Release(); }

	void SceneManager::Initialize(HWND hWnd, UINT32 width, UINT32 height)
	{
		if (!hWnd) return;

		this->hWnd = hWnd;
		this->width = width;
		this->height = height;
		hDC = GetDC(hWnd);
		hBackDC = CreateCompatibleDC(hDC);
		TimeMgr->Initialize(FPS); // FPS : EngineMecro::ENGINE::enum::FPS
	}

	void SceneManager::Release()
	{
		currScene = NULL;
		TimeMgr->Destroy();
		for (std::pair<std::string, Scene*> scene : scenes) REL_DEL(scene.second);
		scenes.clear();
		DeleteObject(hBackDC);
		ReleaseDC(hWnd, hDC);
	}

	void SceneManager::Render()
	{
		if (!TimeMgr->Update()) return;
		if (currScene) // currScene�� NULL�� �ƴ� ���� ������ UPDATE, Draw �ǵ���
		{
			Update();
			Draw();
		}
		SetScene();
	}

	void SceneManager::SetScene()
	{
		if (nextScene.empty()) return;
		if (currScene) { currScene->Release(); }
		currScene = scenes[nextScene];
		currScene->Initialize();
		nextScene = "";
	}

	void SceneManager::Update()
	{
		currScene->Update(TimeMgr->DeltaTime());
	}

	void SceneManager::Draw()
	{
		HBITMAP backBitmap = CreateDIBSectionRe();
		SelectObject(hBackDC, backBitmap);
		currScene->Draw();
		BitBlt(hDC, 0, 0, width, height, hBackDC, 0, 0, SRCCOPY);
		DeleteObject(backBitmap);
	}

}