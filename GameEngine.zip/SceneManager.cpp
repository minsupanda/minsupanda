#include "SceneManager.h"
#include "TimeManager.h"
#include "InputManager.h"
#include "ResourceManager.h"

namespace ENGINE
{
	SceneManager::~SceneManager() { Release(); }

	void SceneManager::Initialize(HWND hWnd, UINT32 width, UINT32 height)
	{
		if (!hWnd) return;

		this->hWnd = hWnd;
		this->width = width;
		this->height = height;
		hDC = GetDC(hWnd);
		hBackDC = CreateCompatibleDC(hDC);
		TimeMgr->Initialize(FPS); // FPS : EngineMecro::ENGINE::enum::FPS
		InputMgr->Initialize();
		ResourceMgr->Initialize();
	}

	void SceneManager::Release()
	{
		currScene = NULL;
		TimeMgr->Destroy();
		InputMgr->Destroy();
		ResourceMgr->Destroy();
		for (std::pair<std::string, Scene*> scene : scenes) REL_DEL(scene.second);
		scenes.clear();
		DeleteObject(hBackDC);
		ReleaseDC(hWnd, hDC);
	}

	void SceneManager::Render()
	{
		if (!TimeMgr->Update()) return;
		if (currScene) // currScene�� NULL�� �ƴ� ���� ������ UPDATE, Draw �ǵ���
		{
			Update();
			Draw();
			InputMgr->Update();
		}
		SetScene();
	}

	void SceneManager::SetScene()
	{
		if (nextScene.empty()) return;
		if (currScene)
		{
			currScene->Release(); 
			ResourceMgr->Clear();
		}
		currScene = scenes[nextScene];
		currScene->Initialize();
		nextScene = "";
	}

	void SceneManager::Update()
	{
		currScene->Update(TimeMgr->DeltaTime());
	}

	void SceneManager::Draw()
	{
		HBITMAP backBitmap = CreateDIBSectionRe();
		SelectObject(hBackDC, backBitmap);
		currScene->Draw();
		BitBlt(hDC, 0, 0, width, height, hBackDC, 0, 0, SRCCOPY);
		DeleteObject(backBitmap);
	}

	bool SceneManager::RegisterScene(LPCSTR sceneName, Scene* scene)
	{
		// �� �̸��� ���ų�, scene�� ����� �����Ͱ� null�̰ų� �Ÿ�Ͽ� �ߺ��� ���� ���� ��� ����� ���� �ʴ´�
		if ("" == sceneName || !scene || scenes.find(sceneName) != scenes.end()) return false;
		scenes.insert(std::make_pair(sceneName, scene));
		return true;
	}

	bool SceneManager::LoadScene(LPCSTR sceneName)
	{
		if ("" == sceneName || scenes.find(sceneName) == scenes.end()) return false;
		nextScene = sceneName;
		return true;
	}

	HBITMAP SceneManager::CreateDIBSectionRe()
	{
		BITMAPINFO bmpInfo;
		ZeroMemory(&bmpInfo.bmiHeader, sizeof(BITMAPINFOHEADER));
		bmpInfo.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
		bmpInfo.bmiHeader.biBitCount = 32;
		bmpInfo.bmiHeader.biWidth = width;
		bmpInfo.bmiHeader.biHeight = height;
		bmpInfo.bmiHeader.biPlanes = 1;
		LPVOID pBits;
		return CreateDIBSection(hDC, &bmpInfo, DIB_RGB_COLORS, (void**)&pBits, NULL, 0);
	}
} //namespace ENGIN