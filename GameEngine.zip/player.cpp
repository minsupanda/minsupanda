#include "player.h"
#include "ResourceManager.h"

player::player()
{
    State = State::Idle;
    Dir = Direction::Right;

    ResourceMgr->Load("Player.bmp");

    Renderer = new SpriteRenderer("Player.bmp", SpritesX, SpritesY);
    Renderer->SetPivot(Pivot::Left | Pivot::Bottom);
    Renderer->SetScale(transform->scale.x, transform->scale.y);
    AddComponent(Renderer);
    AddComponent(Anim = new SpriteAnimation(SpritesX, SpritesY));

    InputComponent* input = new InputComponent;
    input->AddBinding(VK_LEFT, [&]() { Dir = Direction::Left; State = State::Move; }, [&]() { State = State::Idle; });
    input->AddBinding(VK_RIGHT, [&]() { Dir = Direction::Right; State = State::Move; }, [&]() { State = State::Idle; });
    input->AddBinding(VK_UP, [&]() { Dir = Direction::Up; State = State::Move; }, [&]() { State = State::Idle; });
    input->AddBinding(VK_DOWN, [&]() { Dir = Direction::Down; State = State::Move; }, [&]() { State = State::Idle; });
    AddComponent(input);
}


void player::Initialize()
{
    transform->position = { 400, 600 };
}

void player::Update(const FLOAT& deltaTime)
{
}

void player::Move(const float& deltaTime)
{
}

void player::ChangeItem()
{
}


void player::Draw()
{
}



void player::Release()
{
}

player::~player()
{
}