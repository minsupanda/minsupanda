#pragma once
class UIImage
{
};

