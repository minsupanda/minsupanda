#include "Phone.h"
#include "ResourceManager.h"

Phone::Phone()
{
    ResourceMgr->Load("Apple.bmp");

    Renderer = new SpriteRenderer("Apple.bmp");
    Renderer->SetPivot(Pivot::Left | Pivot::Bottom);
    Renderer->SetScale(transform->scale.x, transform->scale.y);
    AddComponent(Renderer);

}
Phone::~Phone()
{
}
void Phone::Initialize()
{
	transform->position = { 10, 800 }; // ĳ���� �ʱ� ��ġ ����
}

void Phone::Update(const FLOAT& deltaTime)
{

}

void Phone::Draw()
{
    Renderer->Draw();
}
