#include "../Component.h"
#include "../Bitmap.h"

#ifndef SPRITE_RENDERER_H
#define SPRITE_RENDERER_H

namespace ENGINE
{
	class SpriteRenderer : public GrahpicComponent
	{
	private:
		Bitmap* sprites;
		SIZE localSize, size;
		Vector2 pos, divide;

	private:
		SpriteRenderer();
	public:
		SpriteRenderer(LPCSTR name, UINT divX = 1, UINT divY = 1);

		void SetPivot(INT pivot) { if (sprites) sprites->SetPivot(pivot); }
		void SetSrc(UINT cx, UINT cy);
		SIZE GetDrawSize() { return size; }

		// GrahpicComponent��(��) ���� ��ӵ�
		virtual void Operate(GameObject* Owner) override;
		virtual void Reset() override;
		virtual void SetScale(UINT cx, UINT cy) override;
		virtual void Draw() override;
	};
}

#endif // !SPRITE_RENDERER_H