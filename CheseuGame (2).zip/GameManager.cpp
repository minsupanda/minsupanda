#include "GameManager.h"
#include "GameBoardManager.h"

GameManager* GameManager::m_hThis = NULL;

GameManager::GameManager()
{
}

GameManager::~GameManager()
{
}

void GameManager::Init(HWND hWnd)
{
	BitmapMgr->Init(hWnd);

	GameBoardMgr->Init(0, 0, 78, 75);

}

bool GameManager::Click_Check(POINT Point)
{
	return true;
}

void GameManager::Draw(HDC hdc)
{
	GameBoardMgr->Draw(hdc);
}
