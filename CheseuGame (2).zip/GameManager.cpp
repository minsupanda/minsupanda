#include "GameManager.h"
#include "GameBoardManager.h"
#include "PieceManager.h"

GameManager* GameManager::m_hThis = NULL;

GameManager::GameManager()
{
}

GameManager::~GameManager()
{
}

void GameManager::Init(HWND hWnd)
{
	RECT rcClient;
	GetClientRect(hWnd, &rcClient);
	int ClientWidth = rcClient.right - rcClient.left;
	int ClientHeight = rcClient.bottom - rcClient.top;

	BitmapMgr->Init(hWnd);
	GameBoardMgr->Init(0, 0, ClientWidth / 8, ClientHeight / 8);
	PieceMgr->Init(0, 0, ClientWidth / 8, ClientHeight / 8);

	m_CurPlayColor = WHITE;
	m_ClickTileImage = BitmapMgr->Get_Image((int)IMAGE_SELECT);
	m_CurScene = Scene::PieceChoiceScene;
}

void GameManager::Draw(HDC hdc)
{
	GameBoardMgr->Draw(hdc);
	PieceMgr->Draw(hdc);
	for (auto Position : m_MoveblePosition)
		m_ClickTileImage->MovableTileDraw(hdc, Position.left, Position.top, Position.right - Position.left, Position.bottom - Position.top);

}

bool GameManager::Click_Check(POINT Point)
{
	switch (m_CurScene)
	{
	case Scene::PieceChoiceScene:
		m_MoveblePosition.clear();
		m_CurChoicePiece = GameBoardMgr->Point_in_TileRect_Check(Point);
		if (m_CurChoicePiece != nullptr)
		{
			if (m_CurChoicePiece->Get_Color() == m_CurPlayColor)
			{
				m_CurChoicePiece->MoveCheck(m_Direction);
				SceneChange(m_CurScene);
			}
		}
		break;
	
	case Scene::PieceMoveScene:
		for (auto Position : m_MoveblePosition)
		{
			if (PtInRect(&Position, Point))
			{
				m_CurChoicePiece->PositionChange(&Position);
				GameBoardMgr->Position_In_PieceCheck(m_CurChoicePiece);
				TurnChange(m_CurPlayColor);
			}
		}
		SceneChange(m_CurScene);
		m_MoveblePosition.clear();
		break;
	}
	return true;
}

void GameManager::TurnChange(PieceColor CurTurnColor)
{
	switch (CurTurnColor)
	{
	case PieceColor::BLACK:
		m_CurPlayColor = PieceColor::WHITE;
		break;

	case PieceColor::WHITE:
		m_CurPlayColor = PieceColor::BLACK;
		break;
	}
}

void GameManager::SceneChange(Scene CurScene)
{
	switch (m_CurScene)
	{
	case Scene::PieceChoiceScene:
		m_CurScene = Scene::PieceMoveScene;
		break;

	case Scene::PieceMoveScene:
		m_CurScene = Scene::PieceChoiceScene;
		break;
	}
}
