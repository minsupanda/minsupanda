#include "Piece.h"

Piece::Piece()
{
}

Piece::~Piece()
{
}

void Piece::Init(int x, int y, int width, int height)
{
	m_ix = x;
	m_iy = y;
	m_width = width;
	m_height = height;
	m_BitmapRect.left = x;
	m_BitmapRect.top = y;
	m_BitmapRect.right = x + width;
	m_BitmapRect.bottom = y + height;
}

void Piece::Draw(HDC hdc)
{
	m_pieceImage->PieceDraw(hdc, m_ix, m_iy, m_width, m_height);
}

void Piece::PositionChange(RECT* m_MoveblePosition)
{
	m_ix = m_MoveblePosition->left;
	m_iy = m_MoveblePosition->top;
	m_width = m_MoveblePosition->right - m_ix;
	m_height = m_MoveblePosition->bottom - m_iy;
	CatchPieceCheck();
}
