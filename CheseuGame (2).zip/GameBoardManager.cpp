#include "GameBoardManager.h"

GameBoardManager* GameBoardManager::m_hThis = NULL;

GameBoardManager::GameBoardManager() {}

void GameBoardManager::Init(int x, int y, int width, int height)
{
	m_Image[SkinColor] = BitmapMgr->Get_Image(IMAGE_FRIST_TILE);
	m_Image[BrownColor] = BitmapMgr->Get_Image(IMAGE_SECOND_TILE);
	m_width = width; // Window_Width * 0.12f;
	m_height = height; // Window_Height * 0.12f;

	for (int i = 0; i < 8; i++)
	{
		for (int j = 0; j < 8; j++)
		{
			m_Tile[i][j].m_ix = x;
			m_Tile[i][j].m_iy = y;
			//m_Tile[i][j].BitmapRect.left = x;
			//m_Tile[i][j].BitmapRect.top = y;
			//m_Tile[i][j].BitmapRect.right = x + m_width;
			//m_Tile[i][j].BitmapRect.bottom = y + m_width;
			// �ʿ� ���� : ���� ����� ������ �ð� ���⵵���� ���� ���⵵�� �� �켱���ϴ� ���� ȿ�����̱� ������ ����� �ʿ��Ҷ� ����ϱ�.

			m_Tile[i][j].piece = NULL;
			x += m_width;
		}
		x = 0;
		y += m_height;
	}
}

void GameBoardManager::Draw(HDC hdc)
{ 
	int CurColor = SkinColor;
	int ChangeColor = BrownColor;
	for (int i = 0; i < 8; i++)
	{
		for (int j = 0; j < 8; j++)
		{
			m_Image[CurColor]->Draw(hdc, m_Tile[i][j].m_ix, m_Tile[i][j].m_iy, m_Tile[i][j].m_ix + m_width, m_Tile[i][j].m_iy + m_height);
			int tmpColor = CurColor;
			CurColor = ChangeColor;
			ChangeColor = tmpColor;
		}
		int tmpColor = CurColor;
		CurColor = ChangeColor;
		ChangeColor = tmpColor;
	}
}

void GameBoardManager::Distory()
{
	if (m_hThis)
	{
		delete m_hThis;
		m_hThis = NULL;
	}
}

GameBoardManager::~GameBoardManager()
{
	Distory();
}
