#pragma once
#include"Mecro.h"
#include"Player.h"

#define GameMgr GameManager::Get_Instance()


class GameManager
{
private:
	GameManager();

	static GameManager* m_hThis;

	PieceColor m_CurPlayColor;
	Scene m_CurScene;
	Piece* m_CurChoicePiece;
	Bitmap* m_ClickTileImage;
	std::vector<RECT> m_MoveblePosition;
	MoveDirection m_Direction;

	void TurnChange(PieceColor CurTurnColor);
	void SceneChange(Scene CurScene);

public:
	~GameManager();

	static GameManager* Get_Instance()
	{
		if (m_hThis == NULL)
			m_hThis = new GameManager;
		return m_hThis;
	}
	std::vector<RECT> Get_MovealePostion() { return m_MoveblePosition; }

	void Init(HWND hWnd);
	bool Click_Check(POINT Point);
	void Draw(HDC hdc);
};

