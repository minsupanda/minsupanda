#pragma once
#include"Mecro.h"

#define GameMgr GameManager::Get_Instance()

class GameManager
{
private:
	GameManager();

	static GameManager* m_hThis;
	


public:
	~GameManager();

	static GameManager* Get_Instance()
	{
		if (m_hThis == NULL)
			m_hThis = new GameManager;
		return m_hThis;
	}

	void Init(HWND hWnd);
	bool Click_Check(POINT Point);
	void Draw(HDC hdc);
};

