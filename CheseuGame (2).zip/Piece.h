#pragma once
#include "Mecro.h"
#include "BitmapManager.h"

enum class PieceType
{
	Pawn = 0,
	Rook = 2,
	Knight = 4,
	Bishop = 6,
	Queen = 8,
	King = 10
};

class Piece abstract
{
protected:
	PieceType m_piece;
	PieceColor m_color;
	Bitmap* m_pieceImage;


	int m_ix;
	int m_iy;
	int m_width;
	int m_height;
	RECT m_BitmapRect;

public:
	Piece();
	~Piece();
	
	virtual void MoveCheck(std::vector<MoveDirection>& m_Direction) abstract = 0;
	virtual void CatchPiece() abstract = 0;

	PieceType Get_PieceType() { return m_piece; }
	PieceColor Get_Color() { return m_color; }
	int GetCX() { return m_ix / m_width; }
	int GetCY() { return m_iy / m_height; }

	void Init(int x, int y, int width, int height);
	void Draw(HDC hdc);

	void PositionChange(RECT* m_MoveblePosition);
	void CatchPieceCheck()
};

