#pragma once
#include "Mecro.h"
#include "Piece.h"
#include <vector>

#define PieceMgr PieceManager::Get_Instance()

class PieceManager
{
private:
	PieceManager();
	static PieceManager* m_hThis;

	std::vector<Piece*> Pieces[2];

public:
	static PieceManager* Get_Instance()
	{
		if (m_hThis == NULL)
			m_hThis = new PieceManager;
		return m_hThis;
	}

	void Init();
	
	void Distory();
	~PieceManager();
};

