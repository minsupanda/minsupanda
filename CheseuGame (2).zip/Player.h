#pragma once
#include"Mecro.h"
#include"PieceManager.h"

class Player
{
private:
	PieceColor m_PlayColor;
	std::vector<Piece*> m_Piece;

public:
	Player();
	~Player();

	void Init(std::vector<Piece*> piece, PieceColor color);
	void TurnPlay(POINT point, std::vector<RECT>& m_MoveblePosition);
};

