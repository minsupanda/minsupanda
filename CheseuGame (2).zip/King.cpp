#include "King.h"

King::King() {}
King::King(PieceColor color)
{
	m_piece = PieceType::King;
	m_color = color;
	m_pieceImage = BitmapMgr->Get_Image((int)PieceType::King + (int)color);
}

King::~King()
{
}

void King::MoveCheck(std::vector<RECT>& m_MoveblePosition)
{
}
