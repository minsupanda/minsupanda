#include "Player.h"

Player::Player()
{
}

Player::~Player()
{
}

void Player::Init(std::vector<Piece*> piece, PieceColor color)
{
	m_Piece = piece;
	m_PlayColor = color;
}

void Player::TurnPlay(POINT point, std::vector<RECT>& m_MoveblePosition)
{
	for (Piece* piece : m_Piece)
	{
		if (piece->Point_In_PieceRect_Check(point))
		{
			piece->MoveCheck(m_MoveblePosition);
			return;
		}
	}
	return;
}
