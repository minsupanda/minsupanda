#include "Bitmap.h"

Bitmap::Bitmap()
{
}

void Bitmap::Init(HDC hdc, const char* FileName)
{
	MemDC = CreateCompatibleDC(hdc);
	m_Bitmap = (HBITMAP)LoadImageA(NULL, FileName, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	SelectObject(MemDC, m_Bitmap);

	BITMAP BitMap_Info;
	GetObject(m_Bitmap, sizeof(BitMap_Info), &BitMap_Info);
	m_Size.cx = BitMap_Info.bmWidth;
	m_Size.cy = BitMap_Info.bmHeight;
}

void Bitmap::Draw(HDC hdc, int x, int y, int width, int height)
{
	StretchBlt(hdc, x, y, width, height, MemDC, 0, 0, m_Size.cx, m_Size.cy, SRCCOPY);
}

Bitmap::~Bitmap()
{
}
