#include "FirePot.h"

FirePot::FirePot()
{
}

FirePot::~FirePot()
{
}

void FirePot::Init()
{
	m_Image[0] = BitmapMgr->Get_Image(IMAGE_FIRE_1);
	m_Image[1] = BitmapMgr->Get_Image(IMAGE_FIRE_2);
	m_CurImage = m_Image[0];

	m_Size = *m_Image[0]->Get_Size();

	m_fx = WIDTH * 0.65f;
	m_fy = HEIGHT * 0.69f;

	m_CollisionRect.left = m_fx;
	m_CollisionRect.right = m_fx + m_Size.cx;
	m_CollisionRect.top = m_fy;
	m_CollisionRect.bottom = m_fy + m_Size.cy; 

	m_ScoreRect.left = m_fx;
	m_ScoreRect.right = m_fx + m_Size.cx;
	m_ScoreRect.top = 0;
	m_ScoreRect.bottom = HEIGHT;

	score = FirePot_Score;

	m_CurCharacterCoord = 0;

	m_BackGroundWidth = WIDTH;
}

void FirePot::Draw(HDC m_backDC)
{
	m_CurImage->TransparentDraw(m_backDC, m_fx + m_CurCharacterCoord + (m_BackGroundWidth * m_Number), m_fy, m_Size.cx, m_Size.cy);
	//Rectangle(m_backDC, m_CollisionRect.left, m_CollisionRect.top, m_CollisionRect.right, m_CollisionRect.bottom);
}

void FirePot::Update(float TotalMoveDist, float CurMoveDistance, const float& deltaTime)
{
	Animation(deltaTime);

	if (Character_Move_Coord <= TotalMoveDist) TotalMoveDist = Character_Move_Coord;

	while (TotalMoveDist > m_BackGroundWidth)
		TotalMoveDist -= m_BackGroundWidth;

	m_CurCharacterCoord = -TotalMoveDist;

	m_CollisionRect.left = m_fx + m_CurCharacterCoord + (m_BackGroundWidth * m_Number);
	m_CollisionRect.right = m_fx + m_Size.cx + m_CurCharacterCoord + (m_BackGroundWidth * m_Number);
	m_ScoreRect.left = m_fx + m_CurCharacterCoord + (m_BackGroundWidth * m_Number);
	m_ScoreRect.right = m_fx + m_Size.cx + m_CurCharacterCoord + (m_BackGroundWidth * m_Number);
}

void FirePot::Animation(const float& deltaTime)
{
	m_ImageChangeTime += deltaTime;

	if (m_ImageChangeTime >= FirePotImage_ChangeTime * 0.1f)
	{
		if (m_CurImage == m_Image[0])
			m_CurImage = m_Image[1];
		else
			m_CurImage = m_Image[0];

		m_ImageChangeTime -= FirePotImage_ChangeTime * 0.1f;
	}
}

