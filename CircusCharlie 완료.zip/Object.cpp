#include "Object.h"

Object::Object() {}
Object::~Object() {}


bool Object::ColliderCheck(const RECT* playerRect)
{
	RECT rcDst = { 0 };

	return IntersectRect(&rcDst, playerRect, &m_CollisionRect);
}

bool Object::ScoreUpCheck(const RECT* playerRect)
{
	RECT rcDst = { 0 };

	return IntersectRect(&rcDst, playerRect, &m_ScoreRect);
}



