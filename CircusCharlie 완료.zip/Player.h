#pragma once
#include"Mecro.h"
#include"BitmapManager.h"

#define DEAFULT_X_COORD WIDTH * 0.03f
#define DEAFULT_Y_COORD HEIGHT * 0.66f
#define MAX_Y_COORD 100.0f

enum Direction
{
	None = 0,
	Right = 1,
	Left = -1,
	Up = -1,
	Down = 1
};


enum PlayerImage
{
	Default = 0,
	Back = 1,
	Run = 2,
	Goal1 = 3,
	Goal2 = 4,
	Die = 5,
};

enum PlayerInfo
{
	Max_Life = 3
};

class Player
{
private:
	Bitmap* m_Image[6];
	Bitmap* m_CurImage;

	RECT m_CollisionRect;
	const SIZE* m_Size;
	
	float m_fx;
	float m_fy;

	float m_DefaultX;
	float m_DefaultY;
	float m_MaxY;

	Direction m_DirX;
	Direction m_DirY;

	float m_MoveDistance;
	float m_CurMoveDistance;

	float m_ImageChangeTime;

	int m_Life;

	bool m_Goal;
	bool m_Jump;
	bool isDie;

	void Input(const float& deltaTime);
	void Jump(const float& deltaTime, bool& upscore);
	void Animation(const float& deltaTime);

public:
	Player();
	~Player();

	void Init();

	void Draw(HDC& m_backDC);
	float Update(const float& deltaTime, bool& upscore);
	bool GoalCheck(const RECT* goalrect);

	void LifeDecrease();
	void revival();

	const float Get_MoveDistance() { return m_MoveDistance; }
	const bool Get_Goal() { return m_Goal; }
	RECT* Get_Rect() { return &m_CollisionRect; }
	const int* Get_Life() { return &m_Life; }
	const bool Get_isDie() { return isDie; }
};

