#include "Miter.h"
#include<string>

Miter::Miter() {}
Miter::~Miter() {}

void Miter::Init()
{
	m_MiterImage = BitmapMgr->Get_Image(IMAGE_INTERFACE_METER);
	m_Size = *m_MiterImage->Get_Size();

	m_fx = DEAFULT_X_COORD;
	m_fy = DEAFULT_Y_COORD;

	m_CurMiter = 0;
	m_CurCharacterCoord = 0;
	m_BackGroundWidth = WIDTH;
}

void Miter::Draw(HDC m_backDC)
{
	int miter = 0;
	std::wstring CurMiter = std::to_wstring(m_CurMiter);

	SetBkMode(m_backDC, TRANSPARENT);
	SetTextColor(m_backDC, RGB(255, 255, 255));
	m_MiterImage->TransparentDraw(m_backDC, m_fx + m_CurCharacterCoord + (m_BackGroundWidth * m_Number), m_fy, m_Size.cx, m_Size.cy);
	TextOutW(m_backDC, m_fx + m_CurCharacterCoord + (m_BackGroundWidth * m_Number) + (m_Size.cx * 0.3f), m_fy + (m_Size.cy * 0.2f), CurMiter.c_str(), CurMiter.length());
}


void Miter::Update(float TotalMoveDist, float CurMoveDistance)
{
	m_CurMiter = 10 - (int)(TotalMoveDist / One_Miter) - m_Number;
	m_CurMiter *= 10;
	if (m_CurMiter <= 10)
		m_CurMiter = 10;

	//if (TotalMoveDist > 0 && (int)TotalMoveDist % 900 == 0)
	//{
	//	if(m_CurMiter != 10)
	//		m_CurMiter += 10;
	//}

	if (Character_Move_Coord <= TotalMoveDist) TotalMoveDist = Character_Move_Coord;

	while (TotalMoveDist >= m_BackGroundWidth)
		TotalMoveDist -= m_BackGroundWidth;

	m_CurCharacterCoord = -TotalMoveDist;
}
