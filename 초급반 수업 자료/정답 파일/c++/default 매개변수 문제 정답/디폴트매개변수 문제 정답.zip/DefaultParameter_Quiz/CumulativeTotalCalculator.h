#pragma once
#include "Mecro.h"
#define DEFAULT_MAX 10
class CumulativeTotalCalculator
{
private:
	int m_iMax;
	int m_iCumulativeTotal;
public:
	void Calculation(int _iMax = DEFAULT_MAX);
	void Print();
};

