#include "CumulativeTotalCalculator.h"



void CumulativeTotalCalculator::Calculation(int _iMax)
{
	m_iMax = _iMax;
	if (_iMax < 1)
		m_iMax = DEFAULT_MAX;

	m_iCumulativeTotal = 0;
	for (int i = 1; i <= m_iMax; i++)
		m_iCumulativeTotal += i;
}
void CumulativeTotalCalculator::Print()
{
	cout << "1 ~ " << m_iMax << " �� �� : " << m_iCumulativeTotal << endl;
}