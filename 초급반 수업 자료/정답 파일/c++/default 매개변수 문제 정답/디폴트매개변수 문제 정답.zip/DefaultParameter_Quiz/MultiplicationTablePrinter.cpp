#include "MultiplicationTablePrinter.h"



void MultiplicationTablePrinter::SetMultiplicationTable(int _iStartNum, int _iEndNum)
{
	if (_iStartNum < 2 || _iStartNum > 9)
		_iStartNum = START_NUM;
	if (_iEndNum < 2 || _iEndNum > 9)
		_iEndNum = END_NUM;
	if (_iStartNum > _iEndNum)
	{
		_iStartNum = START_NUM;
		_iEndNum = END_NUM;
	}
	m_iStartNum = _iStartNum;
	m_iEndNum = _iEndNum;
}
void MultiplicationTablePrinter::Print()
{
	for (int i = m_iStartNum; i <= m_iEndNum; i++)
		printf("====%d��====\t", i);
	printf("\n");

	for (int i = 1; i <= 9; i++)
	{
		for (int j = m_iStartNum; j <= m_iEndNum; j++)
			printf("%d x %d = %d\t", j, i, i * j);
		printf("\n");
	}
}