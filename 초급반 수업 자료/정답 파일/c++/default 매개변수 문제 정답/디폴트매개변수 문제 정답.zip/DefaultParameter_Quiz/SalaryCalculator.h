#pragma once
#include"Mecro.h"
#define MINIMUM_WAGE 9160

class SalaryCalculator
{
private:
	int m_iWorkHourlyWage;
	int m_iWorkingHoursOfDay;
	int m_iWorkingDays;
public:
	void SetSalary(int _iWorkingDays, int _iWorkingHoursOfDay = 8, int _iWorkHourlyWage = MINIMUM_WAGE);
	void Print();
};

