#include "SalaryCalculator.h"



void SalaryCalculator::SetSalary(int _iWorkingDays, int _iWorkingHoursOfDay, int _iWorkHourlyWage)
{
	m_iWorkHourlyWage = _iWorkHourlyWage;
	if (m_iWorkHourlyWage < MINIMUM_WAGE)
		m_iWorkHourlyWage = MINIMUM_WAGE;
	m_iWorkingDays = _iWorkingDays;
	m_iWorkingHoursOfDay = _iWorkingHoursOfDay;
}
void SalaryCalculator::Print()
{
	cout << "�ñ� : " << m_iWorkHourlyWage << endl;
	cout << "���� �ð� : " << m_iWorkingHoursOfDay << "�ð�";
	cout << " ���� ��¥ : " << m_iWorkingDays << "��" << endl;
	cout << "�� �޿� : " << m_iWorkingDays * m_iWorkingHoursOfDay * m_iWorkHourlyWage << "��" << endl;
}