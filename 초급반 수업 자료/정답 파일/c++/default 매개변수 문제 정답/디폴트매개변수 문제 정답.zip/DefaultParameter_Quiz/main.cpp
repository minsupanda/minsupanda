#pragma once
#include"CumulativeTotalCalculator.h"
#include"MultiplicationTablePrinter.h"
#include"SalaryCalculator.h"
#include<Windows.h>


void main()
{
	SalaryCalculator salaryCalculator;
	CumulativeTotalCalculator cumulativeTotalCalculator;
	MultiplicationTablePrinter multiplicationTablePrinter;
	while (true)
	{
		system("cls");
		cout << "DefaultParameter ����" << endl;
		cout << "1.�޿����" << endl;
		cout << "2.�����հ�" << endl;
		cout << "3.���������" << endl;
		cout << "4.����" << endl;
		cout << "���� : ";
		int iSelect;
		cin >> iSelect;
		switch (iSelect)
		{
		case 1:
		{
			int iDay;
			cout << "�ٹ��ϼ� : ";
			cin >> iDay;
			cout << "�ð��� �ӱ��� �Է��Ͻðڽ��ϱ�?(y/n) : ";
			char chStatus;
			cin >> chStatus;
			if (chStatus == 'n')
			{
				salaryCalculator.SetSalary(iDay);
				salaryCalculator.Print();
			}
			else
			{
				cout << "�ٹ��ð� : ";
				int iHour;
				cin >> iHour;
				cout << "�ñ� : ";
				int iHourlyWage;
				cin >> iHourlyWage;
				salaryCalculator.SetSalary(iDay, iHour, iHourlyWage);
				salaryCalculator.Print();
			}
		}
			break;
		case 2:
		{
			cout << "������ �Է��Ͻðڽ��ϱ�?(y/n) : ";
			char chStatus;
			cin >> chStatus;
			if (chStatus == 'n')
			{
				cumulativeTotalCalculator.Calculation();
				cumulativeTotalCalculator.Print();
			}
			else
			{
				cout << "�����Է� : ";
				int iMax;
				cin >> iMax;
				cumulativeTotalCalculator.Calculation(iMax);
				cumulativeTotalCalculator.Print();
			}
		}
			break;
		case 3:
		{
			cout << "���۴ܰ� ������ �Է��Ͻðڽ��ϱ�?(y/n) : ";
			char chStatus;
			cin >> chStatus;
			if (chStatus == 'n')
			{
				multiplicationTablePrinter.SetMultiplicationTable();
				multiplicationTablePrinter.Print();
			}
			else
			{
				int StartNum;
				cout << "���۴� �Է� : ";
				cin >> StartNum;

				int EndNum;
				cout << "���� �Է� : ";
				cin >> EndNum;
				multiplicationTablePrinter.SetMultiplicationTable(StartNum, EndNum);
				multiplicationTablePrinter.Print();
			}
		}
			break;
		case 4:
			return;
		}
		system("pause");
	}
}