#pragma once
#include"Mecro.h"
#define START_NUM 2
#define END_NUM 9
class MultiplicationTablePrinter
{
private:
	int m_iStartNum;
	int m_iEndNum;
public:
	void SetMultiplicationTable(int _iStartNum = START_NUM, int _iEndNum = END_NUM);
	void Print();
};

