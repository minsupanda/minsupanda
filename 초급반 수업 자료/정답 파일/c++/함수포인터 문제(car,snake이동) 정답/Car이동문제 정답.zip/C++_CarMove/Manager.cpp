#include "Manager.h"


Manager::Manager()
{
	Time_Create_NewCar.SetTimer(TIMER_TYPE_LOOP, TIME_CREATE_NEWCAR, std::bind(&Manager::CreateCar, this));
}
void Manager::PlayLoop()
{
	CarList.push_back(new Car);
	while (true)
	{
		Input();
		CreateCarTimer();
		CarMoveController();
	}
}

void Manager::Input()
{
	if (kbhit()) // �ӵ� ����
	{
		if (getch() == MOVE_FASTMODE)
		{
			for (std::list<Car*>::iterator iter = CarList.begin(); iter != CarList.end(); iter++)
				(*iter)->Set_ModeChange();
		}
	}
}

void Manager::CreateCarTimer()
{
	// ����(list �߰�)
	Time_Create_NewCar.CheckTimer();
}

void Manager::CreateCar()
{
	CarList.push_back(new Car);
}


void Manager::CarMoveController()
{
	// �̵�
	for (std::list<Car*>::iterator iter = CarList.begin(); iter != CarList.end(); )
	{
		(*iter)->Move_Car();
		if ((*iter)->EraseCheck_Car()) {
			Car* DeleteCar = *iter;
			iter = CarList.erase(iter);
			delete DeleteCar;
		}
		else
			iter++;
	}
}

Manager::~Manager()
{

	for (std::list<Car*>::iterator iter = CarList.begin(); iter != CarList.end(); )
		delete* iter;

}