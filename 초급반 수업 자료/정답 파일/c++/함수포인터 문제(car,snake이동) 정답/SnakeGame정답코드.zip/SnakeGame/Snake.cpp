#include "Snake.h"
#include"ColliderManager.h"


Snake::Snake()
{

}
Snake::~Snake()
{

}
bool Snake::ColliderCheck(Block _block)
{
	for (Block block : m_vecTailList)
	{
		if (block.Compare(_block) == true)
			return true;
	}
	return false;
}
void Snake::Init()
{
	m_vecTailList.clear();
	m_bLifeStatus = true;
	m_eDirection = DIRECTION::NON;
	m_Head.Init(WIDTH / 2, HEIGHT / 2, BLOCK_TYPE::HEAD);
	m_Head.Draw();
	m_MoveTimer.SetTimer(TIMER_TYPE::TIMER_TYPE_LOOP, 
						DEFAULT_SPEED - (m_vecTailList.size() * SPEED_UP_VALUE), 
						bind(&Snake::Move,this));
	DrawScore();
}


void Snake::MoveTimerCheck()
{
	m_MoveTimer.CheckTimer();
}

void Snake::Input()
{
	if (kbhit())
	{
		char ch = getch();
		switch ((KEY)ch)
		{
		case KEY::LEFT:
			if (m_eDirection == DIRECTION::RIGHT)
				break;
			m_eDirection = DIRECTION::LEFT;
			break;
		case KEY::RIGHT:
			if (m_eDirection == DIRECTION::LEFT)
				break;
			m_eDirection = DIRECTION::RIGHT;
			break;
		case KEY::UP:
			if (m_eDirection == DIRECTION::DOWN)
				break;
			m_eDirection = DIRECTION::UP;
			break;
		case KEY::DOWN:
			if (m_eDirection == DIRECTION::UP)
				break;
			m_eDirection = DIRECTION::DOWN;
			break;
		}
	}
}

void Snake::Move()
{
	if (m_eDirection == DIRECTION::NON)
		return;
	m_PrevPosition = m_Head;
	switch (m_eDirection)
	{
	case DIRECTION::LEFT:
		m_Head.AddPosition(-1, 0);
		break;
	case DIRECTION::RIGHT:
		m_Head.AddPosition(1, 0);
		break;
	case DIRECTION::UP:
		m_Head.AddPosition(0, -1);
		break;
	case DIRECTION::DOWN:
		m_Head.AddPosition(0, 1);
		break;
	}

	for (vector<Block>::iterator iter = m_vecTailList.begin(); iter != m_vecTailList.end(); iter++)
	{
		Block tmp = *iter;
		iter->CopyPosition(m_PrevPosition);
		m_PrevPosition = tmp;
	}

	if (ColliderManager::GetInstance()->ColliderCheck(m_Head) || ColliderManager::GetInstance()->WallCheck(m_Head)
		|| ColliderCheck(m_Head))
		m_bLifeStatus = false;
	else
	{
		if (ColliderManager::GetInstance()->FoodCheck(m_Head,true))
			CreateTail();
		Draw();
	}
}


void Snake::CreateTail()
{
	if(m_vecTailList.size() * SPEED_UP_VALUE > MAX_SPPED)
		m_MoveTimer.SetTimer(DEFAULT_SPEED - (m_vecTailList.size() * SPEED_UP_VALUE));
	m_PrevPosition.SetType(BLOCK_TYPE::TAIL);
	m_vecTailList.push_back(m_PrevPosition);
	DrawScore();
}


void Snake::DrawScore()
{
	DrawManager::DrawMidText("Score : " + to_string(m_vecTailList.size()), WIDTH, HEIGHT + 1);
}

void Snake::Draw()
{
	m_Head.Draw();
	for (Block b : m_vecTailList)
		b.Draw();
	m_PrevPosition.Erase();
}