#pragma once
#include<vector>
#include<list>
#include"Block.h"
#include"Timer.h"
#define FOOD_CREATE_SECOUND 1000
#define MAX_FOOD 10
class ColliderManager
{
private:
	vector<Block> m_vecColliderList;
	vector<Block> m_vecWallList;
	list<Block> m_listFoodList;
	Timer m_foodCreateTimer;
	static ColliderManager* m_hThis;
public:
	static ColliderManager* GetInstance()
	{
		if (m_hThis == NULL) m_hThis = new ColliderManager;
		return m_hThis;
	}
	ColliderManager();
	~ColliderManager();
	void CreateRandomCollider();
	void CreateRandomFood();
	bool ColliderCheck(int _ix, int _iy);
	bool FoodCheck(int _ix, int _iy);
	bool WallCheck(int _ix, int _iy);
	bool ColliderCheck(Block block);
	bool FoodCheck(Block block,bool DeleteStatus = false);
	bool WallCheck(Block block);
	void DrawWall();
	void DrawCollider();
	void SetFoodTimer();
	void FoodTimerCheck();
};

