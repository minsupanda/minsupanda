#include "GameManager.h"


void GameManager::MainLoop()
{
	srand(time(NULL));
	while (true)
	{
		system("cls");
		ColliderManager::GetInstance()->DrawWall();
		DrawManager::DrawMidText("S n a k e  G a m e", WIDTH, HEIGHT * 0.3);
		DrawManager::DrawMidText("1.Game Start", WIDTH, HEIGHT * 0.4);
		DrawManager::DrawMidText("2.Exit", WIDTH, HEIGHT * 0.5);
		DrawManager::DrawMidText("Select : ", WIDTH, HEIGHT * 0.7);
		int Select;
		cin >> Select;
		switch (Select)
		{
		case 1:
			PlayGame();
			break;
		case 2:
			return;
		}
	}
}


void GameManager::PlayGame()
{
	ColliderManager::GetInstance()->CreateRandomCollider();
	system("cls");
	ColliderManager::GetInstance()->DrawWall();
	ColliderManager::GetInstance()->DrawCollider();
	ColliderManager::GetInstance()->SetFoodTimer();
	m_Snake.Init();
	while (m_Snake.GetLife())
	{
		m_Snake.Input();
		m_Snake.MoveTimerCheck();
		ColliderManager::GetInstance()->FoodTimerCheck();
	}
	DrawManager::DrawMidText("G a m e  O v e r", WIDTH, HEIGHT * 0.3);
	DrawManager::DrawMidText("Score : " + to_string(m_Snake.GetScore()), WIDTH, HEIGHT * 0.5);
	DrawManager::DrawMidText("Press Key", WIDTH, HEIGHT * 0.7);
	getch();

}
GameManager::GameManager()
{
	char buf[256];
	sprintf(buf, "mode con: lines=%d cols=%d", HEIGHT + 3, WIDTH * 2 + 1);
	system(buf);
}
GameManager::~GameManager()
{
	delete ColliderManager::GetInstance();
}