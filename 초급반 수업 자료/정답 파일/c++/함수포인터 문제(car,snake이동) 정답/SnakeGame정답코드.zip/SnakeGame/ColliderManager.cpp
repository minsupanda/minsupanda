#include "ColliderManager.h"

ColliderManager* ColliderManager::m_hThis = NULL;

ColliderManager::ColliderManager()
{
	Block block;
	for (int x = 0; x < WIDTH; x++)
	{
		block.Init(x, 0,BLOCK_TYPE::COLLIDER);
		m_vecWallList.push_back(block);
		block.Init(x, HEIGHT-1,BLOCK_TYPE::COLLIDER);
		m_vecWallList.push_back(block);
	}

	for (int y = 0; y < HEIGHT; y++)
	{
		block.Init(0, y, BLOCK_TYPE::COLLIDER);
		m_vecWallList.push_back(block);
		block.Init(WIDTH - 1, y, BLOCK_TYPE::COLLIDER);
		m_vecWallList.push_back(block);
	}
}

void ColliderManager::DrawWall()
{
	for (Block b : m_vecWallList)
	{
		b.Draw();
	}
}
ColliderManager::~ColliderManager()
{

}


void ColliderManager::FoodTimerCheck()
{
	m_foodCreateTimer.CheckTimer();
}

void ColliderManager::SetFoodTimer()
{
	m_listFoodList.clear();
	m_foodCreateTimer.SetTimer(TIMER_TYPE::TIMER_TYPE_LOOP, FOOD_CREATE_SECOUND, bind(&ColliderManager::CreateRandomFood, this));
}


bool ColliderManager::ColliderCheck(int _ix, int _iy)
{
	for (Block b : m_vecColliderList)
	{
		if (b.Compare(_ix, _iy))
			return true;
	}
	return false;
}
bool ColliderManager::FoodCheck(int _ix, int _iy)
{
	for (Block b : m_listFoodList)
	{
		if (b.Compare(_ix, _iy))
			return true;
	}
	return false;
}
bool ColliderManager::WallCheck(int _ix, int _iy)
{
	for (Block b : m_vecWallList)
	{
		if (b.Compare(_ix, _iy))
			return true;
	}
	return false;
}


bool ColliderManager::ColliderCheck(Block block)
{
	for (Block b : m_vecColliderList)
	{
		if (b.Compare(block))
			return true;
	}
	return false;
}
bool ColliderManager::FoodCheck(Block block, bool DeleteStatus)
{
	for (list<Block>::iterator iter = m_listFoodList.begin(); iter != m_listFoodList.end(); iter++)
	{
		if (iter->Compare(block))
		{
			if (DeleteStatus)
				m_listFoodList.erase(iter);
			return true;
		}
	}
	return false;
}
bool ColliderManager::WallCheck(Block block)
{
	for (Block b : m_vecWallList)
	{
		if (b.Compare(block))
			return true;
	}
	return false;
}

void ColliderManager::CreateRandomFood()
{
	if (m_listFoodList.size() >= MAX_FOOD)
		return;
	int x = rand() % (WIDTH - 2) + 1;
	int y = rand() % (HEIGHT - 2) + 1;
	if (ColliderCheck(x, y) == false && FoodCheck(x,y) == false)
	{
		Block block;
		block.Init(x, y, BLOCK_TYPE::FOOD);
		m_listFoodList.push_back(block);
		block.Draw();
	}
}

void ColliderManager::CreateRandomCollider()
{
	m_vecColliderList.clear();
	int ColliderCount = WIDTH * HEIGHT * 0.05;

	Block block;
	for (int i = 0; i < ColliderCount;)
	{
		int x = rand() % (WIDTH - 2) + 1;
		int y = rand() % (HEIGHT - 2) + 1;
		if (ColliderCheck(x, y) == false && x != WIDTH / 2 && y != HEIGHT / 2)
		{
			block.Init(x, y, BLOCK_TYPE::COLLIDER);
			m_vecColliderList.push_back(block);
			i++;
		}
	}
}


void ColliderManager::DrawCollider()
{
	for (Block b : m_vecColliderList)
	{
		b.Draw();
	}
}