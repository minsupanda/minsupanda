#include"GameManager.h"

void main()
{
	GameManager m_gameManager;
	m_gameManager.GameMain();
}