#include "GameManager.h"



GameManager::GameManager()
{
	m_iTurn = 1;
	m_iHeight = HEIGHT;
	m_iWidth = WIDTH;
	m_eGameType = GAMETYPE::FIVE_IN_A_ROW;
}

void GameManager::LobbyDraw()
{
	switch (m_eGameType)
	{
	case GAMETYPE::FIVE_IN_A_ROW:
		DrawManager::DrawMidText("�� �� �� ��", m_iWidth, m_iHeight * 0.3f);
		break;
	case GAMETYPE::OTHELLO:
		DrawManager::DrawMidText("�� �� �� �� ��", m_iWidth, m_iHeight * 0.3f);
		break;
	default:
		break;
	}
	int iMenuCount = 1;
	float fHeightRatio = 0.4f;
	DrawManager::DrawMidText(to_string(iMenuCount++) +  ".���� ����", m_iWidth, m_iHeight * fHeightRatio);
	fHeightRatio += 0.1f;
	if (ContinueFileCheck())
	{
		DrawManager::DrawMidText(to_string(iMenuCount++) + ".�̾� �ϱ�", m_iWidth, m_iHeight * fHeightRatio);
		fHeightRatio += 0.1f;
	}
	DrawManager::DrawMidText(to_string(iMenuCount++) + ".���� ����", m_iWidth, m_iHeight * fHeightRatio);
	fHeightRatio += 0.1f;
	DrawManager::DrawMidText(to_string(iMenuCount++) + ".���� ����", m_iWidth, m_iHeight * fHeightRatio);
	fHeightRatio += 0.1f;
	DrawManager::BoxDraw(m_iWidth, m_iHeight * fHeightRatio, m_iWidth / 2, 3);
	DrawManager::gotoxy(m_iWidth, m_iHeight * fHeightRatio + 1);
}

void GameManager::InputInfoDraw()
{
	if (m_eGameType == GAMETYPE::FIVE_IN_A_ROW)
		DrawManager::DrawMidText("====�� ��====", m_iWidth, m_iHeight);
	else
		DrawManager::DrawMidText("====�� �� ��====", m_iWidth, m_iHeight);
	DrawManager::DrawMidText("�̵� : A,S,W,D ������ : ENTER", m_iWidth, m_iHeight + 1);
	if(m_eGameType == GAMETYPE::FIVE_IN_A_ROW)
		DrawManager::DrawMidText("������ : N ���� : ESC", m_iWidth, m_iHeight + 2);
	else
		DrawManager::DrawMidText("���� : ESC", m_iWidth, m_iHeight + 2);
}

void GameManager::CurPlayerInfoDraw()
{
	string Name = m_iTurn % 2 == (int)PLAYERTYPE::BLACK ? "Black" : "While";
	int UndoCount = m_Players[m_iTurn % 2].GetUndoCount();
	string str;
	if (m_eGameType == GAMETYPE::FIVE_IN_A_ROW)
		str = "Player Name : " + Name + "       ������ : " + to_string(UndoCount) + "  ";
	else
		str = "Player Name : " + Name;
	DrawManager::DrawMidText(str, m_iWidth, m_iHeight + 3);
	DrawManager::DrawMidText("Turn : " + to_string(m_iTurn) + "  ", m_iWidth, m_iHeight + 4);
}

void GameManager::GameMain()
{
	char buf[256];
	sprintf(buf, "mode con: lines=%d cols=%d", m_iHeight + 5, (m_iWidth * 2) + 1);
	system(buf);
	while (1)
	{
		system("cls");
		DrawManager::DrawPanel(m_iWidth, m_iHeight);
		LobbyDraw();
		int Select;
		cin >> Select;
		if (Select == 1)
		{
			NewStartInit();
			Play();
		}
		else if (ContinueFileCheck())
		{
			if (Select == 2)
			{
				ContinueInit();
				Play();
			}
			else if (Select == 3)
				ModeChange();
			else if (Select == 4)
				return;
		}
		else
		{
			if (Select == 2)
				ModeChange();
			else if (Select == 3)
				return;
		}
	}
}

void GameManager::ModeChange()
{
	if (m_eGameType == GAMETYPE::FIVE_IN_A_ROW)
		m_eGameType = GAMETYPE::OTHELLO;
	else
		m_eGameType = GAMETYPE::FIVE_IN_A_ROW;
}
bool GameManager::ContinueFileCheck()
{
	ifstream load;
	load.open(CONTINUE_FILE_NAME);
	if (load.is_open())
	{
		int status;
		load >> status;
		load.close();
		if (status == -1)
			return false;
		else
			return true;
	}
	return false;
}


void GameManager::NewStartInit()
{
	m_saveFile.open(CONTINUE_FILE_NAME);
	m_saveFile << (int)m_eGameType << endl;
	m_saveFile.close();
	m_iTurn = 1;
	m_Players[(int)PLAYERTYPE::BLACK].Init(m_iWidth, m_iHeight, PLAYERTYPE::BLACK, this);
	m_Players[(int)PLAYERTYPE::WHITE].Init(m_iWidth, m_iHeight, PLAYERTYPE::WHITE, this);
}


void GameManager::ContinueInit()
{

	ifstream load;
	m_Players[(int)PLAYERTYPE::BLACK].Init(m_iWidth, m_iHeight, PLAYERTYPE::BLACK, this);
	m_Players[(int)PLAYERTYPE::WHITE].Init(m_iWidth, m_iHeight, PLAYERTYPE::WHITE, this);
	load.open(CONTINUE_FILE_NAME);
	if (load.is_open())
	{
		int iGameType;
		load >> iGameType;
		if (iGameType == -1)
		{
			load.close();
			return;
		}
		m_eGameType = (GAMETYPE)iGameType;
		string buff;
		string saveBuff;
		int iTurn = 1;
		while(true) 
		{
			load >> buff;
			if (buff == "undo" || buff == "end")
				break;
			int ix, iy;
			load >> ix >> iy;
			saveBuff += buff + " " + to_string(ix) + " " + to_string(iy) + "\n";
			if (stoi(buff) == (int)KEY::DROP)
			{
				m_Players[iTurn % 2].StoneSet(ix, iy);
				if (iTurn % 2 == (int)PLAYERTYPE::BLACK)
					m_Players[iTurn % 2].SetCursorPosition(ix, iy, BLACKTEAMICON);
				else
					m_Players[iTurn % 2].SetCursorPosition(ix, iy, WHITETEAMICON);
				m_Players[iTurn % 2].WinCheck(m_eGameType, &m_Players[!(iTurn % 2)], m_iWidth * m_iHeight);
				iTurn++;
			}
			else if (stoi(buff) == (int)KEY::UNDO)
			{
				iTurn--;
				m_Players[iTurn % 2].DeleteStone(ix, iy);
			}
		}
		if (buff == "undo")
		{
			int undoCount;
			load >> undoCount;
			m_Players[(int)PLAYERTYPE::BLACK].SetUndoCount(undoCount);
			load >> undoCount;
			m_Players[(int)PLAYERTYPE::WHITE].SetUndoCount(undoCount);
			load >> buff;
			if (buff == "undoStone")
			{
				int ix, iy;
				load >> ix >> iy;
				m_Players[iTurn % 2].SetUndoStone(ix, iy);
			}
		}
		load.close();
		m_saveFile.open(CONTINUE_FILE_NAME);
		m_saveFile << (int)m_eGameType << endl;
		m_saveFile << saveBuff;
		m_saveFile.close();
		m_iTurn = iTurn;
	}
}
void GameManager::Play()
{
	m_saveFile.open(CONTINUE_FILE_NAME, ios::app);
	system("cls");
	DrawManager::DrawPanel(m_iWidth, m_iHeight);
	InputInfoDraw();
	m_Players[(int)PLAYERTYPE::BLACK].AllStoneDraw();
	m_Players[(int)PLAYERTYPE::WHITE].AllStoneDraw();
	while (true)
	{
		CurPlayerInfoDraw();
		switch (m_Players[m_iTurn % 2].Input(&m_Players[!(m_iTurn % 2)], m_iTurn, m_eGameType, &m_saveFile))
		{
		case KEY::ESC:
			if (m_eGameType == GAMETYPE::FIVE_IN_A_ROW)
			{
				m_saveFile << "undo" << endl;
				m_saveFile << m_Players[(int)PLAYERTYPE::BLACK].GetUndoCount() << " ";
				m_saveFile << m_Players[(int)PLAYERTYPE::WHITE].GetUndoCount();
				Stone undoStone = m_Players[m_iTurn % 2].GetUndoStone();
				if (undoStone.isDisabled() == false)
				{
					m_saveFile << endl << "undoStone" << endl << to_string(undoStone.GetX()) << " " << to_string(undoStone.GetY());
				}
				m_saveFile << endl << "end";
			}
			else
				m_saveFile << "end";
			m_saveFile.close();
			return;
		case KEY::DROP:
			m_iTurn++;
			break;
		case KEY::UNDO:
			if (m_iTurn > 1)
			{
				m_iTurn--;
				m_Players[m_iTurn % 2].UndoSet(&m_saveFile);
			}
			break;
		case KEY::WIN:
			if (m_eGameType == GAMETYPE::FIVE_IN_A_ROW)
			{
				if (m_iTurn % 2 == (int)PLAYERTYPE::BLACK)
					DrawManager::DrawMidText("Black Win", m_iWidth, m_iHeight * 0.5f);
				else
					DrawManager::DrawMidText("White Win", m_iWidth, m_iHeight * 0.5f);
			}
			else
			{
				if(m_Players[(int)PLAYERTYPE::BLACK].GetStoneCount() > m_Players[(int)PLAYERTYPE::WHITE].GetStoneCount())
					DrawManager::DrawMidText("Black Win", m_iWidth, m_iHeight * 0.5f);
				else
					DrawManager::DrawMidText("White Win", m_iWidth, m_iHeight * 0.5f);
			}
			m_saveFile.close();
			SaveFile();
			getch();
			return;
		}
	}
}


void GameManager::SaveFile()
{
	string buff;
	ifstream load;
	ofstream save;
	load.open(CONTINUE_FILE_NAME);
	if (load.is_open())
	{
		load.seekg(0, ios::end);
		int size = load.tellg();
		buff.resize(size);
		load.seekg(0, ios::beg);
		load.read(&buff[0], size);
		load.close();
		save.open(SAVE_FILE_NAME);
		save << buff;
		save.close();
		save.open(CONTINUE_FILE_NAME);
		save << "-1";
		save.close();
	}
}

GameManager::~GameManager()
{
}
