#pragma once
#include"Mecro.h"
#include"DrawManager.h"
#include"Player.h"

#define CONTINUE_FILE_NAME "Continue.txt"
#define SAVE_FILE_NAME "Save.txt"

enum class OPTIONMENU
{
	MAPSIZE = 1,
	CURSOR,
	STONE,
	UNDO,
	RETURN
};

enum class LOBBYMENU
{
	START = 1,
	OPTION,
	EXIT
};


class GameManager
{
private:
	int m_iTurn;
	int m_iWidth;
	int m_iHeight;
	Player m_Players[(int)PLAYERTYPE::END];
	GAMETYPE m_eGameType;
	ofstream m_saveFile;
public:
	void CurPlayerInfoDraw();
	void InputInfoDraw();
	void LobbyDraw();
	void GameMain();
	void Play(); 
	bool ContinueFileCheck();
	void NewStartInit();
	void ContinueInit();
	void ModeChange();
	void SaveFile();
	inline int GetWidth() { return m_iWidth; }
	inline int GetHeight() { return m_iHeight; }
	GameManager();
	~GameManager();
};

