#include "PhoneNumber.h"

void main()
{
	PhoneNumber CreateNumber;
	CreateNumber.InputNumber();
	CreateNumber.Print();
}
