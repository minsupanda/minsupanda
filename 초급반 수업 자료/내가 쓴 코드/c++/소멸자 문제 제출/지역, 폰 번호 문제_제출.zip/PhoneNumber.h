#pragma once
#include<iostream>
#include<string>
#include<Windows.h>
using namespace std;

#define SMART_NUMBER '1'
#define SEOUL_NUMBER '2'
#define LEGION_NUMBER '6'
#define SEOUL_LENGTH 9
#define LEGION_LENGTH 10
#define SMART_LENGTH 11


class PhoneNumber
{
private:
	char* m_iCreateNumber;
	// string* m_iCreateNumber;
public:
	PhoneNumber();
	void InputNumber();
	bool NumberCheck(string _iNumber);
	bool LegionCheck(char _chSecond, char _chThird);
	bool PhoneCheck(char _chThird);
	void CreateNumber(string _iNumber);
	void Print();
	~PhoneNumber();
};