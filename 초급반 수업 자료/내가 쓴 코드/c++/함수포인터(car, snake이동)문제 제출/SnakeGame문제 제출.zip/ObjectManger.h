#pragma once
#include"Mecro.h"
#include"Timer.h"

struct Objects
{
	OBJECT ObjectName;
	std::string m_Shape;
	std::vector<Position> m_Position;
	int m_XRange;
	int m_YRange;
	int m_CurCount;
	int m_MaxCount;
};

class ObjectManger
{
private:
	Objects m_Wall;
	Objects m_TailItem;
	Timer m_TailItem_Timer;
public:
	ObjectManger();
	void Init();
	void Timer_Check(OBJECT _Object);
	void Object_Create(Objects* _Object);
	bool Position_Overlap_Check(Position _Tmp);
	bool Object_Position_Compare(Objects _ComPareObject, Position _Tmp);
	void Object_Clear(Objects* _Object, Position _Position);
	inline Objects* Object_Adress(OBJECT _Object)
	{
		switch (_Object)
		{

		case OBJECT::WALL:
			return &m_Wall;

		case OBJECT::TAIL:
			return &m_TailItem;
		}
	}
	inline void Game_Reset()
	{
		m_Wall.m_Position.clear();
		m_TailItem.m_Position.clear();
	}
	~ObjectManger();
};
