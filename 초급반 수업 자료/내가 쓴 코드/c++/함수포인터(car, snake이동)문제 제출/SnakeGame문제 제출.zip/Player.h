#pragma once
#include"Mecro.h"
#include"ObjectManger.h"

typedef struct Snake
{
	std::string Shpae;
	Position m_Position;
	Position m_PrePosition;
};

class Player
{
private:
	Timer m_Move_Timer;
	std::list<Snake> m_Snake;
	KEY m_Move_Direction;
	int m_iTailCount = 0;
	int m_iSpeed;
public:
	Player();
	void Init();
	void Input(char _Direction);
	void MoveTimeCheck();
	void Move();
	void Snake_Move();
	void Snake_Erase();
	void Snake_Draw();
	bool Position_Check(ObjectManger& _ObjectManger, Score& _Score);
	bool Position_Overlap(Objects _Object);
	void Tail_Plus();
	inline void Speed_Change()
	{
		if (m_iSpeed >= 300)
		{
			m_iSpeed -= 30;
			m_Move_Timer.TimerChange(m_iSpeed);
		}
	}
	inline void Game_Reset()
	{
		m_Snake.clear();
	}
	~Player();
};

