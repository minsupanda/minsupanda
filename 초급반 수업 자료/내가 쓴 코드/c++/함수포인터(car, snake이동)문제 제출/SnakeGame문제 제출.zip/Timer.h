#pragma once
#include<functional>
#include"Mecro.h"

class Timer
{
private:
	int m_iTimeScale;
	int m_OldClock;
	bool m_bTimerOnOff;
	TIMER_TYPE m_TimerType;
	std::function<void()> m_callbackFunc;
public:
	Timer();
	void SetTimer(std::function<void()> m_callbackFun, TIMER_TYPE _TimerType, bool _bTimerOnOFF, int _iTimer);
	void TimerCheck();
	inline void TimerChange(int _Timer)
	{
		m_iTimeScale = _Timer;
	}
	~Timer();
};

