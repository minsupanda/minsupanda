#include"GameManager.h"

void main()
{
	GameManager game;
	game.MainMenu();
}
