#pragma once
#include<iostream>
#include<Windows.h>
#include<string>

class DrawManager
{
public:
	static void gotoxy(int x, int y)
	{
		COORD Pos = { x, y };
		SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), Pos);
	}
	static void DrawPanel(int Width, int Height)
	{
		for (int y = 0; y < Height; y++)
		{
			for (int x = 0; x < Width; x++)
			{
				if (y == 0 || y == Height - 1)
					std::cout << "��";
				else if (x == 0 || x == Width - 1)
					std::cout << "��";
				else
					std::cout << "  ";
			}
			std::cout << std::endl;
		}
	}
	static void DrawMidText(std::string str, int x, int y)
	{
		if (x < str.size() / 2)
			x -= str.size() / 2;
		gotoxy(x, y);
		std::cout << str;
	}

	static void TextDraw(std::string str, int x, int y)
	{
		gotoxy(x * 2, y);
		std::cout << str;
	}

	static void TextErase(int x, int y)
	{
		gotoxy(x * 2, y);
		std::cout << "  ";
	}
	
};