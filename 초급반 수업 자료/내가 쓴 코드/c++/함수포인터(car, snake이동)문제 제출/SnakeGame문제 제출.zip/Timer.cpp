#include "Timer.h"

Timer::Timer()
{
}

void Timer::SetTimer(std::function<void()> m_callbackFun, TIMER_TYPE _TimerType, bool _bTimerOnOFF, int _iTimer)
{
	m_callbackFunc = m_callbackFun;
	m_TimerType = _TimerType;
	m_iTimeScale = _iTimer;
	m_bTimerOnOff = _bTimerOnOFF;
	m_OldClock = clock();
}

void Timer::TimerCheck()
{
	if (m_bTimerOnOff == true && clock() - m_OldClock >= m_iTimeScale)
	{
		m_callbackFunc();
		switch ((int)m_TimerType)
		{
		case (int)TIMER_TYPE::TIMER_TYPE_LOOP:
			m_OldClock = clock();
			return;

		default: break;
		}
	}
}

Timer::~Timer()
{

}
