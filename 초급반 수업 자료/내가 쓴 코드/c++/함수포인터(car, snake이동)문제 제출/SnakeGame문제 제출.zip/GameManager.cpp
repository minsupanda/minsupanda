#include "GameManager.h"


GameManager::GameManager()
{
	srand(time(NULL));
	m_MapSize.m_iWidth = WIDTH;
	m_MapSize.m_iHeight = HEIGHT;
	m_Score.m_iScore = 0;
	m_Score.m_ScoreChange = false;
	char buf[256];
	sprintf(buf, "mode con: cols=%d lines=%d", m_MapSize.m_iWidth * 2 + 1, m_MapSize.m_iHeight + 3);
	system(buf);
}

void GameManager::LobbyDraw()
{
	DrawManager::DrawPanel(m_MapSize.m_iWidth, m_MapSize.m_iHeight);
	DrawManager::DrawMidText("S n a k e  G a m e", m_MapSize.m_iWidth, m_MapSize.m_iHeight * 0.3f);
	DrawManager::DrawMidText("1. Game Start", m_MapSize.m_iWidth, m_MapSize.m_iHeight * 0.4f);
	DrawManager::DrawMidText("2. Exit", m_MapSize.m_iWidth, m_MapSize.m_iHeight * 0.5f);
	DrawManager::DrawMidText("Select : ", m_MapSize.m_iWidth, m_MapSize.m_iHeight * 0.8f);
}

void GameManager::MainMenu()
{
	while (1)
	{
		LobbyDraw();
		int iSelect;
		std::cin >> iSelect;
		switch (iSelect)
		{
		case 1:
			system("cls");
			MapSetting();
			GameStart();
			break;

		case 2:
			return;
			
		default: break;
		}
	}
}

void GameManager::MapSetting()
{
	DrawManager::DrawPanel(m_MapSize.m_iWidth, m_MapSize.m_iHeight);
	Ui_Draw();
	m_ObjectManger.Init();
	m_Player.Init();
}

void GameManager::Ui_Draw()
{
	char buf[256];
	sprintf(buf, "Score = %d", m_Score.m_iScore);
	DrawManager::DrawMidText(buf, m_MapSize.m_iWidth, m_MapSize.m_iHeight + 1);
}

void GameManager::GameStart()
{
	MainLoop();
	DrawManager::DrawMidText("���� ���� (�ƹ� Ű�� �Է��ϼ���)", m_MapSize.m_iWidth, m_MapSize.m_iHeight * 0.5f);
	getch();
	m_ObjectManger.Game_Reset();
	m_Player.Game_Reset();
	m_Score.m_iScore = 0;
	m_Score.m_ScoreChange = false;
	system("cls");
}

void GameManager::MainLoop()
{
	while (1)
	{
		if (m_Player.Position_Check(m_ObjectManger, m_Score) == false)
			return;

		else if(m_Score.m_ScoreChange == true)
		{
			Ui_Draw();
			m_Score.m_ScoreChange = false;
		}

		m_ObjectManger.Timer_Check(OBJECT::TAIL);

		if (kbhit())
		{
			m_Player.Input(getch());
		}
		else
		{
			m_Player.MoveTimeCheck();
		}
	}
}

GameManager::~GameManager()
{
}
