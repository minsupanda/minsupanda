#pragma once
#include<iostream>
#include<stdlib.h>
#include<time.h>
#include<Windows.h>
#include<conio.h>
#include<vector>
#include<list>
#include"DrawManager.h"

#define HEIGHT 30
#define WIDTH 50

enum class TIMER_TYPE
{
	TIMER_TYPE_LOOP
};

enum class TIMER
{
	MOVE_TIME = 400,
	TAIL_CREATE_TIME = 300
};

enum class OBJECT
{
	WALL,
	TAIL
};

enum class OBJECT_MAX_AMOUNT
{
	ADD_TALL = 50,
	WALL = 300
};

enum class KEY
{
	UP = 'w',
	DOWN = 's',
	LEFT = 'a',
	RIGHT = 'd',
	STOP = -1,
	ESC = 27
};

typedef struct Position
{
	int m_ix;
	int m_iy;
};

struct Score
{
	int m_iScore;
	bool m_ScoreChange;
};