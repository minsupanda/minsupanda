#pragma once
#include"Player.h"

struct MAP
{
	int m_iWidth;
	int m_iHeight;
};

class GameManager
{
private:
	Player m_Player;
	ObjectManger m_ObjectManger;
	MAP m_MapSize;
	Score m_Score;
public:
	GameManager();
	void LobbyDraw();
	void MainMenu();
	void MapSetting();
	void Ui_Draw();
	void GameStart();
	void MainLoop();
	~GameManager();
};

