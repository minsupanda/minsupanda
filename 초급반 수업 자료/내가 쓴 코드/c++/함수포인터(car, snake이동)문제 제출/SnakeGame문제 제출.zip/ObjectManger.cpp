#include "ObjectManger.h"

ObjectManger::ObjectManger()
{}

void ObjectManger::Init()
{
	m_Wall.ObjectName = OBJECT::WALL;
	m_Wall.m_Shape = "��";
	m_Wall.m_XRange = WIDTH;
	m_Wall.m_YRange = HEIGHT;
	m_Wall.m_CurCount = 0;
	m_Wall.m_MaxCount = (int)OBJECT_MAX_AMOUNT::WALL;
	for (int i = m_Wall.m_CurCount; i < m_Wall.m_MaxCount; i++)
	{
		Object_Create(&m_Wall);
	}

	m_TailItem.ObjectName = OBJECT::TAIL;
	m_TailItem.m_Shape = "��";
	m_TailItem.m_XRange = WIDTH;
	m_TailItem.m_YRange = HEIGHT;
	m_TailItem.m_CurCount = 0;
	m_TailItem.m_MaxCount = (int)OBJECT_MAX_AMOUNT::ADD_TALL;
	m_TailItem_Timer.SetTimer(std::bind(&ObjectManger::Object_Create, this, &m_TailItem), TIMER_TYPE::TIMER_TYPE_LOOP, true, (int)TIMER::TAIL_CREATE_TIME);
}

void ObjectManger::Timer_Check(OBJECT _Object)
{
	switch (_Object)
	{
	case OBJECT::TAIL:
		if(m_TailItem.m_CurCount < m_TailItem.m_MaxCount)
			m_TailItem_Timer.TimerCheck();
		break;

	default: break;
	}
}

void ObjectManger::Object_Create(Objects* _Object)
{
	Position Tmp;
	do
	{
		Tmp = { (rand() % (_Object->m_XRange - 2)) + 1, (rand() % (_Object->m_YRange - 2)) + 1 };

	} while ((Tmp.m_ix == WIDTH / 2 && Tmp.m_iy == HEIGHT / 2) || Position_Overlap_Check(Tmp) == true);
	_Object->m_Position.push_back(Tmp);
	DrawManager::TextDraw(_Object->m_Shape, Tmp.m_ix, Tmp.m_iy);
	++(_Object->m_CurCount);
}

bool ObjectManger::Position_Overlap_Check(Position _Tmp)
{
	if (Object_Position_Compare(m_Wall, _Tmp) == true)
		return true;

	else if (Object_Position_Compare(m_TailItem, _Tmp) == true)
		return true;

	else return false;
}

bool ObjectManger::Object_Position_Compare(Objects _ComPareObject, Position _Tmp)
{
	for (auto iter = _ComPareObject.m_Position.begin(); iter != _ComPareObject.m_Position.end(); iter++)
	{
		if (_Tmp.m_ix == iter->m_ix && _Tmp.m_iy == iter->m_iy)
			return true;
	}
	return false;
}

void ObjectManger::Object_Clear(Objects* _Object, Position _Position)
{
	for (auto iter = _Object->m_Position.begin(); iter != _Object->m_Position.end();)
	{
		if (_Position.m_ix == iter->m_ix && _Position.m_iy == iter->m_iy)
		{
			_Object->m_Position.erase(iter);
			--_Object->m_CurCount;
			return;
		}
		else
			iter++;
	}
}

ObjectManger::~ObjectManger()
{
}
