#include "Player.h"

Player::Player()
{
}

void Player::Init()
{
	m_Snake.push_back({ "��", { WIDTH / 2, HEIGHT / 2 }, { WIDTH / 2, HEIGHT / 2 } });
	m_iSpeed = (int)TIMER::MOVE_TIME;
	m_Move_Direction = KEY::STOP;
	m_Move_Timer.SetTimer(std::bind(&Player::Move, this), TIMER_TYPE::TIMER_TYPE_LOOP, true, m_iSpeed);
}

void Player::Input(char _Direction)
{
	switch ((KEY)_Direction)
	{
	case KEY::UP:
		if (m_Move_Direction == KEY::DOWN)
			return;
		m_Move_Direction = KEY::UP;
		break;

	case KEY::DOWN:
		if (m_Move_Direction == KEY::UP)
			return;
		m_Move_Direction = KEY::DOWN;
		break;

	case KEY::LEFT:
		if (m_Move_Direction == KEY::RIGHT)
			return;
		m_Move_Direction = KEY::LEFT;
		break;

	case KEY::RIGHT:
		if (m_Move_Direction == KEY::LEFT)
			return;
		m_Move_Direction = KEY::RIGHT;
		break;

	default: break;
	}
	MoveTimeCheck();
}


void Player::MoveTimeCheck()
{
	m_Move_Timer.TimerCheck();
}

void Player::Move()
{
	Snake_Erase();
	for (auto iter = m_Snake.begin(); iter != m_Snake.end(); iter++)
		iter->m_PrePosition = iter->m_Position;
	switch (m_Move_Direction)
	{
	case KEY::UP:
		--(m_Snake.front().m_Position.m_iy);
		break;

	case KEY::DOWN:
		++(m_Snake.front().m_Position.m_iy);;
		break;

	case KEY::LEFT:
		--(m_Snake.front().m_Position.m_ix);
		break;

	case KEY::RIGHT:
		++(m_Snake.front().m_Position.m_ix);
		break;

	case KEY::STOP:
		break;
	}
	Snake_Move();
	Snake_Draw();
}

void Player::Snake_Move()
{
	if (m_iTailCount <= 0)
		return;

	Position Tmp = m_Snake.front().m_PrePosition;
	for (auto iter = m_Snake.begin(); iter != m_Snake.end(); iter++)
	{
		if (iter == m_Snake.begin())
			continue;

		iter->m_Position = Tmp;
		Tmp = iter->m_PrePosition;
	}
}

void Player::Snake_Erase()
{
	for (auto iter = m_Snake.begin(); iter != m_Snake.end(); iter++)
		DrawManager::TextErase(iter->m_Position.m_ix, iter->m_Position.m_iy);
}

void Player::Snake_Draw()
{
	for (auto iter = m_Snake.begin(); iter != m_Snake.end(); iter++)
		DrawManager::TextDraw(iter->Shpae, iter->m_Position.m_ix, iter->m_Position.m_iy);
}

bool Player::Position_Check(ObjectManger& _ObjectManger, Score& _Score)
{
	int x = m_Snake.front().m_Position.m_ix;
	int y = m_Snake.front().m_Position.m_iy;


	if (x == 0 || x == WIDTH - 1 || y == 0 || y == HEIGHT - 1)
	{
		return false;
	}
	else if (_ObjectManger.Object_Position_Compare(*_ObjectManger.Object_Adress(OBJECT::WALL), { x, y }) == true)
	{
		return Position_Overlap(*_ObjectManger.Object_Adress(OBJECT::WALL));
	}
	else if (_ObjectManger.Object_Position_Compare(*_ObjectManger.Object_Adress(OBJECT::TAIL), { x, y }) == true)
	{
		_ObjectManger.Object_Clear(_ObjectManger.Object_Adress(OBJECT::TAIL), {x, y});
		++_Score.m_iScore;
		_Score.m_ScoreChange = true;
		return Position_Overlap(*_ObjectManger.Object_Adress(OBJECT::TAIL));
	}
	else
	{
		for (auto iter = m_Snake.begin(); iter != m_Snake.end(); iter++)
		{
			if (iter == m_Snake.begin())
				continue;
			else if (x == iter->m_Position.m_ix && y == iter->m_Position.m_iy)
				return false;
		}
		return true;
	}
}

bool Player::Position_Overlap(Objects _Object)
{
	switch (_Object.ObjectName)
	{
	case OBJECT::WALL:
		return false;

	case OBJECT::TAIL:
		Tail_Plus();
		Speed_Change();
		return true;

	default: return false;
	}
}

void Player::Tail_Plus()
{
	++m_iTailCount;
	m_Snake.push_back({ "��", { m_Snake.back().m_PrePosition.m_ix, m_Snake.back().m_PrePosition.m_iy}, { m_Snake.back().m_PrePosition.m_ix, m_Snake.back().m_PrePosition.m_iy} });
}

Player::~Player()
{
}
