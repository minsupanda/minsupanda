#include "TimeManager.h"

TimeManager::TimeManager()
{
}

void TimeManager::SetTimer(std::function<void()> callbackFunc, int _iTimeScale)
{
	m_callbackFunc = callbackFunc;
	m_iTimeScale = _iTimeScale;
	m_iOldTime = clock();
}
   
void TimeManager::CheckTimer()
{
	if (clock() - m_iOldTime >= m_iTimeScale)
	{
		m_callbackFunc();
		m_iOldTime = clock();
	}
}

TimeManager::~TimeManager()
{
}
