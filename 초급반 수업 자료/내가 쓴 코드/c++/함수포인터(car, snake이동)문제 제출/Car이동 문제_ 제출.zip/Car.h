#pragma once
#include <iostream>
#include <string>
#include <list>
#include "TimeManager.h"
#include "MapDraw.h"
#include <list>


#define CAR_X_COORDINATE 10
#define CAR_Y_COORDINATE 10
#define DEFAULT_SPEED 300
#define BOOST_SPEED 100

typedef struct Position
{
	int m_ix;
	int m_iy;
};

class Car
{
private:
	std::string m_strShape[3];
	Position m_Position;
	int m_iSpeed;
	TimeManager m_Timemanager;
public:
	Car();
	void Move();
	void MoveTimeCheck();
	void Draw();
	void Erase();
	void SpeedChange();
	inline int X_Position_Get()
	{
		return m_Position.m_ix;
	}
	~Car();
};

