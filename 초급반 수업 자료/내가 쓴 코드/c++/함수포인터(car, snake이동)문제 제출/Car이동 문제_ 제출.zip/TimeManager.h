#pragma once
#include <iostream>
#include <Windows.h>
#include <time.h>
#include <functional>

class TimeManager
{
private:
	int m_iTimeScale;
	std::function<void()> m_callbackFunc;
	int m_iOldTime;
public:
	TimeManager();
	void SetTimer(std::function<void()> callbackFunc, int _iTimeScale);
	void CheckTimer();
	~TimeManager();
	inline void TimeChange(int _ChangeTime)
	{
		m_iTimeScale = _ChangeTime;
	}
};

