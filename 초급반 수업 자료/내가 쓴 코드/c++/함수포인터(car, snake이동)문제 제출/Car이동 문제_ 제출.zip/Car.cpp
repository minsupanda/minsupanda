#include "Car.h"

Car::Car()
{
	m_Position.m_ix = CAR_X_COORDINATE;
	m_Position.m_iy = CAR_Y_COORDINATE;
	m_iSpeed = DEFAULT_SPEED;
	m_strShape[0] = "  ����������";
	m_strShape[1] = "���� �Ȣ� ����";
	m_strShape[2] = "���ۦ������ۦ�";
	m_Timemanager.SetTimer(std::bind(&Car::Move, this), m_iSpeed);
}

void Car::Move()
{
	Erase();
	++m_Position.m_ix;
	Draw();
}

void Car::MoveTimeCheck()
{
	m_Timemanager.CheckTimer(); // Move�Լ� ȣ��
}

void Car::Draw()
{
	for (int i = 0; i <= 2; i++)
		MapDraw::Draw(m_strShape[i], m_Position.m_ix, m_Position.m_iy + i);
}

void Car::Erase()
{
	for (int i = 0; i <= 2; i++)
		MapDraw::Erase(m_Position.m_ix, m_Position.m_iy + i);
}

void Car::SpeedChange()
{
	switch (m_iSpeed)
	{
	case DEFAULT_SPEED:
		m_iSpeed = BOOST_SPEED;
		m_Timemanager.TimeChange(BOOST_SPEED);
		break;

	case BOOST_SPEED:
		m_iSpeed = DEFAULT_SPEED;
		m_Timemanager.TimeChange(DEFAULT_SPEED);
		break;
	}
}

Car::~Car()
{
}
