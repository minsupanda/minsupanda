#include"CarManager.h"

void main()
{
	CarManager car;
	car.MainLoop();

}