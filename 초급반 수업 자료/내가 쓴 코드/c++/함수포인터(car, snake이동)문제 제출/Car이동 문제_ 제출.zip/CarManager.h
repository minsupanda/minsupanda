#pragma once
#include <Conio.h>
#include"Car.h"
#define CREATE_TIME 5000

enum class KEY
{
	SPACE = 32,
	ESC = 27
};

enum class LINE
{
	START = 10,
	END = 90
};


class CarManager
{
private:
	std::list<Car*> m_Carlist;
	TimeManager m_Timemanager;
	int m_iCarCount = 0;
public:
	CarManager();
	void MainLoop();
	bool Input();
	void CreateTimeCheck();
	void Create();
	bool Move();
	void SpeedChange();
	bool Arrive_Check(std::list<Car*>::iterator iter);
	~CarManager();
};

