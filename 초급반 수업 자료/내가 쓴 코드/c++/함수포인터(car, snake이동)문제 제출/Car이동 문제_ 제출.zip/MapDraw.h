#pragma once
#include<iostream>
#include<Windows.h>
#include<string>

class MapDraw
{
public:
	static void Draw(std::string str, int x, int y)
	{
		gotoxy(x, y);
		std::cout << str;
	}

	static void Erase(int x, int y)
	{
		gotoxy(x, y);
		std::cout << "             ";
	}

	static void gotoxy(int x, int y)
	{
		COORD Pos = { x , y };
		SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), Pos);
	}
};

