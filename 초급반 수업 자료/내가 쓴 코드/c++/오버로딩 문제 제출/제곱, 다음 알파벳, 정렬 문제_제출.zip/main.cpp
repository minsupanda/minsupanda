#include"Quiz1.h"
#include"Quiz2.h"
#include"Quiz3.h"

void main()
{
	Quiz1 Squared;
	Quiz1 NextChar;
	Squared.InputNum();
	NextChar.InputCharNum();

	Quiz2 ReverseStr;
	Quiz2 MergeStr;
	ReverseStr.InputReverseString();
	MergeStr.InputMergeString();

	Quiz3 SortNum;
	Quiz3 SortChar;
	SortNum.InputNum();
	SortChar.InputChar();

}