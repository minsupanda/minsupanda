#include "Quiz3.h"

void Quiz3::InputNum()
{
	int _iarrNum[SIZE];
	cout << "���� 5�� �Է� : ";
	for (int i = 0; i < SIZE; i++)
		cin >> _iarrNum[i];
	Print(_iarrNum);
}

void Quiz3::Sort(int _iarrNum[SIZE])
{
	for (int i = 0; i < SIZE - 1; i++)
	{
		for (int j = i; j < SIZE; j++)
		{
			if (_iarrNum[i] > _iarrNum[j])
			{
				int Tmp = _iarrNum[i];
				_iarrNum[i] = _iarrNum[j];
				_iarrNum[j] = Tmp;
			}
		}
	}
}

void Quiz3::Print(int _iarrNum[SIZE])
{
	Sort(_iarrNum);
	cout << "==========iarr==========" << endl;
	for (int i = 0; i < SIZE; i++)
		cout << "iarr[" << i << "] : " << _iarrNum[i] << endl;
}

void Quiz3::InputChar()
{
	char _charrChar[SIZE];
	cout << "���� 5�� �Է� : ";
	for (int i = 0; i < SIZE; i++)
		cin >> _charrChar[i];
	Print(_charrChar);
}

void Quiz3::Sort(char _charrChar[SIZE])
{
	for (int i = 0; i < SIZE - 1; i++)
	{
		for (int j = i; j < SIZE; j++)
		{
			if (_charrChar[i] < _charrChar[j])
			{
				int Tmp = _charrChar[i];
				_charrChar[i] = _charrChar[j];
				_charrChar[j] = Tmp;
			}
		}
	}
}

void Quiz3::Print(char _charrChar[SIZE])
{
	Sort(_charrChar);
	cout << "==========charr==========" << endl;
	for (int i = 0; i < SIZE; i++)
		cout << "charr[" << i << "] : " << _charrChar[i] << endl;
}