#pragma once
#include"Mecro.h"
#define SIZE 5

class Quiz3
{
public:
	void InputNum();
	void Sort(int _iarrNum[SIZE]);
	void Print(int _iarrNum[SIZE]);
	void InputChar();
	void Sort(char _charrChar[SIZE]);
	void Print(char _charrChar[SIZE]);
};

