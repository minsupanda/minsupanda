#pragma once
#include"Mecro.h"
#define A 65
#define Z 90
#define a 97
#define z 122

class Quiz1
{
public:
	void InputNum();
	int Setting(int _iBase, int _iExponent);
	void Print(int _iBase, int _iExponent);

	void InputCharNum();
	char Setting(char _charWord, int _iNum);
	void Print(char _charWord, int _iNum);
};




