#include "Quiz2.h"

void Quiz2::InputReverseString()
{
	string _strReverse;
	cout << "2. ���ڿ� �ϳ� �Է� : ";
	cin >> _strReverse;
	Print(_strReverse);
}

string Quiz2::Setting(string _strReverse)
{
	string ReverseStr;
	for (int i = _strReverse.length() - 1; i >= 0; i--)
		ReverseStr += _strReverse[i];
	return ReverseStr;
}

void Quiz2::Print(string _strReverse)
{
	string ReverseStr = Setting(_strReverse);
	cout << _strReverse << "-��" << ReverseStr << endl;
}

void Quiz2::InputMergeString()
{
	string _strMerge1;
	string _strMerge2;
	cout << "2. ���ڿ� �ΰ� �Է� : ";
	cin >> _strMerge1;
	cin >> _strMerge2;
	Print(_strMerge1, _strMerge2);
}

string Quiz2::Setting(string _strMerge1, string _strMerge2)
{
	string MergeStr;
	MergeStr = _strMerge1;
	MergeStr += _strMerge2;
	return MergeStr;
}

void Quiz2::Print(string _strMerge1, string _strMerge2)
{
	string MergeStr = Setting(_strMerge1, _strMerge2);
	cout << _strMerge1 << " + " << _strMerge2 << " : " << MergeStr << endl;
}