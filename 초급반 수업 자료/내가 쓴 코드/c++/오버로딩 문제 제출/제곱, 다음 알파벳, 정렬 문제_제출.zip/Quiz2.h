#pragma once
#include"Mecro.h"
#include<string>
class Quiz2
{
public:
	void InputReverseString();
	string Setting(string _strReverse);
	void Print(string _strReverse);

	void InputMergeString();
	string Setting(string _strMerge1, string _strMerge2);
	void Print(string _strMerge1, string _strMerge2);
};

