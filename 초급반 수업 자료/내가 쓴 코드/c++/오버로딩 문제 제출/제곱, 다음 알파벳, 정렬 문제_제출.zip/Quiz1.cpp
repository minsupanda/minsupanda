#include "Quiz1.h"

void Quiz1::InputNum()
{
	int _iBase, _iExponent;
	while (1)
	{
		cout << "���� 2�� �Է� : ";
		cin >> _iBase;
		cin >> _iExponent;
		if (_iExponent >= 1)
			break;
		cout << "���� 1���� �۽��ϴ�." << endl;
		system("cls");
	}
	Print(_iBase, _iExponent);
}

int Quiz1::Setting(int _iBase, int _iExponent)
{
	int iSum = 1;
	for (int i = 1; i <= _iExponent; i++)
		iSum = iSum * _iBase;
	return iSum;
}

void Quiz1::Print(int _iBase, int _iExponent)
{
	int iSum = Setting(_iBase, _iExponent);
	cout << "Quiz1(���� 2��)" << endl;
	cout << _iBase << "�� " << _iExponent << "�� : " << iSum << endl;
}

void Quiz1::InputCharNum()
{
	char _charWord;
	int _iNum;
	cout << "1. ���Ϲ��ڿ� ���� �Է� : ";
	cin >> _charWord;
	cin >> _iNum;
	Print(_charWord, _iNum);
}

char Quiz1::Setting(char _charWord, int _iNum)
{
	if (_charWord <= Z)
	{
		_charWord = _charWord + _iNum;
		if (_charWord > Z)
			_charWord =- Z + A - 1;
	}
	else
	{
		_charWord = _charWord + _iNum;
		if (_charWord > z)
			_charWord =- z + a - 1;
	}
	return _charWord;
}

void Quiz1::Print(char _charWord, int _iNum)
{
	char charAlphabet = Setting(_charWord, _iNum);
	cout << _charWord << ">>" << _iNum << " : " << charAlphabet << endl;
}