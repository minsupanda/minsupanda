﻿#include"Wage.h"
#include"Sum.h"
#include "GuGuDan.h"
#include<Windows.h>

void main()
{
	Wage wage;
	Sum sum;
	GuGuDan gugudan;
	int Select;
	while (1)
	{
		system("cls");
		cout << "DefalutParameter 문제" << endl;
		cout << "1. 급여 계산" << endl;
		cout << "2. 누적 합계" << endl;
		cout << "3. 구구단 출력" << endl;
		cout << "4. 종료" << endl;
		cout << "선택 : ";
		cin >> Select;
		switch (Select)
		{
		case 1:
			wage.WorkMeasure();
			break;
		case 2:
			sum.SetNum();
			break;
		case 3:
			gugudan.GuGuDanSet();
			break;
		case 4:
			return;
		}
		system("pause");
	}
}

