#pragma once
#include<iostream>
#define DEFAULT_PAY 9160
#define DEFAULT_TIME 8
using namespace std;

class Wage
{
private:
	int m_iWorkDay;
	int m_iWorkTime;
	int m_iHourlyWage;
public:
	void WorkMeasure();
	void Count(int m_iWorkDay, int m_iWorkTime = DEFAULT_TIME, int m_iHourlyWage = DEFAULT_PAY);
};

