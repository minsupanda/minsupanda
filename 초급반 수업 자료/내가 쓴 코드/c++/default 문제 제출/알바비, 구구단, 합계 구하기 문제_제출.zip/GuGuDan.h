#pragma once
#include<iostream>
#define DEFAULT_FRIST 2
#define DEFAULT_LAST 9
using namespace std;
class GuGuDan
{
private:
	int m_iFrist;
	int m_iLast;
public:
	void GuGuDanSet();
	void Print(int m_iFrist = DEFAULT_FRIST, int m_iLast = DEFAULT_LAST);
};

