#pragma once
#include<iostream>
#define DEFAULT_NUM 10
using namespace std;

class Sum
{
private:
	int m_iInputNum;
public:
	void SetNum();
	void Add(int m_iInputNum = DEFAULT_NUM);
};

