﻿#include"StudentManager.h"
#include<Windows.h>

void main()
{
	StudentManager studentManager;
	studentManager.Main();
}