#pragma once
#include<list>
#include"Student.h"

#define STUDENT_MAX 10

class StudentManager
{
private:
	list<Student> m_StudentList;
public:
	void Main();
	void AddStudent();
	void ShowNumberOrder();
	void ShowGradeOrder();
	void ShowClass(int iGrade, bool bExist);
	bool FindStudentName(string Name);
	void FindStudentClass(int iClass);
	StudentManager();
	~StudentManager();
};

