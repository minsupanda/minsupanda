#include"Mecro.h"
#include"Map.h"
#include"Character.h"

void main()
{
	Map map;
	map.MapDraw();
	Character character(map.GetPosition(), map.GetMapSize());
	character.MoveCheck();
}