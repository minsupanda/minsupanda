#pragma once

#include<iostream>
#include<string>
#include<conio.h>
#include<iomanip>
#include<Windows.h>
using namespace std;

struct Position
{
	int m_ix;
	int m_iy;
};

struct Size
{
	int m_iWidth;
	int m_iHeight;
};

struct MoveRange
{
	int m_iUp;
	int m_iDown;
	int m_iRight;
	int m_iLeft;
};

