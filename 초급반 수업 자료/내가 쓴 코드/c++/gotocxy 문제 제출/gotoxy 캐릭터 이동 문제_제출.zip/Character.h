#pragma once
#include"Mecro.h"
#include"Map.h"
#include"MapDraw.h"

#define UP 119
#define DOWN 115
#define RIGHT 100
#define LEFT 97
#define ESC 27

class Character
{
private:
	string m_character = "��";
	Position m_position;
	MoveRange m_Range;
public:
	Character(Position _position, Size _size);
	void MoveCheck();
	void Move(int x_Direction, int y_Direction);
	~Character();
};

