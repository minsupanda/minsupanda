#pragma once
#include"Mecro.h"
#include"MapDraw.h"

class Map
{
private:
	Position m_position;
	Size m_mapSize;
public:
	void MapDraw();
	inline Position GetPosition()
	{
		return m_position;
	}
	inline Size GetMapSize()
	{
		return m_mapSize;
	}
	Map();
	~Map();
};

