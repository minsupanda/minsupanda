#pragma once
#include"Login.h"

struct ComputerState
{
	std::string m_strProductName = "�̹μ� ��ǻ��";
	std::string m_StrCurrentStatus = "OFF";
	std::string m_strGraphicCard = "GTX990";
	std::string m_strCPU = "i7";
	std::string m_strMemory = "8G";
};

class Computer : public Login
{
private:
	ComputerState m_ComputerState;
public:
	Computer();
	void PowerOnOff();
	void Menu();
	void ComputerInfo();
	void Function();
	void TimeCheck(int Count);

	~Computer();
};

