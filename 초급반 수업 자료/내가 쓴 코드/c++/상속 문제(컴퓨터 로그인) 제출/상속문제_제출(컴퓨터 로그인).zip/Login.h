#pragma once
#include<iostream>
#include<string>
#include<map>
#include<conio.h>
#include<Windows.h>
#include<time.h>
#include<stdlib.h>

#define LOG_IN_COUNT 3
#define LOG_OUT_COUNT 5
#define MIN_ID_LENGTH 3
#define MIN_PW_LENGTH 8
#define JOIN_MILEAGE 1000


struct profile
{
	std::string PW;
	std::string name;
	int age;
	int phone_number;
	int mileage;
};

enum class OPTION
{
	SIGN_UP,
	LOG_IN,
	ESC
};

enum class CHANGE_MENU
{
	NAME,
	AGE,
	PHONE_NUMBER
};

class Login
{
private:
	std::map <std::string, profile> m_Member;
protected:
	std::map <std::string, profile>::iterator m_iterLoginUser;
public:
	Login();
	OPTION Menu();
	void SignUp();
	bool LogIn();
	bool ID_Check(std::string _ID);
	bool PW_Check(std::string _PW);
	bool PW_Confirm(std::string _PW);
	bool ID_Overlap_Check(std::string _ID);
	bool Eng_Check(std::string Check);
	bool Num_Check(std::string Check);
	void TimeCheck(int Count);
	void MemberInfo();
	void MemberInfoChange();
	void InfoChange(CHANGE_MENU _ChangeManu);
	~Login();
};

