
#include"Computer.h"

void main()
{
	Computer computer;
	computer.PowerOnOff();
}