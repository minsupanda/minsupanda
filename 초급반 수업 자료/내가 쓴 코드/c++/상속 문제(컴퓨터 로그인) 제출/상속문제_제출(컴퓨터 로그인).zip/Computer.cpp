#include "Computer.h"

Computer::Computer()
{
	srand(time(NULL));
}

void Computer::PowerOnOff()
{
	switch (Login::Menu())
	{
	case OPTION::LOG_IN:
		m_ComputerState.m_StrCurrentStatus = "ON";
		Menu();
		break;

	case OPTION::ESC:
		m_ComputerState.m_StrCurrentStatus = "OFF";
		return;
	}
}

void Computer::Menu()
{
	int iSelect;
	while (1)
	{
		system("cls");
		std::cout << "===== ȯ �� �� �� �� =====" << std::endl;
		std::cout << "1. ��ǻ�� ����" << std::endl;
		std::cout << "2. �� ��" << std::endl;
		std::cout << "3. ȸ�� ����" << std::endl;
		std::cout << "4. ȸ�� ���� ����" << std::endl;
		std::cout << "5. off" << std::endl;
		std::cout << "�Է� : ";
		std::cin >> iSelect;
		switch (iSelect)
		{
		case 1:
			system("cls");
			ComputerInfo();
			break;

		case 2:
			system("cls");
			Function();
			break;

		case 3:
			system("cls");
			MemberInfo();
			break;

		case 4:
			system("cls");
			MemberInfoChange();
			break;

		case 5:
			TimeCheck(LOG_OUT_COUNT);
			PowerOnOff();
			return;

		default: break;
		}
		system("pause");
	}
}

void Computer::ComputerInfo()
{
	std::cout << "�� ǰ �� : " << m_ComputerState.m_strProductName << std::endl;
	std::cout << "���� ���� : " << m_ComputerState.m_StrCurrentStatus << std::endl;
	std::cout << "�׷���ī��" << m_ComputerState.m_strGraphicCard << std::endl;
	std::cout << "C P U : " << m_ComputerState.m_strCPU << std::endl;
	std::cout << "�� �� �� : " << m_ComputerState.m_strMemory << std::endl;
}

void Computer::Function()
{
	int iSelect;
	while (1)
	{
		system("cls");
		std::cout << "1. �� �� ��" << std::endl;
		std::cout << "2. �� �� ��" << std::endl;
		std::cout << "3. �� �� ��" << std::endl;
		std::cout << "4. ���ư���" << std::endl;
		std::cout << "���� >>>> ";
		std::cin >> iSelect;
		switch (iSelect)
		{
		case 1:
			system("calc");
			break;
		case 2:
			system("notepad");
			break;
		case 3:
			system("mspaint");
			break;
		case 4:
			return;
		}
	}

}

void Computer::TimeCheck(int Count)
{
	int Old_Clock = clock();
	while (Count > 0)
	{
		if (clock() - Old_Clock >= 1000)
		{
			--Count;
			std::cout << "off" << Count << "����" << std::endl;
			Old_Clock = clock();
		}
	}
}

Computer::~Computer()
{
}

