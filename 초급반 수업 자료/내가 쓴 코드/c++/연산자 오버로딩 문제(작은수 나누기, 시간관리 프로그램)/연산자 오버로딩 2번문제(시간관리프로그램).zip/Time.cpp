#include "Time.h"

Time::Time() {}

Time::Time(int Hour, int Min)
{
	m_iHour = Hour;
	m_iMin = Min;
}

void Time::ShowTime()
{
	std::cout << "�� ���� �ð� : " << m_iHour << " : " << m_iMin << std::endl;
}

Time Time::operator+(Time time)
{
	int iPlusHour = 0;
	this->m_iMin += time.m_iMin;
	this->m_iHour += time.m_iHour + time.m_iMin / 60;
	if (this->m_iMin >= 60)
	{
		this->m_iMin %= 60;
	}
	return *this;
}

Time::~Time() {}
