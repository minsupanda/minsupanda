#include <iostream>
using namespace std;
class Time
{
private:
	int m_iHour;
	int	m_iMin;
public:
	Time();
	Time(int Hour, int Min);
	void ShowTime();
	Time operator + (Time time);
	~Time();
};