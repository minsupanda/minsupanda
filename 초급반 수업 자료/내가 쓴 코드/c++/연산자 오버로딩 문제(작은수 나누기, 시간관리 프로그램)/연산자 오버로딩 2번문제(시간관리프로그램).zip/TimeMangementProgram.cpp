#include "TimeMangementProgram.h"

TimeMangementProgram::TimeMangementProgram()
{
	m_iDay = 1;
}

void TimeMangementProgram::Menu()
{
	Time StudyTime(0, 0);
	while (1)
	{
		int iSelect;
		system("cls");
		StudyTime.ShowTime();
		std::cout << "===== ���� �ð� ���� ���α׷�(" << m_iDay << "Day) =====" << std::endl;
		std::cout << "\t1. �ð� ���" << std::endl;
		std::cout << "\t2. ����" << std::endl;
		std::cout << "\t�Է� : ";
		std::cin >> iSelect;
		switch (iSelect)
		{
		case 1:
		{
			Time PlusTime(TimeEnrollment());
			StudyTime + PlusTime;
			break;
		}
		case 2:
			system("cls");
			StudyTime.ShowTime();
			system("pause");
			return;
		default: break;
		}
	}
}

Time TimeMangementProgram::TimeEnrollment()
{
	int iTmpHour;
	int iTmpMin;
	std::cout << "�ð� : ";
	std::cin >> iTmpHour;
	std::cout << "�� : ";
	std::cin >> iTmpMin;
	++m_iDay;
	return { iTmpHour, iTmpMin };
}

TimeMangementProgram::~TimeMangementProgram()
{
}
