#include"TimeMangementProgram.h"


void main()
{
	TimeMangementProgram TimeProgram;
	TimeProgram.Menu();
}