#pragma once
#include"Time.h"

class TimeMangementProgram : public Time
{
private:
	int m_iDay;
public:
	TimeMangementProgram();
	void Menu();
	Time TimeEnrollment();
	~TimeMangementProgram();
};

