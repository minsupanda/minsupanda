#include "Point.h"

Point::Point() {}

Point::Point(int a, int b)
{
	m_ix = a;
	m_iy = b;
}

void Point::Print()
{
	cout << "x = " << m_ix << ", y = " << m_iy << "\n";
}

Point Point::operator/(Point tmp)
{
	Point Tmp;

	if ((this->m_ix >= tmp.m_ix))
		Tmp.m_ix = this->m_ix / tmp.m_ix;
	else
		Tmp.m_ix = tmp.m_ix / this->m_ix;

	if ((this->m_iy >= tmp.m_iy))
		Tmp.m_iy = this->m_iy / tmp.m_iy;
	else
		Tmp.m_iy = tmp.m_iy / this->m_iy;

	return Tmp;
}

Point::~Point() {}
