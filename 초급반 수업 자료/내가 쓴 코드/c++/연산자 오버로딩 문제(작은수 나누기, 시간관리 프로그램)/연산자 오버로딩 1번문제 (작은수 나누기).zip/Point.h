#include <iostream>
using namespace std;
class Point
{
private:
	int m_ix, m_iy;
public:
	Point();
	Point(int a, int b);
	void Print();
	Point operator/(Point tmp);
	~Point();
};