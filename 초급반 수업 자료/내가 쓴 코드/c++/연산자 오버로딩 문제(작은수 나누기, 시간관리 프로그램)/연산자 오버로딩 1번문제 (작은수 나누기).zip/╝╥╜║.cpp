#include"Point.h"

void main()
{
	Point ov1(10, 20), ov2(5, 40);
	ov1.Print();
	ov2.Print();
	std::cout << "��ü / ��ü" << std::endl;
	Point ov3 = ov1 / ov2;
	ov3.Print();
}