#pragma once
#include"Mecro.h"

class Option
{
public:
	Option();
	void Menu();
};