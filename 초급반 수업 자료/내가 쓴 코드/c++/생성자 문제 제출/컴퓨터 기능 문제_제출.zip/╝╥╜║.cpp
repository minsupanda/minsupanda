#include"Mecro.h"
#include"Computer.h"

void main()
{
	Computer Computer;
	Computer.PoewerOn();
}