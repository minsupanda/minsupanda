#include "Skill.h"

Skill::Skill()
{
}

void Skill::Skill_Init(std::string _SetName, SkillUseType _SetUseType)
{
	m_SkillName = _SetName;
	m_UseType = _SetUseType;
}

void Skill::Buff_Setting(BuffSkill _SetBuffSkill)
{
	m_vecBuffList.push_back(_SetBuffSkill);
}

Skill::~Skill()
{
}
