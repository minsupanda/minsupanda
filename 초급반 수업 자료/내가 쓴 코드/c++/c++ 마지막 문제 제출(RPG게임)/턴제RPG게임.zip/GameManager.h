#pragma once
#include<vector>
#include"Mecro.h"
#include"Monster.h"

#define LOG_TEXT_MAX_SIZE 12

struct MapSize
{
	int m_iWidth;
	int m_iHeight;
};

class GameManager
{
private:
	MapSize m_MapSize;
	std::vector<Monster> m_MonsterList;
	std::vector<Weapon> CurShopWeaponList;
public:
	GameManager();
	void Init();
	void MainLoop();
	void GameStart();
	void JobChoice();
	void StageProgressChoice(); // �������� ��������, ĳ���� �������� �����ϴ� ȭ��
	void Character_Management(CharacterManageMentMenu _ChoiceMenu);
	void ShopWeaponBuy(int _iChoiceMenu);
	void Skill_ManageMent();
	void Battle(Monster _CurMonster); // ���� ȭ��
	void TurnChange(Character** CurArot, Character** Target);
	void Battle_Log(Character* _CurActor, Character* _Target, TurnResult _TurnResult, ActionLog _ActionLogRecord, std::list<std::string>* _LogList);
	void Battle_Log_Print(std::list<std::string> _LogList);
	void StageClear(Monster _CurMonster);
	~GameManager();
};

