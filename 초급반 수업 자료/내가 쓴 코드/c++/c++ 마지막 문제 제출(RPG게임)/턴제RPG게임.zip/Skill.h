#pragma once
#include<vector>
#include<list>
#include"Mecro.h"
#include"BuffSkill.h"

enum class SkillUseType
{
	ACTIVE,
	PASSIVE,
	END
};

class Skill
{
private:
	std::string m_SkillName;
	SkillUseType m_UseType;
	std::vector<BuffSkill> m_vecBuffList;
public:
	Skill();
	~Skill();
	virtual void Skill_Setting(std::string _SkillName) = 0;
	void Buff_Setting(BuffSkill _SetBuffSkill);
	inline std::string Get_SkillName() { return m_SkillName; }
	inline SkillUseType Get_SkillUseType() { return m_UseType; }
	inline 	std::vector<BuffSkill> Get_BuffList() { return m_vecBuffList; }
	void Skill_Init(std::string _SetName, SkillUseType _SetUseType);
};

