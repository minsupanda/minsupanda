#pragma once
#include"Character.h"
#include"Weapon.h"

class PlayableCharacter : public Character
{
private:
	JobClass m_JobClass;
	Weapon m_CurWeapon;
public:
	PlayableCharacter();
	void PlayerCharacter_Init();
	inline void JobClass_Setting(JobClass _JobClass) { m_JobClass = _JobClass; }
	inline void Weapon_Setting(Weapon _Weapon) { m_CurWeapon = _Weapon; }
	inline JobClass Get_JobClass() { return m_JobClass; }
	inline Weapon Get_Weapon() { return m_CurWeapon; }
	virtual TurnResult Action_Choice(Character* _Target, ActionLog& _ActionLogRecord);
	void Skill_Init(JobClass _JobClass);
	void Skill_Change(Skill* _CurUseSkill, Skill* ChangeSkill);
	~PlayableCharacter();
};

