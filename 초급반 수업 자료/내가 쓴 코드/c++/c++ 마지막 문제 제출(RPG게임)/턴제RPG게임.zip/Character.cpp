#include "Character.h"
#include "WeaponManager.h"

TurnResult Character::Action_Choice(Character* _Target, ActionLog& _ActionLogRecord) { return TurnResult(); }

Character::Character()
{
}

void Character::Init(CharacterType _CharacterType, std::string _SetCharacterName, int _SetHP, int _SetMP, int _SetAttackPoint, int _SetDefencePoint)
{
	m_CharacterName = _SetCharacterName;
	m_CharacterType = _CharacterType;
	m_OriginStatus.m_iHP = _SetHP;
	m_OriginStatus.m_iMaxHP = _SetHP;
	m_OriginStatus.m_iMP = _SetMP;
	m_OriginStatus.m_iMaxMP = _SetMP;
	m_OriginStatus.m_iAttackPoint = _SetAttackPoint;
	m_OriginStatus.m_iDefencePoint = _SetDefencePoint;
	m_OriginStatus.m_iAvoidRate = 0;
	m_OriginStatus.m_iShieldGage = 0;
	m_OriginStatus.m_fDamageRate= 1.0f;
	m_OriginStatus.m_fUseMPScale = 1.0f;
	m_OriginStatus.m_bDefence = false;
	m_OriginStatus.m_bStern = false;
	m_CurStatus = m_OriginStatus;
	m_iTurn = 1;
	m_AddBuffStatus.Reset();
}

TurnResult Character::Check_Before_Proceeding()
{
	m_CurStatus = m_OriginStatus;
	m_iDamage = 0;
	m_iUseMana = 0;
	m_AddBuffStatus.Reset();
	PreAction_Buff_Apply();
	if (m_CurStatus.m_iHP <= 0)
		return TurnResult::END;
	else if (TurnSkip_Check() == true)
		return TurnResult::SKIP;
	else
		return TurnResult::PROGRESS;
}

bool Character::SkillMana_Confirm(int _iMPUsage)
{
	if (m_CurStatus.m_iMP >= _iMPUsage)
		return true;
	else
		return false;
}

bool Character::TurnSkip_Check()
{
	return m_CurStatus.m_bStern;
}

void Character::PreAction_Buff_Apply()
{
	std::vector<BuffSkill> BuffList = m_MountedPassiveSkill.Get_BuffList();
	for (auto iter = BuffList.begin(); iter != BuffList.end(); iter++)
		m_AddBuffStatus.AddBuff(*iter);
	for (auto iter = m_CurAppliedBuffSkillList.begin(); iter != m_CurAppliedBuffSkillList.end();)
	{
		if (iter->Get_BuffApplyTurn() + iter->Get_BuffTurn() <= m_iTurn) // ������ ����� �� + ���� ������ >= ���� ��
		{ 
			if(iter->Get_BuffType() != BuffType::ATTACK_DAMAGE_INCREASE || iter->Get_BuffType() != BuffType::MANA_USAGE_INCREASE)
				iter = m_CurAppliedBuffSkillList.erase(iter);
		}
		else
		{
			m_AddBuffStatus.AddBuff(*iter);
			iter++;
		}
	}
	Buff_Value_Apply();
}

void Character::Buff_Value_Apply()
{
	m_AddBuffStatus.Value_Apply(m_CurStatus);
}

void Character::Acting_Buff_Value_Apply()
{
	m_iDamage *= m_CurStatus.m_fDamageRate;
	m_CurStatus.m_iMP -= m_iUseMana * m_CurStatus.m_fUseMPScale;
	HP_Heal(m_AddBuffStatus.Get_Heal());
	for (auto iter = m_CurAppliedBuffSkillList.begin(); iter != m_CurAppliedBuffSkillList.end();)
	{
		if (iter->Get_BuffApplyTurn() + iter->Get_BuffTurn() <= m_iTurn) // ������ ����� �� + ���� ������ >= ���� ��
		{
			if (iter->Get_BuffType() == BuffType::ATTACK_DAMAGE_INCREASE || iter->Get_BuffType() == BuffType::MANA_USAGE_INCREASE)
				iter = m_CurAppliedBuffSkillList.erase(iter);
		}
		iter++;
	}
}

void Character::DefaultAttack_Action(Character* _Target, int _WeaponDamage, ActionLog& _ActionLogRecord)
{
	_Target->Hit_By(m_CurStatus.m_iAttackPoint + _WeaponDamage, _ActionLogRecord);
	_Target->TurnEnd_Status_Setting();
}

void Character::UsedSkill_Action(Character* _Target, int _WeaponDamage, int _ChoiceSkill, ActionLog& _ActionLogRecord)
{
	_ActionLogRecord.SkillName = m_MountedActiveSkillList[_ChoiceSkill].Get_SkillName();
	m_iUseMana = m_MountedActiveSkillList[_ChoiceSkill].Get_SkillMana();
	switch (m_MountedActiveSkillList[_ChoiceSkill].Get_AttackType())
	{
	case AttackType::NONE:
		_ActionLogRecord.m_SkillAttack = false;
		Acting_Buff_Value_Apply();
		break;

	case AttackType::ONCE_ATTACK:
	case AttackType::DOUBLE_ATTACK:
		_ActionLogRecord.m_SkillAttack = true;
		m_iDamage = m_CurStatus.m_iAttackPoint + _WeaponDamage;
		m_MountedActiveSkillList[_ChoiceSkill].UseSkill_Damage_Calculation(m_iDamage);
		Acting_Buff_Value_Apply();
		break;
	}
	UsedSkill_Buff_Add(_Target, m_MountedActiveSkillList[_ChoiceSkill]);
	_Target->Hit_By(m_iDamage, _ActionLogRecord);
	_Target->TurnEnd_Status_Setting();
}

void Character::UsedSkill_Buff_Add(Character* _Target, ActiveSkill _CurUseSkill)
{
	std::vector<BuffSkill> TmpUseSkill_BuffList = _CurUseSkill.Get_BuffList();
	for (std::vector<BuffSkill>::iterator iter = TmpUseSkill_BuffList.begin(); iter != TmpUseSkill_BuffList.end(); iter++)
	{
		if (iter->Get_BuffType() == BuffType::SHIEID)
			m_CurStatus.m_iShieldGage = iter->Get_BuffValue();
		else
		{
			switch (iter->Get_SkillTarget())
			{
			case ApplyTarget::MY_TEAM:
				iter->BuffApply_Turn_Setting(m_iTurn + 1);
				if (Buff_OverlapCheck(*iter) == false)
					m_CurAppliedBuffSkillList.push_back(*iter);
				break;

			case ApplyTarget::ENMEY_TEAM:
				iter->BuffApply_Turn_Setting(m_iTurn);
				if (Buff_OverlapCheck(*iter) == false)
					_Target->Get_AppliedBuffSkillList()->push_back(*iter);
				break;
			}
		}
	}
}

bool Character::Buff_OverlapCheck(BuffSkill _CurUseBuffSkill)
{
	BuffType TmpBuffType = _CurUseBuffSkill.Get_BuffType();
	for (std::list<BuffSkill>::iterator iter = m_CurAppliedBuffSkillList.begin(); iter != m_CurAppliedBuffSkillList.end(); iter++)
	{
		if (iter->Get_BuffType() == TmpBuffType)
		{
			iter->BuffApply_Turn_Setting(m_iTurn);
			return true;
		}
	}
	return false;
}

void Character::Hit_By(int _HitDamage, ActionLog& _ActionLogRecord)
{
	if (AttackBlock_Check(_ActionLogRecord) == true)
		return;
	else if (_HitDamage - m_CurStatus.m_iDefencePoint >= 0)
	{
		if (m_CurStatus.m_iShieldGage > 0)
			ShieldGage_Decrease(_HitDamage);
		if(_HitDamage - m_CurStatus.m_iDefencePoint >= 0)
			m_CurStatus.m_iHP -= _HitDamage - m_CurStatus.m_iDefencePoint;
		_ActionLogRecord.m_iTotalDamage = _HitDamage;
		if (m_CurStatus.m_iHP < 0)
			m_CurStatus.m_iHP = 0;
	}
	else
		_ActionLogRecord.m_iTotalDamage = 0;
}

bool Character::AttackBlock_Check(ActionLog& _ActionLogRecord)
{
	if (m_CurStatus.m_bDefence == true)
	{
		_ActionLogRecord.bAttackResult = false;
		_ActionLogRecord.bDefenceResult = true;
		m_CurStatus.m_bDefence = false;
		return true;
	}
	for (auto iter = m_CurAppliedBuffSkillList.begin(); iter != m_CurAppliedBuffSkillList.end(); iter++)
	{
		if (iter->Get_BuffType() == BuffType::EVATION) // Ȯ���� �̰Ը³�?
		{
			if (rand() % 100 < m_CurStatus.m_iAvoidRate)
			{
				_ActionLogRecord.bAttackResult = false;
				_ActionLogRecord.bEvationResult = true;
				return true;
			}
		}
	}
	return false;
}

void Character::AcquiredSkill_Save(Skill* _GetSkill) // �갡 ��Ƽ�곪 �нú��� �����͸� �ްԵǾ Skill Class�� ũ�⸸ŭ �Ҵ�ް� �ּҸ� ����������, �ڿ� �̾ ����� ��Ƽ�곪 �нú��� �޸𸮸� ����ϰ� �Ǵ� ��
{
	switch (_GetSkill->Get_SkillUseType())
	{
	case SkillUseType::ACTIVE:
	{
		ActiveSkill TmpActiveSkill = *dynamic_cast<ActiveSkill*>(_GetSkill);
		m_PossessActiveSkillList.push_back(TmpActiveSkill);
		break;
	}
	case SkillUseType::PASSIVE:
	{
		PassiveSkill TmpPassiveSkill = *dynamic_cast<PassiveSkill*>(_GetSkill);
		m_PossessPassiveSkillList.push_back(TmpPassiveSkill);
		break;
	}
	}
}

void Character::ShieldGage_Decrease(int& _HitDamage)
{
	if (m_CurStatus.m_iShieldGage - _HitDamage > 0)
	{
		m_CurStatus.m_iShieldGage -= _HitDamage;
		_HitDamage = 0;
	}
	else
	{
		_HitDamage -= m_CurStatus.m_iShieldGage;
		m_CurStatus.m_iShieldGage = 0;
	}
}

void Character::Possess_ActiveSkill_Check(std::map<int, std::string>& _mapPrintString)
{
	int j = 0;
	for (auto iter = m_PossessActiveSkillList.begin(); iter != m_PossessActiveSkillList.end(); iter++)
	{
		if (CurUse_ActiveSkill_Check(*iter) == true)
		{
			_mapPrintString.insert(std::make_pair(j, iter->Get_SkillName()));
			++j;
		}
	}
};

bool Character::CurUse_ActiveSkill_Check(ActiveSkill _Skill)
{
	for (int i = 0; i < static_cast<int>(SkillSlot::SLOT_END); i++)
	{
		if (m_MountedActiveSkillList[i].Get_SkillName() == _Skill.Get_SkillName())
			return false;
	}
	return true;
}


void Character::Possess_PassiveSkill_Check(std::map<int, std::string>& _mapPrintString)
{
	int j = 0;
	for (auto iter = m_PossessPassiveSkillList.begin(); iter != m_PossessPassiveSkillList.end(); iter++)
	{
		if (CurUse_PassiveSkill_Check(*iter) == true)
		{
			_mapPrintString.insert(std::make_pair(j, iter->Get_SkillName()));
			++j;
		}
	}
}

bool Character::CurUse_PassiveSkill_Check(PassiveSkill _Skill)
{
	if (m_MountedPassiveSkill.Get_SkillName() == _Skill.Get_SkillName())
			return false;
	else return true;
}

Character::~Character()
{
}
