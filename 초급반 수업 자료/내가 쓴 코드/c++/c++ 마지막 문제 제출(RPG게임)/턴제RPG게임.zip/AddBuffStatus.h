#pragma once
#include"Mecro.h"
#include "BuffSkill.h"

class AddBuffStatus
{
private:
	int m_iShieldGage = 0;
	int m_iAvoidRate;
	int m_iAttackPoint;
	int m_iDefencePoint;
	int m_iHP;
	int m_iHeal;
	float m_fUseMPScale;
	float m_fDamageRate;
	bool m_bStern;
public:
	AddBuffStatus();
	~AddBuffStatus();
	void Reset();
	void AddBuff(BuffSkill _buff);
	inline void Value_Apply(Status& _status)
	{
		if (_status.m_iAttackPoint + m_iAttackPoint < 0)
			_status.m_iAttackPoint = 0;
		else
			_status.m_iAttackPoint += m_iAttackPoint;
		if (_status.m_iDefencePoint + m_iDefencePoint < 0)
			_status.m_iDefencePoint = 0;
		else
			_status.m_iDefencePoint += m_iDefencePoint;
		_status.m_iAvoidRate = m_iAvoidRate;
		if (m_iHP < 0)
		{
			if (_status.m_iHP + m_iHP < 0)
				_status.m_iHP = 0;
			else
				_status.m_iHP += m_iHP;
		}
		else
		{
			if (_status.m_iHP + m_iHP > _status.m_iMaxHP)
				_status.m_iHP = _status.m_iMaxHP;
			else
				_status.m_iHP += m_iHP;
		}
		_status.m_fUseMPScale = m_fUseMPScale;
		_status.m_fDamageRate = m_fDamageRate;
		_status.m_bStern = m_bStern;
	}
	inline void ShieldGage_Setting(int ShieldGage) { m_iShieldGage = ShieldGage; }
	inline int Get_Heal() { return m_iHeal; }
};

