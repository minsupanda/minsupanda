#include "Weapon.h"

Weapon::Weapon()
{
}

Weapon Weapon::Init(WeaponType _SetWeaponType, std::string _SetWeaponName, int _SetWeaponAttackPoint, int _SetButNeedGold)
{
	m_WeaponType = _SetWeaponType;
	m_WeaponName = _SetWeaponName;
	m_iAttackPoint = _SetWeaponAttackPoint;
	m_iBuyNeedGold = _SetButNeedGold;
	return *this;
}

Weapon::~Weapon()
{
}
