#include"GameManager.h"

void main()
{
	GameManager gamemanager;
	gamemanager.MainLoop();
}