#pragma once
#include "Weapon.h"
#include <vector>

class WeaponManager
{
private:
	std::vector <Weapon> m_WeaponList;
	static WeaponManager* m_hThis;
	WeaponManager();
	~WeaponManager();
public:
	static WeaponManager* Get_Instance()
	{
		if (m_hThis == NULL)
			m_hThis = new WeaponManager;
		return m_hThis;
	}
	inline std::vector<Weapon> Get_WeaponList() { return m_WeaponList; }
	void Init();
	std::vector<Weapon> Get_ClassWeapon(JobClass _PlayerClass);
};
