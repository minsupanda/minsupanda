#pragma once
#include"Skill.h"

enum class AttackType
{
	NONE,
	ONCE_ATTACK,
	DOUBLE_ATTACK
};

class ActiveSkill : public Skill
{
private:
	AttackType m_AttackType;
	float m_fValue;
	int m_iManaUsage; // ���� ��뷮
public:
	ActiveSkill();
	~ActiveSkill();
	virtual void Skill_Setting(std::string _SkillName) override;
	inline int Get_SkillMana() { return m_iManaUsage; }
	inline AttackType Get_AttackType() { return m_AttackType; }
	inline float Get_Value() { return m_fValue; }
	int UseSkill_Damage_Calculation(int& _AttackPoint);
};

