#pragma once
#include"Mecro.h"
#include"DrawManager.h"
#include"ConstValue.h"
#include"User.h"
#include"Monster.h"
#include"WeaponManager.h"
#include"SkillManager.h"
#include<map>

class SceneManager
{
public:
	static int CurScene_Confirm(SceneType _eCurScene)
	{
		std::map<int, std::string> mapPrintString;
		switch (_eCurScene)
		{
		case SceneType::JOB_CHOICE_SCENE:
			return JobChoice_ScenePrint(_eCurScene);

		case SceneType::GAME_PROGRESS_CHOICE_SCENE:
			return GameProgressChoice_ScenePrint(_eCurScene);

		case SceneType::CHARACTER_MANAGEMENT_SCENE:
			return CharacterManagement_ScenePrint(_eCurScene);

		case SceneType::SHOP_SCENE:
			return Shop_ScenePrint(_eCurScene);	

		case SceneType::SKILL_CHANGE_SCENE:
			return SkillChange_ScenePrint(_eCurScene);

		case SceneType::FIGHT_SCENE:
			return Fight_ScenePrint(_eCurScene);

		case SceneType::USE_SKILL_SCENE:
			return UseSkillScenePrint(_eCurScene);
		}
	}

	static void CurScene_Confirm(SceneType _eCurScene, Monster _CurMonster)
	{
		std::map<int, std::string> mapPrintString;
		switch(_eCurScene)
		{
		case SceneType::STAGE_CLEAR_SCENE:
			StageClear_ScenePrint(_eCurScene, _CurMonster);
		}
	}

	static int JobChoice_ScenePrint(SceneType _eCurScene)
	{
		std::map<int, std::string> mapPrintString;
		DrawManager::DrawMidText(s_UI_JOB_CHOICE_MENU, WIDTH, HEIGHT * 0.4f);
		mapPrintString.insert(std::make_pair(static_cast<int>(JobChoiceMenu::KNIGHT_CHOICE), s_UI_JOB_CHOICE_FRIST));
		mapPrintString.insert(std::make_pair(static_cast<int>(JobChoiceMenu::ARCHER_CHOICE), s_UI_JOB_CHOICE_SECOND));
		mapPrintString.insert(std::make_pair(static_cast<int>(JobChoiceMenu::WIZARD_CHOICE), s_UI_JOB_CHOICE_THIRD));
		return Choice_Scene_Draw<ActionTypeMenu>(_eCurScene, mapPrintString, WIDTH, static_cast<float>(HEIGHT), 0.5f);
	}
	
	static int GameProgressChoice_ScenePrint(SceneType _eCurScene)
	{
		std::map<int, std::string> mapPrintString;
		mapPrintString.insert(std::make_pair(static_cast<int>(GameProgressChoiceMenu::STAGE_PROGRESS), s_UI_STAGE_PROGRESS));
		mapPrintString.insert(std::make_pair(static_cast<int>(GameProgressChoiceMenu::CHARACTER_MANAGEMENT), s_UI_CHARACTER_MANAGEMENT));
		return Choice_Scene_Draw<GameProgressChoiceMenu>(_eCurScene, mapPrintString, s_RIGHT_BOX.m_iLeft + s_RIGHT_BOX.m_iRight, static_cast<float>(s_RIGHT_BOX.m_iTop + s_RIGHT_BOX.m_iBottom), 0.4f);
	}

	static int Fight_ScenePrint(SceneType _eCurScene)
	{
		std::map<int, std::string> mapPrintString;
		mapPrintString.insert(std::make_pair(static_cast<int>(ActionTypeMenu::DEFAULT_ATTACK), s_UI_DEFAULT_ATTACK));
		mapPrintString.insert(std::make_pair(static_cast<int>(ActionTypeMenu::DEFENSE), s_UI_DEFENSE));
		mapPrintString.insert(std::make_pair(static_cast<int>(ActionTypeMenu::USE_SKILL), s_UI_USE_SKILL));
		return Choice_Scene_Draw<ActionTypeMenu>(_eCurScene, mapPrintString, s_LEFT_BOX.m_iLeft + s_LEFT_BOX.m_iRight, static_cast<float>(s_LEFT_BOX.m_iBottom + s_LEFT_BOX.m_iTop), 0.7f);
	}

	static int CharacterManagement_ScenePrint(SceneType _eCurScene)
	{
		std::map<int, std::string> mapPrintString;
		mapPrintString.insert(std::make_pair(static_cast<int>(CharacterManageMentMenu::SHOP), s_UI_SHOP));
		mapPrintString.insert(std::make_pair(static_cast<int>(CharacterManageMentMenu::SKILL_CHANGE), s_UI_SKILL_CHANGE));
		return Choice_Scene_Draw<CharacterManageMentMenu>(_eCurScene, mapPrintString, s_RIGHT_BOX.m_iLeft + s_RIGHT_BOX.m_iRight, static_cast<float>(s_RIGHT_BOX.m_iTop + s_RIGHT_BOX.m_iBottom), 0.4f);
	}

	static int Shop_ScenePrint(SceneType _eCurScene)
	{
		std::map<int, std::string> mapPrintString;
		std::vector<Weapon> TmpWeaponList = WeaponManager::Get_Instance()->Get_ClassWeapon(User::Get_Instance()->Get_MyCharacter()->Get_JobClass());
		mapPrintString.insert(std::make_pair(static_cast<int>(ShoppingMenu::FIRST_WEAPON), TmpWeaponList[1].Get_WeaponName() + " : " + std::to_string(TmpWeaponList[1].Get_BuyNeedGold()) + "Gold"));
		mapPrintString.insert(std::make_pair(static_cast<int>(ShoppingMenu::SECOND_WEAPON), TmpWeaponList[2].Get_WeaponName() + " : " + std::to_string(TmpWeaponList[2].Get_BuyNeedGold()) + "Gold"));
		mapPrintString.insert(std::make_pair(static_cast<int>(ShoppingMenu::THIRD_WEAPON), TmpWeaponList[3].Get_WeaponName() + " : " + std::to_string(TmpWeaponList[3].Get_BuyNeedGold()) + "Gold"));
		while (1)
		{
			DrawManager::EraseUiBox(s_RIGHT_BOX.m_iLeft, s_RIGHT_BOX.m_iTop, s_RIGHT_BOX.m_iRight, s_RIGHT_BOX.m_iBottom);
			DrawManager::DrawMidText(s_UI_SHOP, s_RIGHT_BOX.m_iLeft + s_RIGHT_BOX.m_iRight, static_cast<float>(s_RIGHT_BOX.m_iTop + s_RIGHT_BOX.m_iBottom) * 0.2f);
			DrawManager::DrawMidText(s_UI_HAVE_GOLD + std::to_string(User::Get_Instance()->Get_Gold()), s_RIGHT_BOX.m_iLeft + s_RIGHT_BOX.m_iRight, static_cast<float>(s_RIGHT_BOX.m_iTop + s_RIGHT_BOX.m_iBottom) * 0.3f);
			int iChoiceMenu = Choice_Scene_Draw<ShoppingMenu>(_eCurScene, mapPrintString, s_RIGHT_BOX.m_iLeft + s_RIGHT_BOX.m_iRight, static_cast<float>(s_RIGHT_BOX.m_iTop + s_RIGHT_BOX.m_iBottom), 0.4f);
			if (iChoiceMenu == ESC)
				return iChoiceMenu;
			else if(User::Get_Instance()->Get_Gold() >= TmpWeaponList[iChoiceMenu + 1].Get_BuyNeedGold())
				return iChoiceMenu + 1; // ���� List���� �ε��� 1������ �����ϹǷ�.
			else
			{
				DrawManager::EraseUiBox(s_RIGHT_BOX.m_iLeft, s_RIGHT_BOX.m_iTop, s_RIGHT_BOX.m_iRight, s_RIGHT_BOX.m_iBottom);
				DrawManager::DrawMidText("��尡 �����մϴ�!", s_RIGHT_BOX.m_iLeft + s_RIGHT_BOX.m_iRight, static_cast<float>(s_RIGHT_BOX.m_iTop + s_RIGHT_BOX.m_iBottom) * 0.5f);
				getch();
			}
		}
	}

	static int SkillChange_ScenePrint(SceneType _eCurScene)
	{
		int iWidth = s_LEFT_BOX.m_iLeft + s_LEFT_BOX.m_iRight;
		float iHeight = static_cast<float>(s_LEFT_BOX.m_iTop + s_LEFT_BOX.m_iBottom);
		PlayableCharacter* TmpMyCharacter = User::Get_Instance()->Get_MyCharacter();
		ActiveSkill* TmpActiveSkillList = TmpMyCharacter->Get_CurUse_ActiveSkill();
		PassiveSkill* TmpPassiveSkillList = TmpMyCharacter->Get_CurUse_PassiveSkill();
		while (1)
		{
			std::map<int, std::string> mapPrintString;
			DrawManager::EraseUiBox(s_LEFT_BOX.m_iLeft, s_LEFT_BOX.m_iTop, s_LEFT_BOX.m_iRight, s_LEFT_BOX.m_iBottom);
			DrawManager::EraseUiBox(s_RIGHT_BOX.m_iLeft, s_RIGHT_BOX.m_iTop, s_RIGHT_BOX.m_iRight, s_RIGHT_BOX.m_iBottom);
			DrawManager::DrawUiBox(s_LOG_BOX.m_iLeft, s_LOG_BOX.m_iTop, s_LOG_BOX.m_iRight, s_LOG_BOX.m_iBottom);
			mapPrintString.insert(std::make_pair(static_cast<int>(SkillChangeMenu::ACTIVE_SLOT_1), TmpActiveSkillList[static_cast<int>(SkillChangeMenu::ACTIVE_SLOT_1)].Get_SkillName() + " (�ʿ丶�� : " + std::to_string(TmpActiveSkillList[static_cast<int>(SkillChoiceMenu::FRIST)].Get_SkillMana()) + ")"));
			mapPrintString.insert(std::make_pair(static_cast<int>(SkillChangeMenu::ACTIVE_SLOT_2), TmpActiveSkillList[static_cast<int>(SkillChangeMenu::ACTIVE_SLOT_2)].Get_SkillName() + " (�ʿ丶�� : " + std::to_string(TmpActiveSkillList[static_cast<int>(SkillChoiceMenu::SECOND)].Get_SkillMana()) + ")"));
			mapPrintString.insert(std::make_pair(static_cast<int>(SkillChangeMenu::ACTIVE_SLOT_3), TmpActiveSkillList[static_cast<int>(SkillChangeMenu::ACTIVE_SLOT_3)].Get_SkillName() + " (�ʿ丶�� : " + std::to_string(TmpActiveSkillList[static_cast<int>(SkillChoiceMenu::THIRD)].Get_SkillMana()) + ")"));
			mapPrintString.insert(std::make_pair(static_cast<int>(SkillChangeMenu::PASSIVE), TmpPassiveSkillList->Get_SkillName()));
			PassiveSkill_Explanation(*TmpPassiveSkillList);
			int iChoiceMenu = Choice_Scene_Draw<SkillChangeMenu>(_eCurScene, mapPrintString, iWidth, iHeight, 0.3f);
			if (iChoiceMenu == ESC)
				return iChoiceMenu;
			else if (iChoiceMenu == static_cast<int>(SkillChangeMenu::PASSIVE))
				ChageSkillMenu_Print(_eCurScene, TmpPassiveSkillList);
			else
				ChageSkillMenu_Print(_eCurScene, &TmpActiveSkillList[iChoiceMenu]);
		}
	}

	static void ChageSkillMenu_Print(SceneType _eCurScene, Skill* _CurUseSkill)
	{
		DrawManager::EraseUiBox(s_RIGHT_BOX.m_iLeft, s_RIGHT_BOX.m_iTop, s_RIGHT_BOX.m_iRight, s_RIGHT_BOX.m_iBottom);
		int i = 0;
		int iChoiceMenu = ESC;
		std::map<int, std::string> mapPrintString;
		int iWidth = s_RIGHT_BOX.m_iLeft + s_RIGHT_BOX.m_iRight;
		float iHeight = static_cast<float>(s_LEFT_BOX.m_iTop + s_LEFT_BOX.m_iBottom);
		PlayableCharacter* TmpMyCharacter = User::Get_Instance()->Get_MyCharacter();
		switch (_CurUseSkill->Get_SkillUseType())
		{
		case SkillUseType::ACTIVE:
		{
			TmpMyCharacter->Possess_ActiveSkill_Check(mapPrintString);
			if (mapPrintString.size() <= 0)
			{
				DrawManager::DrawMidText(s_UI_DONT_HAVE_SKILL, iWidth, iHeight * 0.5f);
				getch();
			}
			else
			{
				iChoiceMenu = Choice_Scene_Draw<SkillChangeMenu>(_eCurScene, mapPrintString, iWidth, iHeight, 0.3f);
				if (iChoiceMenu == ESC)
					return;
				else 
				{
					std::string SkillName = mapPrintString.find(iChoiceMenu)->second;
					TmpMyCharacter->Skill_Change(_CurUseSkill, TmpMyCharacter->Get_ActiveSkill(SkillName));
				}
			}
		}
		break;

		case SkillUseType::PASSIVE:
		{
			TmpMyCharacter->Possess_PassiveSkill_Check(mapPrintString);
			if (mapPrintString.size() <= 0)
			{
				DrawManager::DrawMidText(s_UI_DONT_HAVE_SKILL, iWidth, iHeight * 0.5f);
				getch();
			}
			else
			{
				iChoiceMenu = Choice_Scene_Draw<SkillChangeMenu>(_eCurScene, mapPrintString, iWidth, iHeight, 0.3f);
				if (iChoiceMenu == ESC)
					return;
				else
				{
					std::string SkillName = mapPrintString.find(iChoiceMenu)->second;
					TmpMyCharacter->Skill_Change(_CurUseSkill, TmpMyCharacter->Get_PassiveSkill(SkillName));
				}
			}
			break;
		}
		}
	}

	static int UseSkillScenePrint(SceneType _eCurScene)
	{
		std::map<int, std::string> mapPrintString;
		int iWidth = s_LEFT_BOX.m_iLeft + s_LEFT_BOX.m_iRight;
		float iHeight = static_cast<float>(s_LEFT_BOX.m_iTop + s_LEFT_BOX.m_iBottom);
		PlayableCharacter* TmpMyCharacter = User::Get_Instance()->Get_MyCharacter();
		ActiveSkill* TmpActiveSkillList = TmpMyCharacter->Get_CurUse_ActiveSkill();
		mapPrintString.insert(std::make_pair(static_cast<int>(SkillChoiceMenu::FRIST), TmpActiveSkillList[static_cast<int>(SkillChoiceMenu::FRIST)].Get_SkillName() + " (�ʿ丶�� : " + std::to_string(TmpActiveSkillList[static_cast<int>(SkillChoiceMenu::FRIST)].Get_SkillMana()) + ")"));
		mapPrintString.insert(std::make_pair(static_cast<int>(SkillChoiceMenu::SECOND), TmpActiveSkillList[static_cast<int>(SkillChoiceMenu::SECOND)].Get_SkillName() + " (�ʿ丶�� : " + std::to_string(TmpActiveSkillList[static_cast<int>(SkillChoiceMenu::SECOND)].Get_SkillMana()) + ")"));
		mapPrintString.insert(std::make_pair(static_cast<int>(SkillChoiceMenu::THIRD), TmpActiveSkillList[static_cast<int>(SkillChoiceMenu::THIRD)].Get_SkillName() + " (�ʿ丶�� : " + std::to_string(TmpActiveSkillList[static_cast<int>(SkillChoiceMenu::THIRD)].Get_SkillMana()) + ")"));
		while (1)
		{
			DrawManager::EraseUiBox(s_LEFT_BOX.m_iLeft, s_LEFT_BOX.m_iTop, s_LEFT_BOX.m_iRight, s_LEFT_BOX.m_iBottom);
			DrawManager::EraseUiBox(s_LOG_BOX.m_iLeft, s_LOG_BOX.m_iTop, s_LOG_BOX.m_iRight, s_LOG_BOX.m_iBottom);
			DrawManager::DrawMidText("�нú� : " + TmpMyCharacter->Get_CurUse_PassiveSkill()->Get_SkillName(), iWidth, iHeight * 0.2f);
			DrawManager::DrawMidText("���� ���� : " + std::to_string(TmpMyCharacter->Get_MP()), iWidth, iHeight * 0.3f);
			PassiveSkill_Explanation(*User::Get_Instance()->Get_MyCharacter()->Get_CurUse_PassiveSkill());
			int iChoiceMenu = Choice_Scene_Draw<SkillChoiceMenu>(_eCurScene, mapPrintString, iWidth, iHeight, 0.4f);
			if (iChoiceMenu == ESC)
				return iChoiceMenu;
			else
			{
				bool bMPUsageCheck;
				std::vector<BuffSkill> TmpBuffList = TmpActiveSkillList[iChoiceMenu].Get_BuffList();
				int iMPUsage = TmpActiveSkillList[iChoiceMenu].Get_SkillMana();
				if (TmpBuffList.size() > 0)
				{
					for (auto iter = TmpBuffList.begin(); iter != TmpBuffList.end(); iter++)
					{
						if (iter->Get_BuffType() == BuffType::MANA_USAGE_INCREASE)
							bMPUsageCheck = TmpMyCharacter->SkillMana_Confirm(iMPUsage * 2);
						else
							bMPUsageCheck = TmpMyCharacter->SkillMana_Confirm(iMPUsage);
					}
				}
				else
					bMPUsageCheck = TmpMyCharacter->SkillMana_Confirm(iMPUsage);
				if (bMPUsageCheck == true)
					return iChoiceMenu;
				else
				{
					DrawManager::EraseUiBox(s_LEFT_BOX.m_iLeft, s_LEFT_BOX.m_iTop, s_LEFT_BOX.m_iRight, s_LEFT_BOX.m_iBottom);
					DrawManager::DrawMidText("������ �����մϴ�!", iWidth, iHeight * 0.5f);
					getch();
				}
			}
		}
	}

	static void StageClear_ScenePrint(SceneType _eCurScene, Monster _CurMonster)
	{
		std::map<int, std::string> mapPrintString;
		int iWidth = s_RIGHT_BOX.m_iLeft + s_RIGHT_BOX.m_iRight;
		int iHeight = s_RIGHT_BOX.m_iTop + s_RIGHT_BOX.m_iBottom;
		PlayableCharacter* TmpMyCharacter = User::Get_Instance()->Get_MyCharacter();
		ActiveSkill CompensationActiveSkill;
		PassiveSkill CompensationPassiveSkill;
		DrawManager::EraseUiBox(s_RIGHT_BOX.m_iLeft, s_RIGHT_BOX.m_iTop, s_RIGHT_BOX.m_iRight, s_RIGHT_BOX.m_iBottom);
		DrawManager::EraseUiBox(s_LOG_BOX.m_iLeft, s_LOG_BOX.m_iTop, s_LOG_BOX.m_iRight, s_LOG_BOX.m_iBottom);
		DrawManager::DrawMidText(_CurMonster.Get_CharacterName() + " " + s_UI_MONSTER_KILL, iWidth, iHeight * 0.3f);
		DrawManager::DrawMidText(s_UI_STAGE_CLEAR, iWidth, (s_RIGHT_BOX.m_iTop + s_RIGHT_BOX.m_iBottom) * 0.4f);
		DrawManager::DrawMidText(std::to_string(_CurMonster.Get_Gold()) + s_UI_GET_GOLD, iWidth, iHeight * 0.5f);
		getch();

		bool Get_Skill = false;
		int iRandomSkill;
		while (Get_Skill == false)
		{
			iRandomSkill = rand() % static_cast<int>(SkillUseType::END);
			if (iRandomSkill == static_cast<int>(SkillUseType::ACTIVE))
			{
				CompensationActiveSkill = SkillManager::Get_Instance()->Get_RandomPlayerActiveSkill(TmpMyCharacter->Get_JobClass());
				if (TmpMyCharacter->ActiveSkill_Overlap_Check(CompensationActiveSkill) == false)
					Get_Skill = true;
			}
			else if (iRandomSkill == static_cast<int>(SkillUseType::PASSIVE))
			{
				CompensationPassiveSkill = SkillManager::Get_Instance()->Get_RandomPlayerPassiveSkill(TmpMyCharacter->Get_JobClass());
				if (TmpMyCharacter->PassiveSkill_Overlap_Check(CompensationPassiveSkill) == false)
					Get_Skill = true;
			}
		}

		DrawManager::EraseUiBox(s_RIGHT_BOX.m_iLeft, s_RIGHT_BOX.m_iTop, s_RIGHT_BOX.m_iRight, s_RIGHT_BOX.m_iBottom);

		switch (static_cast<SkillUseType>(iRandomSkill))
		{
		case SkillUseType::ACTIVE:
			ActiveSkill_Explanation_Print(CompensationActiveSkill, CompensationActiveSkill.Get_BuffList());
			DrawManager::DrawMidText("��ų : " + CompensationActiveSkill.Get_SkillName(), iWidth, iHeight * 0.3f);
			mapPrintString.insert(std::make_pair(static_cast<int>(StageClearMenu::SKILL_GET), "ȹ���ϱ�"));
			mapPrintString.insert(std::make_pair(static_cast<int>(StageClearMenu::SKILL_THORW), "������"));
			if (Choice_Scene_Draw<StageClearMenu>(_eCurScene, mapPrintString, iWidth, static_cast<float>(iHeight), 0.4f) == static_cast<int>(StageClearMenu::SKILL_GET))
				User::Get_Instance()->StageClearCompensation(&CompensationActiveSkill, _CurMonster.Get_Gold(), true);
			else
				User::Get_Instance()->StageClearCompensation(&CompensationActiveSkill, _CurMonster.Get_Gold(), false);
			// �� Ŭ������� skill�� ��ӹ޾Ƽ� ó���ϹǷ�, �Ű����� ������ Skill*�� ��ĳ�����ؼ� ������...? �̷��͵� ��ĳ�����̶�� �ϴ°ǰ�? ����ȯ�̶�� �ؾ��ϴ°ǰ�?
			break;

		case SkillUseType::PASSIVE:
			PassiveSkill_Explanation(CompensationPassiveSkill);
			DrawManager::DrawMidText("��ų : " + CompensationPassiveSkill.Get_SkillName(), iWidth, iHeight * 0.3f);
			mapPrintString.insert(std::make_pair(static_cast<int>(StageClearMenu::SKILL_GET), "ȹ���ϱ�"));
			mapPrintString.insert(std::make_pair(static_cast<int>(StageClearMenu::SKILL_THORW), "������"));
			if (Choice_Scene_Draw<StageClearMenu>(_eCurScene, mapPrintString, iWidth, static_cast<float>(iHeight), 0.4f) == static_cast<int>(StageClearMenu::SKILL_GET))
				User::Get_Instance()->StageClearCompensation(&CompensationPassiveSkill, _CurMonster.Get_Gold(), true);
			else
				User::Get_Instance()->StageClearCompensation(&CompensationPassiveSkill, _CurMonster.Get_Gold(), false);
			break;
		}		
	}

	static void PassiveSkill_Explanation(PassiveSkill TmpCurPassiveSkill)
	{
		std::vector<BuffSkill> TmpBuffSkill = TmpCurPassiveSkill.Get_BuffList();
		for (auto iter = TmpBuffSkill.begin(); iter != TmpBuffSkill.end(); iter++)
			PassiveSkill__Buff_Explanation_Print(*iter);
	}

	static void PassiveSkill__Buff_Explanation_Print(BuffSkill _TmpBuffSkill)
	{
		std::string Messege;
		switch (_TmpBuffSkill.Get_BuffType())
		{
		case BuffType::SHIEID:
			Messege = std::format("�нú� ȿ�� : �� �������� ���带 {}��ŭ ȹ��", _TmpBuffSkill.Get_BuffValue());
			break;

		case BuffType::ATTACT_INCREASE:
			Messege = std::format("�нú� ȿ�� : �� �������� ���ݷ��� {}��ŭ ����", _TmpBuffSkill.Get_BuffValue());
			break;

		case BuffType::DEFENCE_INCREASE:
			Messege = std::format("�нú� ȿ�� : �� �������� ������ {}��ŭ ����", _TmpBuffSkill.Get_BuffValue());
			break;

		case BuffType::ATTACT_DECREASE:
			Messege = std::format("�нú� ȿ�� : �� �������� ���ݷ��� {}��ŭ ����", _TmpBuffSkill.Get_BuffValue());
			break;

		case BuffType::DEFENCE_DECREASE:
			Messege = std::format("�нú� ȿ�� : �� �������� ������ {}��ŭ ����", _TmpBuffSkill.Get_BuffValue());
			break;

		case BuffType::EVATION:
			Messege = std::format("�нú� ȿ�� : ��� ������ {}% Ȯ���� ȸ��", _TmpBuffSkill.Get_BuffValue());
			break;

		case BuffType::FAINTING:
			Messege = std::format("�нú� ȿ�� : ���� �� {}% Ȯ���� ��뿡�� ���� �ο�", _TmpBuffSkill.Get_BuffValue());
			break;

		case BuffType::BURNS:
			Messege = std::format("�нú� ȿ�� : ���� �� {}% Ȯ���� ��뿡�� ȭ�� �ο�", _TmpBuffSkill.Get_BuffValue());
			break;

		case BuffType::HP_CURE:
			Messege = std::format("�нú� ȿ�� : �� �� {}��ŭ ȸ��", _TmpBuffSkill.Get_BuffValue());
			break;
		}
		DrawManager::DrawPoint(Messege, s_LOG_BOX.m_iLeft + 1, s_LOG_BOX.m_iTop + 1);
	}

	static void ActvieSkill_Explanation_Text_Setting(int _ChoicedSkill)
	{
		DrawManager::EraseUiBox(s_LOG_BOX.m_iLeft, s_LOG_BOX.m_iTop + 1, s_LOG_BOX.m_iRight, s_LOG_BOX.m_iBottom);
		ActiveSkill TmpCurActiveSkill = User::Get_Instance()->Get_MyCharacter()->Get_CurUse_ActiveSkill()[_ChoicedSkill];
		std::vector<BuffSkill> TmpBuffList = TmpCurActiveSkill.Get_BuffList();
		ActiveSkill_Explanation_Print(TmpCurActiveSkill, TmpBuffList);
	}

	static void ActiveSkill_Explanation_Print(ActiveSkill _TmpCurActiveSkill, std::vector<BuffSkill> _TmpBuffList)
	{
		int iHeightIncrese = 2;
		switch (_TmpCurActiveSkill.Get_AttackType())
		{
		case AttackType::NONE:
		{
			DrawManager::DrawPoint("���ݷ� 0", s_LOG_BOX.m_iLeft + 1, s_LOG_BOX.m_iTop + iHeightIncrese);
			break;
		}
		case AttackType::ONCE_ATTACK:
		{
			std::string Messege = std::format("���ݷ� * {}��ŭ 1ȸ ����", _TmpCurActiveSkill.Get_Value());
			DrawManager::DrawPoint(Messege, s_LOG_BOX.m_iLeft + 1, s_LOG_BOX.m_iTop + iHeightIncrese);
			break;
		}
		case AttackType::DOUBLE_ATTACK:
		{
			std::string Messege = std::format("���ݷ� * {}��ŭ 2ȸ ����", _TmpCurActiveSkill.Get_Value());
			DrawManager::DrawPoint(Messege, s_LOG_BOX.m_iLeft + 1, s_LOG_BOX.m_iTop + iHeightIncrese);
			break;
		}
		}
		for (auto iter = _TmpBuffList.begin(); iter != _TmpBuffList.end(); iter++)
		{
			ActiveSkill_Buff_Explanation_Print(*iter, &(++iHeightIncrese));
		}
	}

	static void ActiveSkill_Buff_Explanation_Print(BuffSkill _TmpBuffSkill, int* _iHeightIncrese)
	{
		std::string Messege;
		switch (_TmpBuffSkill.Get_SkillTarget())
		{
		case ApplyTarget::MY_TEAM:
			Messege = std::format("Target : Player", _TmpBuffSkill.Get_BuffValue());
			break;

		case ApplyTarget::ENMEY_TEAM:
			Messege = std::format("Target : Enemy", _TmpBuffSkill.Get_BuffValue());
			break;
		}
		DrawManager::DrawPoint(Messege, s_LOG_BOX.m_iLeft + 1, s_LOG_BOX.m_iTop + (*_iHeightIncrese)++);

		Messege.clear();

		switch (_TmpBuffSkill.Get_BuffType())
		{
		case BuffType::SHIEID:
			DrawManager::DrawPoint("ȿ�� : ���� ����", s_LOG_BOX.m_iLeft + 1, s_LOG_BOX.m_iTop + (*_iHeightIncrese));
			Messege = std::format("���带 {}��ŭ ����", _TmpBuffSkill.Get_BuffValue());
			break;

		case BuffType::ATTACT_INCREASE:
			DrawManager::DrawPoint("ȿ�� : ���ݷ� ����", s_LOG_BOX.m_iLeft + 1, s_LOG_BOX.m_iTop + (*_iHeightIncrese));
			Messege = std::format("���ݷ��� {}�ϰ� {}��ŭ ����", _TmpBuffSkill.Get_BuffTurn(), _TmpBuffSkill.Get_BuffValue());
			break;

		case BuffType::DEFENCE_INCREASE:
			DrawManager::DrawPoint("ȿ�� : ���� ����", s_LOG_BOX.m_iLeft + 1, s_LOG_BOX.m_iTop + (*_iHeightIncrese));
			Messege = std::format("������ {}�ϰ� {}��ŭ ����", _TmpBuffSkill.Get_BuffTurn(), _TmpBuffSkill.Get_BuffValue());
			break;

		case BuffType::ATTACT_DECREASE:
			DrawManager::DrawPoint("ȿ�� : ���ݷ� ����", s_LOG_BOX.m_iLeft + 1, s_LOG_BOX.m_iTop + (*_iHeightIncrese));
			Messege = std::format("���ݷ��� {}�ϰ� {}��ŭ ����", _TmpBuffSkill.Get_BuffTurn(), _TmpBuffSkill.Get_BuffValue());
			break;

		case BuffType::DEFENCE_DECREASE:
			DrawManager::DrawPoint("ȿ�� : ���� ����", s_LOG_BOX.m_iLeft + 1, s_LOG_BOX.m_iTop + (*_iHeightIncrese));
			Messege = std::format("������ {}�ϰ� {}��ŭ ����", _TmpBuffSkill.Get_BuffTurn(), _TmpBuffSkill.Get_BuffValue());
			break;

		case BuffType::EVATION:
			DrawManager::DrawPoint("ȿ�� : ȸ���� ����", s_LOG_BOX.m_iLeft + 1, s_LOG_BOX.m_iTop + (*_iHeightIncrese));
			Messege = std::format("���� ������ {}�ϰ� {}%�� Ȯ���� ȸ��", _TmpBuffSkill.Get_BuffTurn(), _TmpBuffSkill.Get_BuffValue());
			break;

		case BuffType::FAINTING:
			DrawManager::DrawPoint("ȿ�� : ����", s_LOG_BOX.m_iLeft + 1, s_LOG_BOX.m_iTop + (*_iHeightIncrese));
			Messege = std::format("������ �ɸ� ����� {}�ϰ� �ൿ�Ҵ�", _TmpBuffSkill.Get_BuffTurn());
			break;

		case BuffType::BURNS:
			DrawManager::DrawPoint("ȿ�� : ȭ��", s_LOG_BOX.m_iLeft + 1, s_LOG_BOX.m_iTop + (*_iHeightIncrese));
			Messege = std::format("ȭ�� �ɸ� ����� {}�ϰ� {}��ŭ ü�� ����", _TmpBuffSkill.Get_BuffTurn(), _TmpBuffSkill.Get_BuffValue());
			break;

		case BuffType::HP_CURE:
			DrawManager::DrawPoint("ȿ�� : ȸ��", s_LOG_BOX.m_iLeft + 1, s_LOG_BOX.m_iTop + (*_iHeightIncrese));
			Messege = std::format("HP�� {}�ϰ� {} ��ŭ ȸ��", _TmpBuffSkill.Get_BuffTurn(), _TmpBuffSkill.Get_BuffValue());
			break;

		case BuffType::MANA_USAGE_INCREASE:
			DrawManager::DrawPoint("ȿ�� : ���� ��뷮 ����", s_LOG_BOX.m_iLeft + 1, s_LOG_BOX.m_iTop + (*_iHeightIncrese));
			Messege = std::format("���� ��뷮�� {}�ϰ� {}�� ��ŭ ����", _TmpBuffSkill.Get_BuffTurn(), _TmpBuffSkill.Get_BuffValue());
			break;

		case BuffType::ATTACK_DAMAGE_INCREASE:
			DrawManager::DrawPoint("ȿ�� : ������ ����", s_LOG_BOX.m_iLeft + 1, s_LOG_BOX.m_iTop + (*_iHeightIncrese));
			Messege = std::format("���ݽ� �������� {}�ϰ� {}�� ��ŭ ����", _TmpBuffSkill.Get_BuffTurn(), _TmpBuffSkill.Get_BuffValue());
			break;
		}
		++(*_iHeightIncrese);
		DrawManager::DrawPoint(Messege, s_LOG_BOX.m_iLeft + 1, s_LOG_BOX.m_iTop + (*_iHeightIncrese)++);
}

	static void PlayerStatus_Print(RectSize _RectSize)
	{
		int iWidth = _RectSize.m_iLeft + _RectSize.m_iRight;
		float iHeight = static_cast<float>(_RectSize.m_iBottom + _RectSize.m_iTop);
		PlayableCharacter* TmpMyCharacter = User::Get_Instance()->Get_MyCharacter();
		DrawManager::DrawMidText(s_UI_PLAYER_Name + TmpMyCharacter->Get_CharacterName(), iWidth, iHeight * 0.1f);
		if(TmpMyCharacter->Get_ShieldGage() > 0)
			DrawManager::DrawMidText(s_UI_HP + std::to_string(TmpMyCharacter->Get_HP()) + " + " + std::to_string(TmpMyCharacter->Get_ShieldGage()), iWidth, iHeight * 0.2f);
		else
			DrawManager::DrawMidText(s_UI_HP + std::to_string(TmpMyCharacter->Get_HP()), iWidth, iHeight * 0.2f);
		DrawManager::DrawMidText(s_UI_MP + std::to_string(TmpMyCharacter->Get_MP()), iWidth, iHeight * 0.3f);
		DrawManager::DrawMidText(s_UI_ATTTACK_POINT + std::to_string(TmpMyCharacter->Get_AttackPoint()) + " + " + std::to_string(TmpMyCharacter->Get_Weapon().Get_WeaponAttackPoint()), iWidth, iHeight * 0.4f);
		DrawManager::DrawMidText(s_UI_DEFENCE_POINT + std::to_string(TmpMyCharacter->Get_DefencePoint()), iWidth, iHeight * 0.5f);
		DrawManager::DrawMidText(s_UI_PLAYER_WEAPON + TmpMyCharacter->Get_Weapon().Get_WeaponName(), iWidth, iHeight * 0.6f);
		DrawManager::DrawMidText(s_UI_DEFAULT_ATTACK, iWidth, iHeight * 0.7f);
		DrawManager::DrawMidText(s_UI_DEFENSE, iWidth, iHeight * 0.8f);
		DrawManager::DrawMidText(s_UI_USE_SKILL, iWidth, iHeight * 0.9f);
	}

	static void MonsterStatus_Print(RectSize _RectSize, Monster _CurMonster)
	{
		int iWidth = _RectSize.m_iLeft + _RectSize.m_iRight;
		float iHeight = static_cast<float>(_RectSize.m_iBottom + _RectSize.m_iTop);
		DrawManager::DrawMidText(s_UI_MONSTER_Name + _CurMonster.Get_CharacterName(), iWidth, iHeight * 0.1f);
		if (_CurMonster.Get_ShieldGage() > 0)
			DrawManager::DrawMidText(s_UI_HP + std::to_string(_CurMonster.Get_HP()) + " + " + std::to_string(_CurMonster.Get_ShieldGage()), iWidth, iHeight * 0.2f);
		else
			DrawManager::DrawMidText(s_UI_HP + std::to_string(_CurMonster.Get_HP()), iWidth, iHeight * 0.2f);
		DrawManager::DrawMidText(s_UI_MP + std::to_string(_CurMonster.Get_MP()),iWidth, iHeight * 0.3f);
		DrawManager::DrawMidText(s_UI_ATTTACK_POINT + std::to_string(_CurMonster.Get_AttackPoint()), iWidth, iHeight * 0.4f);
		DrawManager::DrawMidText(s_UI_DEFENCE_POINT + std::to_string(_CurMonster.Get_DefencePoint()), iWidth, iHeight * 0.5f);
	}

	template <typename CurMenu>
	static CurMenu Get_CurMenu(SceneType _eCurScene)
	{
		switch (_eCurScene)
		{
		case SceneType::JOB_CHOICE_SCENE:
			return static_cast<CurMenu>(JobChoiceMenu::KNIGHT_CHOICE);

		case SceneType::GAME_PROGRESS_CHOICE_SCENE:
			return static_cast<CurMenu>(GameProgressChoiceMenu::STAGE_PROGRESS);

		case SceneType::FIGHT_SCENE:
			return static_cast<CurMenu>(ActionTypeMenu::DEFAULT_ATTACK);

		case SceneType::SHOP_SCENE:
			return static_cast<CurMenu>(ShoppingMenu::FIRST_WEAPON);

		case SceneType::SKILL_CHANGE_SCENE:
			return static_cast<CurMenu>(SkillChangeMenu::ACTIVE_SLOT_1);

		case SceneType::CHARACTER_MANAGEMENT_SCENE:
			return static_cast<CurMenu>(CharacterManageMentMenu::SHOP);

		case SceneType::USE_SKILL_SCENE:
			return static_cast<CurMenu>(SkillChoiceMenu::FRIST);

		case SceneType::STAGE_CLEAR_SCENE:
			return static_cast<CurMenu>(StageClearMenu::SKILL_GET);
		}
	}

	template <typename CurMenu>
	static void SceneChoiceTextPrint(SceneType _eCurScene, CurMenu _eChoiceMenu, std::map<int, std::string> _mapPrintString, float _fWidth, float _fStartHeight, float _fIncreaseHeight)
	{
		for (std::map<int, std::string>::iterator iter = _mapPrintString.begin(); iter != _mapPrintString.end(); iter++)
		{
			if (iter->first == static_cast<int>(_eChoiceMenu))
			{
				DrawManager::DrawMidText(iter->second + " ��", _fWidth, _fStartHeight * _fIncreaseHeight);
			}
			else
			{
				DrawManager::DrawMidText(iter->second, _fWidth, _fStartHeight * _fIncreaseHeight);
			}
			_fIncreaseHeight += 0.1f;
		}
	}

	template <typename CurMenu>
	static void SceneChoiceTextErase(SceneType _eCurScene, CurMenu _eChoiceMenu, std::map<int, std::string> _mapPrintString, float _fWidth, float _fStartHeight, float _fIncreaseHeight)
	{
		std::string PrintText;
		for (std::map<int, std::string>::iterator iter = _mapPrintString.begin(); iter != _mapPrintString.end(); iter++)
		{
			DrawManager::EraseText(iter->second + " ��",_fWidth, _fStartHeight * _fIncreaseHeight);
			_fIncreaseHeight += 0.1f;
		}
	}

	template <typename CurScene>
	static int Choice_Scene_Draw(SceneType _eChoiceScene, std::map<int, std::string> _mapPrintString, float _fWidth, float _fStartHeight, float _fIncreaseHeight)
	{
		std::string PrintText;
		CurScene eChoiceMenu = Get_CurMenu<CurScene>(_eChoiceScene);
		while (1)
		{
			unsigned char chSelect;
			int iChoice = static_cast<int>(eChoiceMenu);
			if (_eChoiceScene == SceneType::USE_SKILL_SCENE)
				ActvieSkill_Explanation_Text_Setting(iChoice);
			else if (_eChoiceScene == SceneType::SKILL_CHANGE_SCENE)
			{
				if (iChoice - _mapPrintString.size() != static_cast<int>(SkillChangeMenu::PASSIVE))
					ActvieSkill_Explanation_Text_Setting(iChoice);
			}
			SceneChoiceTextPrint(_eChoiceScene, eChoiceMenu, _mapPrintString, _fWidth, _fStartHeight, _fIncreaseHeight);
			chSelect = getch();
			if (chSelect == 224)
				chSelect = getch();
			else if (chSelect != ENTER && chSelect != ESC)
				continue;
			switch (chSelect)
			{
			case UP:
				iChoice = (iChoice - 1 + _mapPrintString.size()) %_mapPrintString.size();
				break;
			case DOWN:
				iChoice = (iChoice + 1) % _mapPrintString.size();
				break;
			case ENTER:
				return iChoice;

			case ESC:
				if (_eChoiceScene == SceneType::CHARACTER_MANAGEMENT_SCENE || _eChoiceScene == SceneType::SHOP_SCENE || _eChoiceScene == SceneType::SKILL_CHANGE_SCENE || _eChoiceScene == SceneType::USE_SKILL_SCENE)
					return ESC;
				else
					break;

			default: break;
			}
			eChoiceMenu = static_cast<CurScene>(iChoice);
			SceneChoiceTextErase(_eChoiceScene, eChoiceMenu, _mapPrintString, _fWidth, _fStartHeight, _fIncreaseHeight);
		}
	}
};