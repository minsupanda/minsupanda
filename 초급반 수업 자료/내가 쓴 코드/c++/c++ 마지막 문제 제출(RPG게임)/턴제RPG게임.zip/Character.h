#pragma once
#include"Mecro.h"
#include"ActiveSkill.h"
#include"PassiveSkill.h"
#include"Skill.h"
#include"BuffSkill.h"
#include"Weapon.h"
#include"AddBuffStatus.h"
#include<list>
#include<map>

enum RewardStatus
{
	HP_REWARD = 5,
	MP_REWARD = 10
};

enum class TurnResult
{
	PROGRESS,
	SKIP,
	END
};

enum class SkillSlot
{
	FRIST_SLOT,
	SECOND_SLOT,
	THIRD_SLOT,
	SLOT_END
};

enum MinStatus
{
	MIN_ATTACK_POINT = 1,
	MIN_DEFENCE_POINT = 0
};

struct ActionLog
{
	ActionTypeMenu m_CurAction;
	std::string SkillName;
	bool m_SkillAttack;
	int m_iTotalDamage;
	bool bAttackResult = true;
	bool bDefenceResult = false;
	bool bEvationResult = false;
};

class Character
{
private:
	CharacterType m_CharacterType;
	std::string m_CharacterName;
	Status m_OriginStatus;
	Status m_CurStatus;
	int m_iDamage;
	int m_iUseMana;
	int m_iTurn;
	AddBuffStatus m_AddBuffStatus;
	std::list<BuffSkill> m_CurAppliedBuffSkillList; // ���� ����� ��������Ʈ
	ActiveSkill m_MountedActiveSkillList[static_cast<int>(SkillSlot::SLOT_END)]; // ���� ������� ��ų����Ʈ
	PassiveSkill m_MountedPassiveSkill;
	std::list<ActiveSkill> m_PossessActiveSkillList; // ���� �������� ��ų����Ʈ
	std::list<PassiveSkill> m_PossessPassiveSkillList; // ���� �������� ��ų����Ʈ
public:
	Character();
	virtual ~Character();
	virtual TurnResult Action_Choice(Character* _Target, ActionLog& _ActionLogRecord);
	inline void Defence_On_Off(bool _Defence) { m_CurStatus.m_bDefence = _Defence; }
	inline void ActiveSkill_Setting(int _SkillSlot, ActiveSkill _SetSkill)
	{
		m_PossessActiveSkillList.push_back(_SetSkill);
		m_MountedActiveSkillList[_SkillSlot] = _SetSkill;
	}
	inline void PassiveSkill_Setting(PassiveSkill _SetSkill)
	{
		m_PossessPassiveSkillList.push_back(_SetSkill);
		m_MountedPassiveSkill = _SetSkill;
	}
	inline CharacterType Get_CharacterType() { return m_CharacterType; }
	inline std::string Get_CharacterName() { return m_CharacterName; }
	inline int Get_AttackPoint() { return m_CurStatus.m_iAttackPoint; }
	inline int Get_DefencePoint() { return m_CurStatus.m_iDefencePoint; }
	inline int Get_HP() { return m_CurStatus.m_iHP; }
	inline int Get_MP() { return m_CurStatus.m_iMP; }
	inline int Get_ShieldGage() { return m_CurStatus.m_iShieldGage; }
	inline ActiveSkill* Get_CurUse_ActiveSkill() { return m_MountedActiveSkillList; }
	inline PassiveSkill* Get_CurUse_PassiveSkill() { return &m_MountedPassiveSkill; }
	inline std::list<BuffSkill>* Get_AppliedBuffSkillList() { return &m_CurAppliedBuffSkillList; }
	inline ActiveSkill* Get_ActiveSkill(std::string _SkillName)
	{
		for (auto iter = m_PossessActiveSkillList.begin(); iter != m_PossessActiveSkillList.end(); iter++)
		{
			if (iter->Get_SkillName() == _SkillName)
				return &(*iter);
		}
	}
	inline PassiveSkill* Get_PassiveSkill(std::string _SkillName)
	{
		for (auto iter = m_PossessPassiveSkillList.begin(); iter != m_PossessPassiveSkillList.end(); iter++)
		{
			if (iter->Get_SkillName() == _SkillName)
				return &(*iter);
		}
	}
	void Init(CharacterType _CharacterType, std::string _SetCharacterName, int _SetHP, int _SetMP, int _SetAttackPoint, int _SetDefencePoint);
	TurnResult Check_Before_Proceeding();
	bool SkillMana_Confirm(int _iMPUsage);
	bool TurnSkip_Check();
	void PreAction_Buff_Apply();
	void Buff_Value_Apply();
	void Acting_Buff_Value_Apply();
	void DefaultAttack_Action(Character* _Target, int _WeaponDamage, ActionLog& _ActionLogRecord);
	void UsedSkill_Action(Character* _Target, int _WeaponDamage, int _ChoiceSkill, ActionLog& _ActionLogRecord);
	void UsedSkill_Buff_Add(Character* _Target, ActiveSkill _CurUseSkill);
	bool Buff_OverlapCheck(BuffSkill _CurUseBuffSkill);
	void Hit_By(int _HitDamage, ActionLog& _ActionLogRecord);
	bool AttackBlock_Check(ActionLog& _ActionLogRecord);
	void AcquiredSkill_Save(Skill* _GetSkill);
	void ShieldGage_Decrease(int& _HitDamage);
	void Possess_ActiveSkill_Check(std::map<int, std::string>& _mapPrintString);
	void Possess_PassiveSkill_Check(std::map<int, std::string>& _mapPrintString);
	bool CurUse_ActiveSkill_Check(ActiveSkill _Skill);
	bool CurUse_PassiveSkill_Check(PassiveSkill _Skill);
	inline bool ActiveSkill_Overlap_Check(ActiveSkill _ActiveSkill)
	{
		for (auto iter = m_PossessActiveSkillList.begin(); iter != m_PossessActiveSkillList.end(); iter++)
		{
			if (iter->Get_SkillName() == _ActiveSkill.Get_SkillName())
				return true;
		}
		return false;
	}
	inline bool PassiveSkill_Overlap_Check(PassiveSkill _PassiveSkill)
	{
		for (auto iter = m_PossessPassiveSkillList.begin(); iter != m_PossessPassiveSkillList.end(); iter++)
		{
			if (iter->Get_SkillName() == _PassiveSkill.Get_SkillName())
				return true;
		}
		return false;
	}
	inline void PassiveSkill_Change(PassiveSkill _ChangePassiveSkill) { m_MountedPassiveSkill = _ChangePassiveSkill; }
	inline void ActiveSkill_Change(ActiveSkill _ChangeActiveSkill, ActiveSkill _CurUseActiveSkill)
	{
		for (int i = 0; i < static_cast<int>(SkillSlot::SLOT_END); i++)
		{
			if (m_MountedActiveSkillList[i].Get_SkillName() == _CurUseActiveSkill.Get_SkillName())
				m_MountedActiveSkillList[i] = _ChangeActiveSkill;
		}
	}
	inline void Cur_AppliedBuff_Reset() { m_CurAppliedBuffSkillList.clear(); }
	inline void Turn_Increse() { ++m_iTurn; }
	inline void Turn_Init() { m_iTurn = 1; }
	inline void TurnEnd_Status_Setting()
	{
		m_OriginStatus.m_iHP = m_CurStatus.m_iHP;
		m_OriginStatus.m_iMP = m_CurStatus.m_iMP;
		m_OriginStatus.m_iShieldGage = m_CurStatus.m_iShieldGage;
	}
	inline void Reward_HP_MP()
	{
		HP_Heal(HP_REWARD);
		MP_Heal(MP_REWARD);
		TurnEnd_Status_Setting();
	}
	inline void HP_Heal(int _Heal)
	{
		if (m_CurStatus.m_iHP + _Heal > m_CurStatus.m_iMaxHP)
			m_CurStatus.m_iHP = m_CurStatus.m_iMaxHP;
		else
			m_CurStatus.m_iHP += _Heal;
	}
	inline void MP_Heal(int _Heal)
	{
		if (m_CurStatus.m_iMP + _Heal > m_CurStatus.m_iMaxMP)
			m_CurStatus.m_iMP = m_CurStatus.m_iMaxMP;
		else
			m_CurStatus.m_iMP += _Heal;
	}
};
