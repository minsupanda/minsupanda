#include "ActiveSkill.h"
#include <fstream>

ActiveSkill::ActiveSkill()
{
}

void ActiveSkill::Skill_Setting(std::string _SkillName)
{
	std::ifstream SkillFileLoad;
	std::string LoadSkillName;
	std::string LoadDamage;
	std::string LoadAttackType;
	std::string LoadTarget;
	std::string LoadManaUsage;
	std::string LoadBuff;
	std::string LoadBuffType;
	std::string LoadBuffTurn;
	std::string LoadBuffValue;
	SkillFileLoad.open("ActiveSkill.txt");
	if (SkillFileLoad.is_open())
	{
		while (!SkillFileLoad.eof())
		{
			SkillFileLoad >> LoadSkillName;
			if (LoadSkillName == _SkillName)
			{
				SkillFileLoad >> LoadAttackType >> LoadDamage >> LoadManaUsage;
				SkillFileLoad >> LoadBuff;
				if (LoadBuff == "Buff")
				{
					std::string LoadBuffContinue;
					do
					{
						SkillFileLoad >> LoadBuffType >> LoadTarget >> LoadBuffTurn >> LoadBuffValue;
						Buff_Setting({ (BuffType)stoi(LoadBuffType), (ApplyTarget)stoi(LoadTarget), stoi(LoadBuffTurn), stof(LoadBuffValue) });
						SkillFileLoad >> LoadBuffContinue;
					} while (LoadBuffContinue == "and");
				}
				break;
			}
			else
				getline(SkillFileLoad, LoadSkillName);
		}
	}
	Skill_Init(_SkillName, SkillUseType::ACTIVE);
	m_AttackType = static_cast<AttackType>(stoi(LoadAttackType));
	m_fValue = static_cast<float>(stof(LoadDamage));
	m_iManaUsage = static_cast<int>(stoi(LoadManaUsage));
}

int ActiveSkill::UseSkill_Damage_Calculation(int& _AttackPoint)
{
	switch (m_AttackType)
	{
	case AttackType::NONE:
		return 0;
		
	case AttackType::ONCE_ATTACK:
		return _AttackPoint *= m_fValue;

	case AttackType::DOUBLE_ATTACK:
		_AttackPoint *= m_fValue;
		return _AttackPoint * 2;
	}
}

ActiveSkill::~ActiveSkill()
{

}

