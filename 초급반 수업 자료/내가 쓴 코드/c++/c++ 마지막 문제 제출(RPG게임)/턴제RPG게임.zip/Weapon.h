#pragma once
#include"Mecro.h"

enum class WeaponType
{
	SWORD,
	BOW,
	WAND,
	NONE
};

class Weapon
{
private:
	WeaponType m_WeaponType;
	std::string m_WeaponName;
	int m_iAttackPoint;
	int m_iBuyNeedGold;
public:
	Weapon();
	Weapon Init(WeaponType _SetWeaponType, std::string _SetWeaponName, int _SetWeaponAttackPoint, int _SetBuyNeedGold);
	inline WeaponType Get_WeaponType() { return m_WeaponType; }
	inline std::string Get_WeaponName() { return m_WeaponName; }
	inline int Get_WeaponAttackPoint() { return m_iAttackPoint; }
	inline int Get_BuyNeedGold() { return m_iBuyNeedGold; }
	~Weapon();
};

