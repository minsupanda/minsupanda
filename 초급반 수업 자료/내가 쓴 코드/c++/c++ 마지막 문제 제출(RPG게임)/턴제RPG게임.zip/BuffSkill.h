#pragma once
#include<iostream>

enum class BuffType
{
	NONE,
	SHIEID,
	EVATION, // ȸ��
	ATTACT_INCREASE,
	DEFENCE_INCREASE,
	ATTACT_DECREASE,
	DEFENCE_DECREASE,
	BURNS, // ȭ��
	FAINTING, // ����
	HP_CURE, // �ູ (HPȸ��)
	MANA_USAGE_INCREASE,
	ATTACK_DAMAGE_INCREASE
};

enum class ApplyTarget
{
	MY_TEAM,
	ENMEY_TEAM
};

class BuffSkill
{
private:
	BuffType m_BufffType;
	ApplyTarget m_Target;
	int m_iBuffTurn;
	int m_iBuffApplyTurn; // ������ ����� ��
	float m_fValue;
public:
	BuffSkill();
	BuffSkill(BuffType _SetBuffType, ApplyTarget _Target, int _SetTurn, float _SetValue);
	~BuffSkill();
	inline BuffType Get_BuffType() { return m_BufffType; }
	inline float Get_BuffValue() { return m_fValue; }
	inline int Get_BuffTurn() { return m_iBuffTurn; }
	inline int Get_BuffApplyTurn() { return m_iBuffApplyTurn; }
	inline ApplyTarget Get_SkillTarget() { return m_Target; }
	inline void BuffApply_Turn_Setting(int _Turn) { m_iBuffApplyTurn = _Turn; }
};