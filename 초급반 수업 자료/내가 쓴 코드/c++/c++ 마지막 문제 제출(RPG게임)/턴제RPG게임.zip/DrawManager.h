#pragma once
#include"Mecro.h"

class DrawManager
{
public:
	static void DrawMap()
	{
		for (int y = 0; y < HEIGHT; y++)
		{
			for (int x = 0; x < WIDTH; x++)
			{
				if (x == 0 && y == 0 )
					std::cout << "��";
				else if (y == 0 && x == WIDTH - 1)
					std::cout << "��";
				else if (x == 0 && y == HEIGHT - 1)
					std::cout << "��";
				else if (x == WIDTH - 1 && y == HEIGHT - 1)
					std::cout << "��";
				else if (y == 0 || y == HEIGHT - 1)
					std::cout << "��";
				else if ((y > 0 || y < HEIGHT - 1) && (x == 0 || x == WIDTH - 1))
					std::cout << "��";
				else
					std::cout << "  ";
			}
			std::cout << std::endl;
		}
	}

	static void DrawUiBox(int _Left, int _Top, int _Right, int _Bottom)
	{
		for (int y = _Top; y <= _Bottom; y++)
		{
			for (int x = _Left; x <= _Right; x++)
			{
				gotoxy(x * 2, y);
				if (x == _Left && y == _Top)
					std::cout << "��";
				else if (x == _Right && y == _Top)
					std::cout << "��";
				else if (x == _Left && y == _Bottom)
					std::cout << "��";
				else if (x == _Right && y == _Bottom)
					std::cout << "��";
				else if ((x > _Left && x < _Right) && (y == _Bottom || y == _Top ))
					std::cout << "��";
				else if ((x == _Left || x == _Right) && (y > _Top || y < _Bottom))
					std::cout << "��";
			}
		}
	}

	static void EraseUiBox(int _Left, int _Top, int _Right, int _Bottom)
	{
		for (int y = _Top + 1; y < _Bottom; y++)
		{
			for (int x = _Left + 1; x < _Right; x++)
				ErasePoint(x, y);
		}
	}

	static void EraseText(std::string str, int x, int y)
	{
		int EraseStartPoint = GetTextStartPoint(str, x);
		for (int x = EraseStartPoint; x < EraseStartPoint + str.size(); x++)
		{
			gotoxy(x, y);
			std::cout << "  ";
		}
	}

	static int GetTextStartPoint(std::string str, int x)
	{
		if (x > str.size() / 2)
			x -= str.size() / 2;
		return x;
	}

	static void gotoxy(int x, int y)
	{
		COORD Pos = { x, y };
		SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), Pos);
	}

	static void DrawPoint(std::string str, int x, int y)
	{
		gotoxy(x * 2, y);
		std::cout << str;
	}

	static void DrawMidText(std::string str, int x, int y)
	{
		if (x > str.size() / 2)
			x -= str.size() / 2;
		gotoxy(x, y);
		std::cout << str;
	}

	static void ErasePoint(int x, int y)
	{
		gotoxy(x * 2, y);
		std::cout << "  ";
	}
};
