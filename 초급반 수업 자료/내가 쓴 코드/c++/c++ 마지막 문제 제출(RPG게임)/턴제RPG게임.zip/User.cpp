#include "User.h"
#include "CharacterManager.h"
#include "SceneManager.h"

User* User::m_hThis = NULL;

User::User()
{
}

void User::Init()
{
	m_iCurStage = 1;
	m_iGold = 0;
	m_MyCharacter.PlayerCharacter_Init();
}

void User::JobSetting(JobClass _JobClass)
{
	m_MyCharacter = CharacterManager::Get_Instance()->Get_PlayableCharacter_Instance(_JobClass);
	m_MyCharacter.JobClass_Setting(_JobClass);
	m_MyCharacter.Skill_Init(_JobClass);
}

void User::WeaponBuy(Weapon _BuyWeapon)
{
	m_iGold -=_BuyWeapon.Get_BuyNeedGold();
	m_MyCharacter.Weapon_Setting(_BuyWeapon);
}

void User::Skill_Acquisition(Skill* _GetSkill)
{
	m_MyCharacter.AcquiredSkill_Save(_GetSkill);
}

bool User::GameEndCheck()
{
	if (m_MyCharacter.Get_HP() <= 0 || m_iCurStage >= static_cast<int>(MAX_STAGE))
		return true;
	else
		return false;
}

void User::StageClearCompensation(Skill* _GetSkill, int _iGold, bool SkillGet)
{
	if(SkillGet == true)
		m_MyCharacter.AcquiredSkill_Save(_GetSkill);
	m_MyCharacter.Reward_HP_MP();
	m_MyCharacter.Cur_AppliedBuff_Reset();
	m_MyCharacter.Turn_Init();
	m_iGold += _iGold;
	++m_iCurStage;
}

User::~User()
{
}
