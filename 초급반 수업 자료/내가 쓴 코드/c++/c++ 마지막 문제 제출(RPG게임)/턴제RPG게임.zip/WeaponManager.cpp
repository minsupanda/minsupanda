#include "WeaponManager.h"
#include <fstream>

WeaponManager* WeaponManager::m_hThis = NULL;

WeaponManager::WeaponManager()
{
}

void WeaponManager::Init()
{
	std::ifstream LoadWeaponListFile;
	std::string LoadWeaponType;
	std::string LoadWeaponName;
	std::string LoadWeaponAttackPoint;
	std::string LoadWeaopnBuyNeedGold;
	Weapon TmpWeapon;
	LoadWeaponListFile.open("WeaponList.txt");
	if (LoadWeaponListFile.is_open())
	{
		while (!LoadWeaponListFile.eof())
		{
			LoadWeaponListFile >> LoadWeaponName >> LoadWeaponType >> LoadWeaponAttackPoint >> LoadWeaopnBuyNeedGold;
			m_WeaponList.push_back(TmpWeapon.Init((WeaponType)stoi(LoadWeaponType), LoadWeaponName, (int)stoi(LoadWeaponAttackPoint), (int)stoi(LoadWeaopnBuyNeedGold)));
		}
	}
}

std::vector<Weapon> WeaponManager::Get_ClassWeapon(JobClass _PlayerClass)
{
	std::vector<Weapon> TmpWeaponList;
	for (std::vector<Weapon>::iterator iter = m_WeaponList.begin(); iter != m_WeaponList.end(); iter++)
	{
		switch (_PlayerClass)
		{
		case JobClass::KNIGHT:
			if (iter->Get_WeaponType() == WeaponType::SWORD)
				TmpWeaponList.push_back(*iter);
			break;

		case JobClass::ARCHER:
			if (iter->Get_WeaponType() == WeaponType::BOW)
				TmpWeaponList.push_back(*iter);
			break;

		case JobClass::WIZARD:
			if (iter->Get_WeaponType() == WeaponType::WAND)
				TmpWeaponList.push_back(*iter);
			break;
		}
	}
	return TmpWeaponList;
}
WeaponManager::~WeaponManager()
{
}
