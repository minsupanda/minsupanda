#include "PassiveSkill.h"
#include <fstream>

PassiveSkill::PassiveSkill()
{
}

void PassiveSkill::Skill_Setting(std::string _SkillName)
{
	std::ifstream SkillFileLoad;
	std::string LoadSkillName;
	std::string  LoadBuffType;
	std::string LoadTarget;
	std::string  LoadBuffTurn;
	std::string  LoadBuffValue;
	SkillFileLoad.open("PassiveSkill.txt");
	if (SkillFileLoad.is_open())
	{
		while (!SkillFileLoad.eof())
		{
			SkillFileLoad >> LoadSkillName;
			if (LoadSkillName == _SkillName)
			{
				std::string LoadBuffContinue;
				do
				{
					SkillFileLoad >> LoadBuffType >> LoadTarget >> LoadBuffTurn >> LoadBuffValue;
					Buff_Setting({ (BuffType)stoi(LoadBuffType), (ApplyTarget)stoi(LoadTarget), (int)stoi(LoadBuffTurn), (float)stoi(LoadBuffValue) });
					SkillFileLoad >> LoadBuffContinue;
				} while (LoadBuffContinue == "and");
				break;
			}
			else
				getline(SkillFileLoad, LoadSkillName);
		}
	}
	Skill_Init(_SkillName, SkillUseType::PASSIVE);
	SkillFileLoad.close();
}



PassiveSkill::~PassiveSkill()
{
}
