#include "CharacterManager.h"
#include "ConstValue.h"
#include <fstream>

CharacterManager* CharacterManager::m_hThis = NULL;

CharacterManager::CharacterManager()
{

}

void CharacterManager::Init()
{
	m_vecPlayableCharacterList.push_back(Chracter_Init<PlayableCharacter>(CharacterType::PLAYER, s_UI_JOB_CHOICE_FRIST));
	m_vecPlayableCharacterList.push_back(Chracter_Init<PlayableCharacter>(CharacterType::PLAYER, s_UI_JOB_CHOICE_SECOND));
	m_vecPlayableCharacterList.push_back(Chracter_Init<PlayableCharacter>(CharacterType::PLAYER, s_UI_JOB_CHOICE_THIRD));
	m_vecMonsterList.push_back(Chracter_Init<Monster>(CharacterType::MONSTER, s_MONSTER_FRIST));
	m_vecMonsterList.push_back(Chracter_Init<Monster>(CharacterType::MONSTER, s_MONSTER_SECOND));
	m_vecMonsterList.push_back(Chracter_Init<Monster>(CharacterType::MONSTER, s_MONSTER_THIRD));
	m_vecMonsterList.push_back(Chracter_Init<Monster>(CharacterType::MONSTER, s_MONSTER_FOURTH));
	m_vecMonsterList.push_back(Chracter_Init<Monster>(CharacterType::MONSTER, s_MONSTER_FIFTH));
}

template<typename CreateType>
CreateType CharacterManager::Chracter_Init(CharacterType _CreateType, std::string _CharacterName)
{
	switch (_CreateType)
	{
	case CharacterType::PLAYER:
		return CharacterStatus_Setting<CreateType>(_CreateType, _CharacterName, "PlayableCharacterStatus.txt");

	case CharacterType::MONSTER:
		return CharacterStatus_Setting<CreateType>(_CreateType, _CharacterName, "MonsterStatus.txt");
	}
}
template<typename CreateType>
CreateType CharacterManager::CharacterStatus_Setting(CharacterType _CreateType, std::string _CharacterName, std::string LoadFileName)
{
	CreateType TmpCharacter;
	std::ifstream CharacterStatusFileLoad;
	std::string CharacterClassName;
	std::string LoadHP;
	std::string LoadMP;
	std::string LoadAttackPoint;
	std::string LoadDefencePoint;
	CharacterStatusFileLoad.open(LoadFileName);
	if (CharacterStatusFileLoad.is_open())
	{
		while (!CharacterStatusFileLoad.eof())
		{
			CharacterStatusFileLoad >> CharacterClassName;
			if (CharacterClassName == _CharacterName)
			{
				CharacterStatusFileLoad >> LoadHP >> LoadMP >> LoadAttackPoint >> LoadDefencePoint;
				break;
			}
		}
	}
	CharacterStatusFileLoad.close();
	TmpCharacter.Init(_CreateType, _CharacterName, (int)stoi(LoadHP), (int)stoi(LoadMP), (int)stoi(LoadAttackPoint), (int)stoi(LoadDefencePoint));
	// ���⼭ ���ø� ������ ���°� Character�� ��Ŭ��� �ȵž������� �������� �ǰ�?
	return TmpCharacter;
}

PlayableCharacter CharacterManager::Get_PlayableCharacter_Instance(JobClass _JobClass)
{
	std::string TmpCharacterName = Get_PlayableCharacterName(_JobClass);
	for (std::vector<PlayableCharacter>::iterator iter = m_vecPlayableCharacterList.begin(); iter != m_vecPlayableCharacterList.end(); iter++)
	{
		if (iter->Get_CharacterName() == TmpCharacterName)
			return *iter;
	}
}

Monster CharacterManager::Get_Monster_Instance(MonsterClass _Monster)
{
	std::string TmpCharacterName = Get_MonsterName(_Monster);
	for (std::vector<Monster>::iterator iter = m_vecMonsterList.begin(); iter != m_vecMonsterList.end(); iter++)
	{
		if (iter->Get_CharacterName() == TmpCharacterName)
			return *iter;
	}
}

std::string CharacterManager::Get_PlayableCharacterName(JobClass _JobClass)
{
	switch (_JobClass)
	{
	case JobClass::KNIGHT:
		return s_UI_JOB_CHOICE_FRIST;

	case JobClass::ARCHER:
		return s_UI_JOB_CHOICE_SECOND;

	case JobClass::WIZARD:
		return s_UI_JOB_CHOICE_THIRD;
	}
}
std::string CharacterManager::Get_MonsterName(MonsterClass _Monster)
{
	switch (_Monster)
	{
	case MonsterClass::GOBLINE:
		return s_MONSTER_FRIST;

	case MonsterClass::ORC:
		return s_MONSTER_SECOND;

	case MonsterClass::ZOMBIE:
		return s_MONSTER_THIRD;

	case MonsterClass::WYVERN:
		return s_MONSTER_FOURTH;

	case MonsterClass::DRAGON:
		return s_MONSTER_FIFTH;
	}
}

CharacterManager::~CharacterManager()
{
}
