#pragma once
#include<map>
#include<vector>
#include"ActiveSkill.h"
#include"PassiveSkill.h"

class SkillManager
{
private:
	std::map<JobClass, std::vector<ActiveSkill>> m_PlayerActiveSkillList;
	std::map<JobClass, std::vector<PassiveSkill>> m_PlayerPassiveSkillList;
	std::map<MonsterClass, std::vector<ActiveSkill>> m_MonsterActiveSkillList;
	std::map<MonsterClass, std::vector<PassiveSkill>> m_MonsterPassiveSkillList;
	static SkillManager* m_hThis;
	SkillManager();
	~SkillManager();
public:
	static SkillManager* Get_Instance()
	{
		if (m_hThis == NULL)
			m_hThis = new SkillManager;
		return m_hThis;
	}
	void Init();
	std::vector<ActiveSkill> ActiveSkill_Init(std::string _LoadFileName);
	std::vector<PassiveSkill> PassiveSkill_Init(std::string _LoadFileName);
	std::vector<ActiveSkill> KnightActiveSkill_Setting();
	std::vector<ActiveSkill> ArcherActiveSkill_Setting();
	std::vector<ActiveSkill> WizardActiveSkill_Setting();
	std::vector<ActiveSkill> MonsterActiveSkill_Setting();
	std::vector<PassiveSkill> KnightPassiveSkill_Setting();
	std::vector<PassiveSkill> ArcherPassiveSkill_Setting();
	std::vector<PassiveSkill> WizardPassiveSkill_Setting();
	std::vector<PassiveSkill> MonsterPassiveSkill_Setting();
	inline ActiveSkill Get_RandomPlayerActiveSkill(JobClass _JobClass)
	{
		int iSkillIndex = rand() % m_PlayerActiveSkillList[_JobClass].size();
		return  m_PlayerActiveSkillList[_JobClass][iSkillIndex];
	}
	inline PassiveSkill Get_RandomPlayerPassiveSkill(JobClass _JobClass)
	{
		int iSkillIndex = rand() % m_PlayerPassiveSkillList[_JobClass].size();
		return  m_PlayerPassiveSkillList[_JobClass][iSkillIndex];
	}
	inline std::vector<ActiveSkill> Get_PlayerActiveSkill(JobClass _JobClass) { return m_PlayerActiveSkillList.find(_JobClass)->second; }
	inline std::vector<PassiveSkill> Get_PlayerPassiveSkill(JobClass _JobClass) { return m_PlayerPassiveSkillList.find(_JobClass)->second; }
	inline std::vector<ActiveSkill> Get_MonsterActiveSkill(MonsterClass _MonsterClass) { return m_MonsterActiveSkillList.find(_MonsterClass)->second; }
	inline std::vector<PassiveSkill> Get_MonsterPassiveSkill(MonsterClass _MonsterClass) { return m_MonsterPassiveSkillList.find(_MonsterClass)->second; }
};
