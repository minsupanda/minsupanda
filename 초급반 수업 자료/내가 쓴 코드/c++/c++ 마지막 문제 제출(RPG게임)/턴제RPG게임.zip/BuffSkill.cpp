#include "BuffSkill.h"

BuffSkill::BuffSkill()
{
}

BuffSkill::BuffSkill(BuffType _SetBuffType, ApplyTarget _Target, int _SetTurn, float _SetValue)
{
	m_BufffType = _SetBuffType;
	m_Target = _Target;
	m_iBuffTurn = _SetTurn;
	m_fValue = _SetValue;
}

BuffSkill::~BuffSkill()
{
}

