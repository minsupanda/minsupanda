#include "AddBuffStatus.h"

AddBuffStatus::AddBuffStatus()
{
}

void AddBuffStatus::Reset()
{
	m_iAvoidRate = 0;
	m_iAttackPoint = 0;
	m_iDefencePoint = 0;
	m_iHP = 0;
	m_iHeal = 0;
	m_fUseMPScale = 1.0f;
	m_fDamageRate = 1.0f;
	m_bStern = false;
}

void AddBuffStatus::AddBuff(BuffSkill _buff)
{
	switch (_buff.Get_BuffType())
	{
	case BuffType::ATTACK_DAMAGE_INCREASE:
		m_fDamageRate = _buff.Get_BuffValue();
		break;
	case BuffType::ATTACT_INCREASE:
		m_iAttackPoint += static_cast<int>(_buff.Get_BuffValue());
		break;
	case BuffType::ATTACT_DECREASE:
		m_iAttackPoint -= static_cast<int>(_buff.Get_BuffValue());
		break;
	case BuffType::DEFENCE_INCREASE:
		m_iDefencePoint += static_cast<int>(_buff.Get_BuffValue());
		break;
	case BuffType::DEFENCE_DECREASE:
		m_iDefencePoint -= static_cast<int>(_buff.Get_BuffValue());
		break;
	case BuffType::EVATION:
		m_iAvoidRate = static_cast<int>(_buff.Get_BuffValue());
		break;
	case BuffType::BURNS:
		m_iHP -= _buff.Get_BuffValue();
		break;
	case BuffType::FAINTING:
		m_bStern = true;
		break;
	case BuffType::HP_CURE:
		m_iHeal = _buff.Get_BuffValue();
		m_iHP += _buff.Get_BuffValue();
		break;
	case BuffType::MANA_USAGE_INCREASE:
		m_fUseMPScale = _buff.Get_BuffValue();
		break;
	}
}


AddBuffStatus::~AddBuffStatus()
{
}