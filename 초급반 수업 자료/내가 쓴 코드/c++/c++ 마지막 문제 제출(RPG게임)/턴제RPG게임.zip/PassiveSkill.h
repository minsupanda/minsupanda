#pragma once
#include"Skill.h"

class PassiveSkill : public Skill
{
private:
public:
	PassiveSkill();
	~PassiveSkill();
	virtual void Skill_Setting(std::string _SkillName) override;
};
