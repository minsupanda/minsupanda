#include "GameManager.h"
#include"CharacterManager.h"
#include"SkillManager.h"
#include"WeaponManager.h"
#include"SceneManager.h"
#include"User.h"

GameManager::GameManager()
{
	srand(time(NULL));
	m_MapSize.m_iWidth = WIDTH;
	m_MapSize.m_iHeight = HEIGHT;
	char buf[256];
	sprintf(buf, "mode con: cols=%d lines=%d", m_MapSize.m_iWidth * 2 + 1, m_MapSize.m_iHeight + 3);
	system(buf);
	Init();
}

void GameManager::Init()
{
	m_MonsterList.resize(MAX_STAGE);
	WeaponManager::Get_Instance()->Init();
	SkillManager::Get_Instance()->Init();
	CharacterManager::Get_Instance()->Init();
	m_MonsterList[0] = CharacterManager::Get_Instance()->Get_Monster_Instance(GOBLINE);
	m_MonsterList[0].Gold_Setting(5); // ��差�� enum����?
	m_MonsterList[1] = CharacterManager::Get_Instance()->Get_Monster_Instance(ORC);
	m_MonsterList[1].Gold_Setting(7);
	m_MonsterList[2] = CharacterManager::Get_Instance()->Get_Monster_Instance(ZOMBIE);
	m_MonsterList[2].Gold_Setting(9);
	m_MonsterList[3] = CharacterManager::Get_Instance()->Get_Monster_Instance(WYVERN);
	m_MonsterList[3].Gold_Setting(10);
	m_MonsterList[4] = CharacterManager::Get_Instance()->Get_Monster_Instance(DRAGON);
	m_MonsterList[4].Gold_Setting(11);
}

void GameManager::MainLoop()
{
	while (1)
	{	
		system("cls");
		int iSelect;
		DrawManager::DrawMidText("�ؽ�Ʈ RPG", WIDTH, HEIGHT * 0.4f);
		DrawManager::DrawMidText("1. ���� ����", WIDTH, HEIGHT * 0.5f);
		DrawManager::DrawMidText("2. ���� ����", WIDTH, HEIGHT * 0.6f);
		DrawManager::DrawMidText("Select : ", WIDTH, HEIGHT * 0.7f);
		std::cin >> iSelect;
		switch (iSelect)
		{
		case 1:
			JobChoice();
			GameStart();
			break;

		case 2:
			return;

		default: break;
		}
	}
}

void GameManager::GameStart()
{
	system("cls");
	DrawManager::DrawMap();
	DrawManager::DrawUiBox(s_LEFT_BOX.m_iLeft, s_LEFT_BOX.m_iTop, s_LEFT_BOX.m_iRight, s_LEFT_BOX.m_iBottom);
	DrawManager::DrawUiBox(s_RIGHT_BOX.m_iLeft, s_RIGHT_BOX.m_iTop, s_RIGHT_BOX.m_iRight, s_RIGHT_BOX.m_iBottom);
	StageProgressChoice();
	system("cls");
	DrawManager::DrawMidText("Game End!!", WIDTH, HEIGHT / 2);
	getch();
}

void GameManager::JobChoice()
{
	system("cls");
	User::Get_Instance()->JobSetting(static_cast<JobClass>(SceneManager::CurScene_Confirm(SceneType::JOB_CHOICE_SCENE)));
	User::Get_Instance()->Init();
	CurShopWeaponList = WeaponManager::Get_Instance()->Get_ClassWeapon(User::Get_Instance()->Get_MyCharacter()->Get_JobClass());
}

void GameManager::StageProgressChoice()
{
	while (1)
	{
		DrawManager::EraseUiBox(s_RIGHT_BOX.m_iLeft, s_RIGHT_BOX.m_iTop, s_RIGHT_BOX.m_iRight, s_RIGHT_BOX.m_iBottom);
		DrawManager::EraseUiBox(s_LEFT_BOX.m_iLeft, s_LEFT_BOX.m_iTop, s_LEFT_BOX.m_iRight, s_LEFT_BOX.m_iBottom);
		DrawManager::EraseUiBox(s_LOG_BOX.m_iLeft, s_LOG_BOX.m_iTop, s_LOG_BOX.m_iRight, s_LOG_BOX.m_iBottom);
		SceneManager::PlayerStatus_Print(s_LEFT_BOX);
		switch (static_cast<GameProgressChoiceMenu>(SceneManager::CurScene_Confirm(SceneType::GAME_PROGRESS_CHOICE_SCENE)))
		{
		case GameProgressChoiceMenu::STAGE_PROGRESS:
		{
			Monster CurStageMonster = m_MonsterList[User::Get_Instance()->Get_CurStage() - 1];
			CurStageMonster.Skill_Init(static_cast<MonsterClass>(User::Get_Instance()->Get_CurStage() - 1));
			Battle(CurStageMonster);
			DrawManager::EraseUiBox(s_LOG_BOX.m_iLeft, s_LOG_BOX.m_iTop, s_LOG_BOX.m_iRight, s_LOG_BOX.m_iBottom);
			if (User::Get_Instance()->GameEndCheck() == true)
				return;
			else
				StageClear(CurStageMonster);
			break;
		}
		case GameProgressChoiceMenu::CHARACTER_MANAGEMENT:
			DrawManager::EraseUiBox(s_RIGHT_BOX.m_iLeft, s_RIGHT_BOX.m_iTop, s_RIGHT_BOX.m_iRight, s_RIGHT_BOX.m_iBottom);
			Character_Management(static_cast<CharacterManageMentMenu>(SceneManager::CurScene_Confirm(SceneType::CHARACTER_MANAGEMENT_SCENE)));
			break;
		}
	}
}

void GameManager::Character_Management(CharacterManageMentMenu _ChoiceMenu)
{
	DrawManager::EraseUiBox(s_RIGHT_BOX.m_iLeft, s_RIGHT_BOX.m_iTop, s_RIGHT_BOX.m_iRight, s_RIGHT_BOX.m_iBottom);
	switch (_ChoiceMenu)
	{
	case CharacterManageMentMenu::SHOP:
	{
		int iChoiceMenu = SceneManager::CurScene_Confirm(SceneType::SHOP_SCENE);
		if (iChoiceMenu == ESC)
			break;
		else
			ShopWeaponBuy(iChoiceMenu);
		break;
	}
	case CharacterManageMentMenu::SKILL_CHANGE:
		Skill_ManageMent();
		break;
	}
}

void GameManager::ShopWeaponBuy(int _iChoiceMenu)
{
	User::Get_Instance()->WeaponBuy(CurShopWeaponList[_iChoiceMenu]);
}

void GameManager::Skill_ManageMent()
{
	SceneManager::CurScene_Confirm(SceneType::SKILL_CHANGE_SCENE);
}

void GameManager::Battle(Monster _CurMonster)
{
	std::list<std::string> LogList;
	Character* CurActor = User::Get_Instance()->Get_MyCharacter();
	Character* Target = &_CurMonster;

	while (User::Get_Instance()->Get_MyCharacter()->Get_HP() > 0 && _CurMonster.Get_HP() > 0)
	{
		ActionLog ActionLogRecord; // �̰� ��������, �׳� ��� ������� ȣ���ؼ� �ٽ� �����ϴ°� ������
		DrawManager::EraseUiBox(s_RIGHT_BOX.m_iLeft, s_RIGHT_BOX.m_iTop, s_RIGHT_BOX.m_iRight, s_RIGHT_BOX.m_iBottom);
		DrawManager::EraseUiBox(s_LEFT_BOX.m_iLeft, s_LEFT_BOX.m_iTop, s_LEFT_BOX.m_iRight, s_LEFT_BOX.m_iBottom);
		SceneManager::MonsterStatus_Print(s_RIGHT_BOX, _CurMonster);
		SceneManager::PlayerStatus_Print(s_LEFT_BOX);
		DrawManager::DrawUiBox(s_LOG_BOX.m_iLeft, s_LOG_BOX.m_iTop, s_LOG_BOX.m_iRight, s_LOG_BOX.m_iBottom);
		TurnResult CurTurnResult = CurActor->Action_Choice(Target, ActionLogRecord);
		switch (CurTurnResult)
		{
		case TurnResult::PROGRESS:
		case TurnResult::SKIP:
			Battle_Log(CurActor, Target, CurTurnResult, ActionLogRecord, &LogList);
			TurnChange(&CurActor, &Target);
			break;
		case TurnResult::END:
			return;
		}
	}
}

void GameManager::Battle_Log(Character* _CurActor, Character* _Target, TurnResult _TurnResult, ActionLog _ActionLogRecord, std::list<std::string>* _LogList)
{
	DrawManager::EraseUiBox(s_LOG_BOX.m_iLeft, s_LOG_BOX.m_iTop, s_LOG_BOX.m_iRight, s_LOG_BOX.m_iBottom);

	if (_TurnResult == TurnResult::SKIP)
		_LogList->push_front(_CurActor->Get_CharacterName() + "��(��) �ൿ�Ҵɿ� �������ϴ�!!");
	else
	{
		switch (_ActionLogRecord.m_CurAction)
		{
		case ActionTypeMenu::DEFAULT_ATTACK:
			_LogList->push_front(_CurActor->Get_CharacterName() + "��(��) " + " �⺻ ������ ����߽��ϴ�.");
			if (_ActionLogRecord.bAttackResult == false)
			{
				if (_ActionLogRecord.bEvationResult == true)
					_LogList->push_front(_Target->Get_CharacterName() + "��(��) " + _CurActor->Get_CharacterName() + "�� ������ ȸ���Ͽ����ϴ�!");
				else if (_ActionLogRecord.bDefenceResult == true)
					_LogList->push_front(_Target->Get_CharacterName() + "��(��) " + _CurActor->Get_CharacterName() + "�� ������ ����߽��ϴ�!");
			}
			else
				_LogList->push_front(_Target->Get_CharacterName() + "��(��) " + _CurActor->Get_CharacterName() + "�� ���� " + std::to_string(_ActionLogRecord.m_iTotalDamage) + "�������� �޾ҽ��ϴ�!");
			break;

		case ActionTypeMenu::DEFENSE:
			_LogList->push_front(_CurActor->Get_CharacterName() + "��(��) �� ����߽��ϴ�. (1ȸ �ǰ� �鿪)");
			break;

		case ActionTypeMenu::USE_SKILL:
			_LogList->push_front(_CurActor->Get_CharacterName() + "��(��) " + "'" + _ActionLogRecord.SkillName + "'" + " ��ų��(��) ����߽��ϴ�.");
			if (_ActionLogRecord.m_SkillAttack == true)
			{
				if (_ActionLogRecord.bDefenceResult == true && _ActionLogRecord.bAttackResult == false)
					_LogList->push_front(_Target->Get_CharacterName() + "��(��) " + _CurActor->Get_CharacterName() + "�� ������ ����߽��ϴ�!");
				else if (_ActionLogRecord.bEvationResult == true && _ActionLogRecord.bAttackResult == false)
					_LogList->push_front(_Target->Get_CharacterName() + "��(��) " + _CurActor->Get_CharacterName() + "�� ������ ȸ���Ͽ����ϴ�!");
				else
					_LogList->push_front(_Target->Get_CharacterName() + "��(��) " + _CurActor->Get_CharacterName() + "�� " + _ActionLogRecord.SkillName + "�� ���� " + std::to_string(_ActionLogRecord.m_iTotalDamage) + "�������� �޾ҽ��ϴ�!");

			}
			break;
		}
	}
	while (_LogList->size() >= LOG_TEXT_MAX_SIZE)
	{
		_LogList->pop_back();
	}
	Battle_Log_Print(*_LogList);

}

void GameManager::Battle_Log_Print(std::list<std::string> _LogList)
{
	int i = 1;
	for (auto iter = _LogList.begin(); iter != _LogList.end(); iter++)
	{
		DrawManager::DrawPoint(*iter, s_LOG_BOX.m_iLeft + 1, s_LOG_BOX.m_iTop + i);
		++i;
	}
}

void GameManager::TurnChange(Character** CurActor, Character** Target)
{
	Character* TmpCharacter = *CurActor;
	*CurActor = *Target;
	*Target = TmpCharacter;
}

void GameManager::StageClear(Monster _CurMonster)
{
	SceneManager::CurScene_Confirm(SceneType::STAGE_CLEAR_SCENE, _CurMonster);
}

GameManager::~GameManager()
{
}
