#include "Monster.h"
#include "SkillManager.h"
#include "SceneManager.h"

Monster::Monster()
{
	
}

TurnResult Monster::Action_Choice(Character* _Target, ActionLog& _ActionLogRecord)
{
	TurnResult TurnProgressCheck = Check_Before_Proceeding();
	if (TurnProgressCheck != TurnResult::PROGRESS)
	{
		Turn_Increse();
		TurnEnd_Status_Setting();
		return TurnProgressCheck;
	}
	int iSelect = (rand() % static_cast<int>(ActionTypeMenu::MENU_END));
	DrawManager::EraseUiBox(s_LEFT_BOX.m_iLeft, s_LEFT_BOX.m_iTop, s_LEFT_BOX.m_iRight, s_LEFT_BOX.m_iBottom);
	SceneManager::MonsterStatus_Print(s_RIGHT_BOX, *this);
	switch (static_cast<ActionTypeMenu>/*(iSelect)*/(0))
	{
	case ActionTypeMenu::DEFAULT_ATTACK:
		_ActionLogRecord.m_CurAction = ActionTypeMenu::DEFAULT_ATTACK;
		DefaultAttack_Action(_Target, 0, _ActionLogRecord);
		break;

	case ActionTypeMenu::DEFENSE:
		_ActionLogRecord.m_CurAction = ActionTypeMenu::DEFENSE;
		Defence_On_Off(true);
		break;

	case ActionTypeMenu::USE_SKILL:
	{
		int iChoice = rand() % static_cast<int>(SkillSlot::SLOT_END);
		if (SkillMana_Confirm(iChoice) == true)
		{
			_ActionLogRecord.m_CurAction = ActionTypeMenu::USE_SKILL;
			UsedSkill_Action(_Target, 0, iChoice, _ActionLogRecord);
		}
		break;
	}
	}
	Turn_Increse();
	TurnEnd_Status_Setting();
	return TurnProgressCheck;
}

void Monster::Skill_Init(MonsterClass _MonsterClass)
{
	std::vector<ActiveSkill> TmpActiveSkillList = SkillManager::Get_Instance()->Get_MonsterActiveSkill(_MonsterClass);
	std::vector<PassiveSkill> TmpPassiveSkillList = SkillManager::Get_Instance()->Get_MonsterPassiveSkill(_MonsterClass);

	int i = 0;
	for (std::vector<ActiveSkill>::iterator iter = TmpActiveSkillList.begin(); iter != TmpActiveSkillList.end(); iter++)
	{
		if (i <= 2)
		{
			ActiveSkill_Setting(i, *iter);
			++i;
		}
		else break;
	}
	PassiveSkill_Setting(*TmpPassiveSkillList.begin());
}

Monster::~Monster()
{
}
