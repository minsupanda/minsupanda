#include "SkillManager.h"
#include <fstream>

SkillManager* SkillManager::m_hThis = NULL;

SkillManager::SkillManager()
{
}

void SkillManager::Init()
{
	m_PlayerActiveSkillList.insert(std::make_pair(JobClass::KNIGHT, KnightActiveSkill_Setting()));
	m_PlayerPassiveSkillList.insert(std::make_pair(JobClass::KNIGHT, KnightPassiveSkill_Setting()));

	m_PlayerActiveSkillList.insert(std::make_pair(JobClass::ARCHER, ArcherActiveSkill_Setting()));
	m_PlayerPassiveSkillList.insert(std::make_pair(JobClass::ARCHER, ArcherPassiveSkill_Setting()));

	m_PlayerActiveSkillList.insert(std::make_pair(JobClass::WIZARD, WizardActiveSkill_Setting()));
	m_PlayerPassiveSkillList.insert(std::make_pair(JobClass::WIZARD, WizardPassiveSkill_Setting()));

	m_MonsterActiveSkillList.insert(std::make_pair(MonsterClass::GOBLINE, MonsterActiveSkill_Setting()));
	m_MonsterPassiveSkillList.insert(std::make_pair(MonsterClass::GOBLINE, MonsterPassiveSkill_Setting()));

	m_MonsterActiveSkillList.insert(std::make_pair(MonsterClass::ORC, MonsterActiveSkill_Setting()));
	m_MonsterPassiveSkillList.insert(std::make_pair(MonsterClass::ORC, MonsterPassiveSkill_Setting()));

	m_MonsterActiveSkillList.insert(std::make_pair(MonsterClass::ZOMBIE, MonsterActiveSkill_Setting()));
	m_MonsterPassiveSkillList.insert(std::make_pair(MonsterClass::ZOMBIE, MonsterPassiveSkill_Setting()));

	m_MonsterActiveSkillList.insert(std::make_pair(MonsterClass::WYVERN, MonsterActiveSkill_Setting()));
	m_MonsterPassiveSkillList.insert(std::make_pair(MonsterClass::WYVERN, MonsterPassiveSkill_Setting()));

	m_MonsterActiveSkillList.insert(std::make_pair(MonsterClass::DRAGON, MonsterActiveSkill_Setting()));
	m_MonsterPassiveSkillList.insert(std::make_pair(MonsterClass::DRAGON, MonsterPassiveSkill_Setting()));
}

std::vector<ActiveSkill> SkillManager::ActiveSkill_Init(std::string _LoadFileName)
{
	std::ifstream ClassSkillListFileLoad;
	std::vector<ActiveSkill> vecTmpActiveSkill;
	std::string LoadSkillName;
	ClassSkillListFileLoad.open(_LoadFileName);
	if (ClassSkillListFileLoad.is_open())
	{
		while (!ClassSkillListFileLoad.eof())
		{
			ActiveSkill CreateActiveSkill;
			ClassSkillListFileLoad >> LoadSkillName;
			CreateActiveSkill.Skill_Setting(LoadSkillName);
			vecTmpActiveSkill.push_back(CreateActiveSkill);
		}
		ClassSkillListFileLoad.close();
		return vecTmpActiveSkill;
	}
}

std::vector<PassiveSkill> SkillManager::PassiveSkill_Init(std::string _LoadFileName)
{
	std::ifstream ClassSkillListFileLoad;
	std::vector<PassiveSkill> vecTmpPassiveSkill;
	std::string LoadSkillName;
	ClassSkillListFileLoad.open(_LoadFileName);
	if (ClassSkillListFileLoad.is_open())
	{
		while (!ClassSkillListFileLoad.eof())
		{
			PassiveSkill CreatePassiveSkill;
			ClassSkillListFileLoad >> LoadSkillName;
			CreatePassiveSkill.Skill_Setting(LoadSkillName);
			vecTmpPassiveSkill.push_back(CreatePassiveSkill);
		}
		ClassSkillListFileLoad.close();
		return vecTmpPassiveSkill;
	}
}

std::vector<ActiveSkill> SkillManager::KnightActiveSkill_Setting()
{
	return ActiveSkill_Init("KnightActiveSkillList.txt");
}

std::vector<ActiveSkill> SkillManager::ArcherActiveSkill_Setting()
{
	return ActiveSkill_Init("ArcherActiveSkillList.txt");
}

std::vector<ActiveSkill> SkillManager::WizardActiveSkill_Setting()
{
	return ActiveSkill_Init("WizardActiveSkillList.txt");;
}

std::vector<ActiveSkill> SkillManager::MonsterActiveSkill_Setting()
{
	return ActiveSkill_Init("MonsterActiveSkillList.txt");;
}

std::vector<PassiveSkill> SkillManager::KnightPassiveSkill_Setting()
{
	return PassiveSkill_Init("KnightPassiveSkillList.txt");
}

std::vector<PassiveSkill> SkillManager::ArcherPassiveSkill_Setting()
{
	return PassiveSkill_Init("ArcherPassiveSkillList.txt");
}

std::vector<PassiveSkill> SkillManager::WizardPassiveSkill_Setting()
{
	return PassiveSkill_Init("WizardPassiveSkillList.txt");
}

std::vector<PassiveSkill> SkillManager::MonsterPassiveSkill_Setting()
{
	return PassiveSkill_Init("MonsterPassiveSkillList.txt");
}

SkillManager::~SkillManager()
{
}
