#pragma once
#include "PlayableCharacter.h"

class User
{
private:
	PlayableCharacter m_MyCharacter;
	int m_iGold;
	int m_iCurStage;
	static User* m_hThis;
	User();
	~User();
public:
	static User* Get_Instance()
	{
		if (m_hThis == NULL)
			m_hThis = new User;
		return m_hThis;
	}
	inline PlayableCharacter* Get_MyCharacter() { return &m_MyCharacter; }
	inline int Get_CurStage() { return m_iCurStage; }
	inline int Get_Gold() { return m_iGold; }
	inline void Gold_Increase(int _IncreaseGold) { m_iGold += _IncreaseGold; }
	inline void Gold_Decrease(int _DecreaseGold) { m_iGold -= _DecreaseGold; }
	inline void Stage_Increase() { ++m_iCurStage; }
	void Init();
	void JobSetting(JobClass _JobClass);
	void WeaponBuy(Weapon _BuyWeapon);
	bool GameEndCheck();
	void Skill_Acquisition(Skill* _GetSkill);
	void StageClearCompensation(Skill* _GetSkill, int _iGold, bool SkillGet);
};
