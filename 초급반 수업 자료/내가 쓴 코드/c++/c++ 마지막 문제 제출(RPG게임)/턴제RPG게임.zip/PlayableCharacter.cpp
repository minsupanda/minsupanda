#include "PlayableCharacter.h"
#include "WeaponManager.h"
#include "SceneManager.h"
#include "SkillManager.h"

PlayableCharacter::PlayableCharacter()
{
}

void PlayableCharacter::PlayerCharacter_Init()
{;
	CharacterType CurCharacterType = Get_CharacterType();
	std::string CurCharacterName = Get_CharacterName();
	std::vector<Weapon> WeaponList = WeaponManager::Get_Instance()->Get_WeaponList();
	for (std::vector<Weapon>::iterator iter = WeaponList.begin(); iter != WeaponList.end(); iter++)
	{
		if (CurCharacterType == CharacterType::PLAYER)
		{
			if (CurCharacterName == s_UI_JOB_CHOICE_FRIST && iter->Get_WeaponName() == s_KINGHT_INIT_WEAPON ||
				CurCharacterName == s_UI_JOB_CHOICE_SECOND && iter->Get_WeaponName() == s_ARCHER_INIT_WEAPON||
				CurCharacterName == s_UI_JOB_CHOICE_THIRD && iter->Get_WeaponName() == s_WIZARD_INIT_WEAPON)
			{
				m_CurWeapon = *iter;
				break;
			}
		}
	}
}

TurnResult PlayableCharacter::Action_Choice(Character* _Target, ActionLog& _ActionLogRecord)
{	
	TurnResult TurnProgressCheck = Check_Before_Proceeding();
	if (TurnProgressCheck != TurnResult::PROGRESS)
	{
		Turn_Increse();
		return TurnProgressCheck;
	}
	while (1)
	{
		DrawManager::EraseUiBox(s_LEFT_BOX.m_iLeft, s_LEFT_BOX.m_iTop, s_LEFT_BOX.m_iRight, s_LEFT_BOX.m_iBottom);
		SceneManager::PlayerStatus_Print(s_LEFT_BOX);
		switch (static_cast<ActionTypeMenu>(SceneManager::CurScene_Confirm(SceneType::FIGHT_SCENE)))
		{
		case ActionTypeMenu::DEFAULT_ATTACK:
			_ActionLogRecord.m_CurAction = ActionTypeMenu::DEFAULT_ATTACK;
			DefaultAttack_Action(_Target, m_CurWeapon.Get_WeaponAttackPoint(), _ActionLogRecord);
			TurnEnd_Status_Setting();
			Turn_Increse();
			return TurnProgressCheck;

		case ActionTypeMenu::DEFENSE:
			_ActionLogRecord.m_CurAction = ActionTypeMenu::DEFENSE;
			Defence_On_Off(true);
			TurnEnd_Status_Setting();
			Turn_Increse();
			return TurnProgressCheck;;

		case ActionTypeMenu::USE_SKILL:
		{
			_ActionLogRecord.m_CurAction = ActionTypeMenu::USE_SKILL;
			int iChoice = SceneManager::CurScene_Confirm(SceneType::USE_SKILL_SCENE);
			if (iChoice == ESC)
				break;
			else
			{
				UsedSkill_Action(_Target, m_CurWeapon.Get_WeaponAttackPoint(), iChoice, _ActionLogRecord);
				TurnEnd_Status_Setting();
				Turn_Increse();
				return TurnProgressCheck;
			}
		}
		}
	}
}

void PlayableCharacter::Skill_Init(JobClass _JobClass)
{
	std::vector<ActiveSkill> TmpActiveSkillList = SkillManager::Get_Instance()->Get_PlayerActiveSkill(_JobClass);
	std::vector<PassiveSkill> TmpPassiveSkillList = SkillManager::Get_Instance()->Get_PlayerPassiveSkill(_JobClass);

	int i = 0;
	for (std::vector<ActiveSkill>::iterator iter = TmpActiveSkillList.begin(); iter != TmpActiveSkillList.end(); iter++)
	{
		if (i <= 2)
		{
			ActiveSkill_Setting(i, *iter);
			++i;
		}
		else
			break;
	}
	PassiveSkill_Setting(*TmpPassiveSkillList.begin());
}

void PlayableCharacter::Skill_Change(Skill* _CurUseSkill, Skill* ChangeSkill)
{
	switch(ChangeSkill->Get_SkillUseType())
	{
	case SkillUseType::ACTIVE:
	{
		ActiveSkill_Change(*dynamic_cast<ActiveSkill*>(ChangeSkill), *dynamic_cast<ActiveSkill*>(_CurUseSkill));
		break;
	}
		
	case SkillUseType::PASSIVE:
		PassiveSkill_Change(*dynamic_cast<PassiveSkill*>(ChangeSkill));
		break;
	}
}

PlayableCharacter::~PlayableCharacter()
{
}
