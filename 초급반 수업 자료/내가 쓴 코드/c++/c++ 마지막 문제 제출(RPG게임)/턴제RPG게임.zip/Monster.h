#pragma once
#include"Character.h"

class Monster : public Character
{
private:
	int m_iGold;
public:
	Monster();
	~Monster();
	void Gold_Setting(int _SetGold) { m_iGold = _SetGold; }
	inline int Get_Gold() { return m_iGold; }
	virtual TurnResult Action_Choice(Character* _Target, ActionLog& _ActionLogRecord);
	void Skill_Init(MonsterClass _MonsterClass);
};

