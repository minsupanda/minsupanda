#pragma once
#include"BitMap.h"
#include"BitMapManager.h"

enum CARD
{
	CARD_FRONT,
	CARD_REAR,
	CARD_END
};

class Card
{
private:
	CARD m_eCardState;
	BitMap* m_pBitMap[CARD_END];
	int m_ix;
	int m_iy;
	int m_iWidth;
	int m_iHeight;
	RECT m_BitMapRect;
public:
	Card();
	~Card();
	
	int Get_Card_Width() { return m_pBitMap[0]->GetSize().cx; }
	int Get_Card_Height() { return m_pBitMap[0]->GetSize().cy; }

	void Init(IMAGE Index, int x, int y, int w, int h);
	void Draw(HDC hdc);
	bool ColliderCheck(POINT point);
	bool CardOpenCheck(POINT point);
	inline void CardOpen()
	{
		m_eCardState = CARD_FRONT;
	}
	inline void CardClose()
	{
		m_eCardState = CARD_REAR;
	}
};

