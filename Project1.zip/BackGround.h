#pragma once
#include"Mecro.h"
#include"BitmapManager.h"

enum BackGroundImage
{
	Ground,
	Elephant,
	Dark_Audience,
	light_Audience,

	ImageEnd,

	BackGround_Image_Number = 15
};

class BackGround
{
private:
	Bitmap* m_BackGorundImage[BackGroundImage::ImageEnd];
	Bitmap* m_CurAudiecneImage;

	const SIZE* m_GroundSize;
	const SIZE* m_AudienceSize;

	float m_BackGroundWidth;
	float m_DrawBaseX;

	float m_ImageChangeTime = 0.0f;

	void Animation(const float& deltaTime);
	void PrintImage(HDC& m__backDC, Bitmap* PrintImage, int& i, int& j, float& DrawBaseY);

public:
	BackGround();
	~BackGround();

	void Init();
	void Update(float ToalDistance, const bool& Goal, const float& deltaTime);
	void Draw(HDC& m_backDC, float& DrawBaseY);

};

