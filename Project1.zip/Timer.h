#pragma once
#include"Mecro.h"

#define DEFAULT_TIME 5


