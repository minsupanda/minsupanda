#pragma once
#include "Figure.h"

class Circle : public Figure
{
public:
	Circle();
	~Circle();

	virtual void Init(Vector2 v) override;
	virtual void Draw() override;
};

