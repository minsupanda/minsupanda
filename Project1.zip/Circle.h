#pragma once
#include "Figure.h"

class Circle : public Figure
{
public:
	Circle();
	~Circle();

	virtual void Init(Vector2 v, Vector2 p, Vector2 f) override;
	virtual void Draw(HDC backDC) override;

	float Get_radius() { return m_HalfSize.x; }
};

