#pragma once
#include "Figure.h"

class Square : public Figure
{
public:
	Square();
	~Square();

	virtual void Init(Vector2 v) override;
	virtual void Draw() override;
};

