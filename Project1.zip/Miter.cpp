#include "Miter.h"

Miter::Miter() {}
Miter::~Miter() {}

void Miter::Init(int width)
{
	m_MiterImage = BitmapMgr->Get_Image(IMAGE_INTERFACE_METER);
	MiterSize = *m_MiterImage->Get_Size();

	m_DrawBaseX = 0;
	m_BackGroundWidth = WIDTH;
}

void Miter::Draw(HDC m_backDC)
{
	for (int i = 0; i <= 1; i++)
	{
		m_MiterImage->TransparentDraw(m_backDC, m_DrawBaseX + (m_BackGroundWidth * i), DEAFULT_Y_COORD, MiterSize.cx, MiterSize.cy);
	}
}

void Miter::Update(float TotalMoveDistance)
{
	if (Character_Move_Coord <= TotalMoveDistance) TotalMoveDistance = Character_Move_Coord;

	while (TotalMoveDistance > m_BackGroundWidth)
		TotalMoveDistance -= m_BackGroundWidth;

	m_DrawBaseX = -(TotalMoveDistance);
}