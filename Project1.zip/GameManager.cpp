#include "GameManager.h"

#define CARD_CLOSE(card) card->CardClose(); card = NULL;


GameManager* GameManager::m_iThis = NULL;

GameManager::GameManager() {}


void GameManager::Init(HWND hWnd)
{
	BitMapManager::GetInstance()->Init(hWnd);

	SetTimer(hWnd, TIMER_ID, DEFAULT_TIME, NULL);

	m_Timer.m_iMin = 5;
	m_Timer.m_iSec = 0;

	m_ClickCard[0] = NULL;
	m_ClickCard[1] = NULL;

	m_CurScene = Scene::Before_GameStart_CardOpen_Scene;

	float X_Start_Coordinate = WIDTH * 0.01f;
	float Y_Start_Coordinate = HEIGHT * 0.01f;
	
	int CradWidth = CardSize::Width;
	int CradHeight = CardSize::Height;
	int LineBreak = LINE_BREAK;
	int LineBreakCount = 0;

	for (int i = 0, j = 0; i < IMAGE::IMAGE_END; i++)
	{
		if (LineBreakCount >= LineBreak)
		{
			++j;
			LineBreakCount = 0;
		}

		m_Card[i].Init(static_cast<IMAGE>(i), X_Start_Coordinate + ((SPACE_X_BETWEEN_CARDS + CradWidth) * i), Y_Start_Coordinate + ((SPACE_Y_BETWEEN_CARDS + CradHeight) * j));
		++LineBreakCount;
	}

	Cur_Scene_Start_Acting();
}

void GameManager::Cur_Scene_Start_Acting() // �ش� ���� ���۵Ǿ��� �� ���õǾ�� �� �͵�
{
	switch (m_CurScene)
	{
	case Scene::Before_GameStart_CardOpen_Scene:
		m_StopTime = static_cast<int>(All_OpenCard_Time);
		All_Card_Open();
		break;

	case Scene::GamePlaying_Scene:
		break;
	}
}


void GameManager::Display_Draw(HDC hdc) // ȭ�� �׸���
{
	switch (m_CurScene)
	{
	case Scene::Before_GameStart_CardOpen_Scene:
	case Scene::GamePlaying_Scene:
		Time_Draw(hdc);
		AllCard_Draw(hdc);
		break;
	}
}


void GameManager::Time_Draw(HDC hdc)
{
	std::string CurTime = std::to_string(m_Timer.m_iMin) + ":" + std::to_string(m_Timer.m_iSec);
	TextOut(hdc, WIDTH * 0.5f, HEIGHT * 0.01f, CurTime.c_str(), CurTime.length());
}
void GameManager::AllCard_Draw(HDC hdc)
{
	for (int i = 0; i < IMAGE::IMAGE_END; i++)
	{
		m_Card[i].Draw(hdc);
	}
}


void GameManager::All_Card_Close()
{
	for (int i = 0; i < IMAGE::IMAGE_END; i++)
	{
		m_Card[i].CardClose();
	}
}
void GameManager::All_Card_Open()
{
	for (int i = 0; i < IMAGE::IMAGE_END; i++)
	{
		m_Card[i].CardOpen();
	}
}


void GameManager::TimerCheck()
{
	if (0 < m_StopTime)
	{
		--m_StopTime;
		if (0 >= m_StopTime)
			StopTime_Check();
	}

	switch (m_CurScene)
	{
	case Scene::GamePlaying_Scene:
	case Scene::Card_Compare_Scene:
		--m_Timer.m_iSec;
		if (m_Timer.m_iSec < 0)
		{
			m_Timer.m_iSec = 59;
			--m_Timer.m_iMin;
			if (m_Timer.m_iMin < 0)
			{
				// ���� �й�
			}
		}
		break;
	}
}
void GameManager::StopTime_Check() // ���� �ð��� ������ �� ����Ǿ�� �� �͵�
{
	switch (m_CurScene)
	{
	case Scene::Before_GameStart_CardOpen_Scene:
		All_Card_Close();
		m_CurScene = Scene::GamePlaying_Scene;
		break;

	case Scene::GamePlaying_Scene:
		break;

	case Scene::Card_Compare_Scene:
		CARD_CLOSE(m_ClickCard[0]);
		CARD_CLOSE(m_ClickCard[1]);
		m_CurScene = Scene::GamePlaying_Scene;
		break;
	}
}


bool GameManager::Click_Check(POINT point)
{
	if (m_StopTime > 0)
		return false;

	switch (m_CurScene)
	{
	case Scene::Before_GameStart_CardOpen_Scene:
		return false;

	case Scene::GamePlaying_Scene:
		return Card_Click_Check(point);
	}
}
bool GameManager::Card_Click_Check(POINT point)
{
	for (int i = 0; i < IMAGE::IMAGE_END; i++)
	{
		if (m_Card[i].ColliderCheck(point) == true)
		{
			if (m_ClickCard[0] == NULL)
				m_ClickCard[0] = &m_Card[i];
			else
			{
				m_ClickCard[1] = &m_Card[i];
				if (Same_Card_Check() == true)
				{
				}
			}
			return true;
		}
	}
	return false;
}

bool GameManager::Same_Card_Check()
{
	if (m_ClickCard[0] != m_ClickCard[1])
	{
		m_StopTime = static_cast<int>(Not_SameCard_Time);
		m_CurScene = Scene::Card_Compare_Scene;
		return false;
	}
	else
	{
		m_ClickCard[0] = NULL;
		m_ClickCard[1] = NULL;
		return true;
	}
}

GameManager::~GameManager() {}