#include "GameManager.h"

GameManager* GameManager::m_iThis = NULL;

GameManager::GameManager() {}


void GameManager::Init(HWND hWnd)
{
	BitMapManager::GetInstance()->Init(hWnd);
	SetTimer(hWnd, TIMER_ID, DEFAULT_TIME, NULL);
	m_Timer.m_iMin = 5;
	m_Timer.m_iSec = 0;
	float X_Coordinate = WIDTH * 0.01f;
	float Y_Coordinate = HEIGHT * 0.01f;
	int PreCardRight = 0;
	int PreCardBottom = 0;
	int LineBreakCount = 0;
	int LineBreak = LINE_BREAK;
	for (int i = 0; i < IMAGE::IMAGE_END; i++)
	{
		if (LineBreakCount >= LineBreak)
		{
			LineBreak += LINE_BREAK;
			Y_Coordinate = PreCardBottom + SPACE_Y_BETWEEN_CARDS;
			PreCardRight = 0;
		}

		m_Card[i].Init(static_cast<IMAGE>(i), X_Coordinate + PreCardRight + SPACE_X_BETWEEN_CARDS, Y_Coordinate + 40);
	
		PreCardRight = m_Card[i].Get_Right();
		PreCardBottom = m_Card[i].Get_Bottom();
		++LineBreakCount;
	}
}

void GameManager::Draw(HDC hdc)
{
	std::string CurTime = std::to_string(m_Timer.m_iMin) + ":" + std::to_string(m_Timer.m_iSec);
	TextOut(hdc, WIDTH / 2, HEIGHT * 0.01f, CurTime.c_str(), CurTime.length());

	for (int i = 0; i < IMAGE::IMAGE_END; i++)
		m_Card[i].Draw(hdc);

}

void GameManager::TimerCheck()
{
	--m_Timer.m_iSec;
	if (m_Timer.m_iSec < 0)
	{
		m_Timer.m_iSec = 59;
		--m_Timer.m_iMin;
		if (m_Timer.m_iMin < 0)
		{
			// ���� �й�
		}
	}
}

void GameManager::GameStart(POINT point)
{
	for (int i = 0; i < IMAGE::IMAGE_END; i++)
		m_Card[i].ColliderCheck();
}

GameManager::~GameManager() {}