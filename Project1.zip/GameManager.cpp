#include "GameManager.h"

GameManager* GameManager::m_iThis = NULL;

GameManager::GameManager() {}


void GameManager::Init(HWND hWnd)
{
	BitMapManager::GetInstance()->Init(hWnd);
	SetTimer(hWnd, TIMER_ID, DEFAULT_TIME, NULL);
	m_Timer.m_iMin = 5;
	m_Timer.m_iSec = 0;
	m_bGameStratCheck = false;
	m_ClickCard[0] = NULL;
	m_ClickCard[1] = NULL;
	m_CurScene = Scene::Before_GameStart_CardOpen_Scene;

	float X_Coordinate = WIDTH * 0.01f;
	float Y_Coordinate = HEIGHT * 0.01f;
	int PreCardRight = 0;
	int PreCardBottom = 0;
	int LineBreakCount = 0;
	int LineBreak = LINE_BREAK;
	for (int i = 0; i < IMAGE::IMAGE_END; i++)
	{
		if (LineBreakCount >= LineBreak)
		{
			LineBreak += LINE_BREAK;
			Y_Coordinate = PreCardBottom + SPACE_Y_BETWEEN_CARDS;
			PreCardRight = 0;
		}

		m_Card[i].Init(static_cast<IMAGE>(i), X_Coordinate + PreCardRight + SPACE_X_BETWEEN_CARDS, Y_Coordinate + 40);
	
		PreCardRight = m_Card[i].Get_Right();
		PreCardBottom = m_Card[i].Get_Bottom();
		++LineBreakCount;
	}

	// 
	All_Card_Open();
	StopTime_Setting(All_OpenCard_Time);


		
}

void Cur_Scene_Check()
{

}
void GameManager::Display_Draw(HDC hdc, Scene scene)
{
	switch (scene)
	{
	case Scene::Before_GameStart_CardOpen_Scene:

	case Scene::GameStart_Scene:
		All_Display_Draw(hdc);
		break;
	}
}

void GameManager::StopTime_Setting(int Second)
{
	m_StopTime = Second;
}

void GameManager::All_Card_Close()
{
	for (int i = 0; i < IMAGE::IMAGE_END; i++)
	{
		m_Card[i].CardClose();
	}
}

void GameManager::All_Card_Open()
{
	for (int i = 0; i < IMAGE::IMAGE_END; i++)
	{
		m_Card[i].CardOpen();
	}
}

void GameManager::Time_Draw(HDC hdc)
{
	std::string CurTime = std::to_string(m_Timer.m_iMin) + ":" + std::to_string(m_Timer.m_iSec);
	TextOut(hdc, WIDTH / 2, HEIGHT * 0.01f, CurTime.c_str(), CurTime.length());
}

void GameManager::All_Display_Draw(HDC hdc)
{
	Time_Draw(hdc);
	for (int i = 0; i < IMAGE::IMAGE_END - 1; i++)
		m_Card[i].Draw(hdc);
}

void GameManager::AllCard_Draw(HDC hdc)
{
	for (int i = 0; i < IMAGE::IMAGE_END; i++)
	{
		m_Card[i].Draw(hdc);
	}
}

void GameManager::TimerCheck()
{
	if (0 < m_StopTime)
	{
		m_StopTime--;

		if(0 == m_StopTime && m_CurScene == Scene::Before_GameStart_CardOpen_Scene)
		{
			All_Card_Close();
			m_CurScene = Scene::GameStart_Scene;
			m_bGameStratCheck = true;
		}
	}



	if (m_CurScene == Scene::GameStart_Scene)
	{
		--m_Timer.m_iSec;
		if (m_Timer.m_iSec < 0)
		{
			m_Timer.m_iSec = 59;
			--m_Timer.m_iMin;
			if (m_Timer.m_iMin < 0)
			{
				// ���� �й�
			}
		}
	}
}

bool GameManager::Card_Click_Check(POINT point)
{
	for (int i = 0; i < IMAGE::IMAGE_END; i++)
	{
		if (m_Card[i].ColliderCheck(point) == true)
		{
			if(m_ClickCard[0] == NULL)
				m_ClickCard[0] = &m_Card[i];
			else
			{
				m_ClickCard[1] = &m_Card[i];
				if (Same_Card_Check() == false)
				{
					m_ClickCard[0]->CardClose();
					m_ClickCard[1]->CardClose();
					m_ClickCard[0] = NULL;
					m_ClickCard[1] = NULL;
				}
			}
			return true;
		}
	}
	return false;
}

bool GameManager::Same_Card_Check()
{
	if (m_ClickCard[0] != m_ClickCard[1])
	{
		StopTime_Setting(Not_SameCard_Time);
		return false;
	}
	else
	{
		m_ClickCard[0] = NULL;
		m_ClickCard[1] = NULL;
		return true;
	}
}

GameManager::~GameManager() {}