#pragma once
# include "Object.h"

enum RingImage
{
	LeftRing = 0,
	RightRing = 1
};

enum RingType
{
	Big,
	Small
};

class FireRing : public Object
{
private:
	Bitmap* m_Image[2][2];
	Bitmap* m_CurImage[2];

	Bitmap* m_MoneyImage;
	SIZE m_MoneySize;

	RingType Type;

	float AddWidth;
	int m_Speed = 0;

	float m_Time;

	virtual void Animation(const float& deltaTime) override;

public:
	FireRing();
	~FireRing();

	virtual void Init() override;
	virtual void Draw(HDC m_backDC) override;
	virtual void Update(float AllMoveDistance, float CurMoveDistance, const float& deltaTime) override;
	virtual void ContinuePlayUpdate(float ReturnDistance) override;

	inline void SetSpeed(int speed) { m_Speed = speed; }
	void SetSize(float x, RingType type, int num);
};

