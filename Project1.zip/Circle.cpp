#include "Circle.h"

Circle::Circle() {}

Circle::~Circle() {}

void Circle::Init(Vector2 v)
{

}

void Circle::Draw()
{

}
