#pragma once
#include <Windows.h>
#include <vector>
#include <cmath>
#include "Vector2.h"

#define GRAVITY 9.80665

enum SystemData
{
	WIDTH = 900,
	HEIGHT = 900
	
};