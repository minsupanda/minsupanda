#pragma once
#include<Windows.h>
#include<string.h>
#include<stdlib.h>
#include<stdio.h>
