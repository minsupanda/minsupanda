#pragma once
#include <Windows.h>
#include "Vector2.h"

enum SystemData
{
	WIDTH = 900,
	HEIGHT = 900,
};