#pragma once
#include<iostream>
#include<Windows.h>
#include<string>
#include<stdlib.h>
#include<stdio.h>

#define WIDTH 1000
#define HEIGHT 900
#define WINDOW_X_COORDINATE 55
#define WINDOW_Y_COORDINATE 5
#define SPACE_X_BETWEEN_CARDS 10
#define SPACE_Y_BETWEEN_CARDS 5

enum class Scene
{
	Before_GameStart_CardOpen_Scene,
	GameStart_Scene,
	Card_Compare_Scene
};