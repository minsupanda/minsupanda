#pragma once
#include"Mecro.h"

enum FigureType
{
	CireCle,
	Square
};

class Figure
{
private:
	FigureType m_Type;
	
	Vector2 m_Position; // ��ġ
	Vector2 m_Velocity; // �ӵ�
	Vector2 m_HalfSize; // ũ��

	float m_e; // �ݹ߰��
	float m_Mass; // ����, 0�� �� �� ����
	float m_Inv_Mass; // ������

public:
	Figure();
	virtual ~Figure();
	
	float Get_e() { return m_e; }
	float Get_Inv_Mass() { return m_Inv_Mass; }
	Vector2 Get_HalfSize() { return m_HalfSize; }

	virtual void Init(Vector2 v) abstract;
	virtual void Draw() abstract;

	void AddForce();
	void Update();
};

