#pragma once
#include"Mecro.h"

enum class FigureType
{
	CireCle,
	Box
};

class Figure
{
protected:
	FigureType m_Type;
	
	Vector2 m_Position; // ��ġ
	Vector2 m_Velocity; // �ӵ�
	Vector2 m_HalfSize; // ũ��

	float m_e; // �ݹ߰��
	float m_Mass; // ����, 0�� �� �� ����
	float m_Inv_Mass; // ������

public:
	Figure();
	virtual ~Figure();

	virtual void Init(Vector2 v, Vector2 p, Vector2 f) abstract;
	virtual void Draw(HDC backDC) abstract;
	
	FigureType Get_Type() { return m_Type; }
	float Get_e() { return m_e; }
	float Get_Mass() { return m_Mass; }
	float Get_Inv_Mass() { return m_Inv_Mass; }
	Vector2 Get_Position() { return m_Position; }
	Vector2 Get_HalfSize() { return m_HalfSize; }
	Vector2 Get_Velocity() { return m_Velocity; }

	void ReSet_Velocity() { m_Velocity = { 0, 0 }; }

	void AddForce(Vector2 force);
	void Update(const float& deltaTime);
};

