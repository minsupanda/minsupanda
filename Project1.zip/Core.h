#pragma once
#include"Mecro.h"
#include"PhysicsEngine.h"
#include"Circle.h"
#include"Square.h"
#include<vector>

class Core
{
private:
	Core();
	static Core* m_This;

	HWND m_hWnd;
	HDC m_frontDC;
	HDC m_backDC;
	HBITMAP m_backBitmap;

	float m_Width;
	float m_Height;

	std::vector<Figure*> Firgures;
	std::vector<Figure*> Circles;
	std::vector<Figure*> Square;
	PhysicsEngine physicsEngine;

	HBITMAP MyCreateDIBSection(HDC hdc, int width, int height);
	void CollisionCheck();

public:
	~Core();
	void Release(); // DC �����ϴ� �Լ�
	void Destory(); // Ŭ���� �ı�

	
	static Core* Get_Instance()
	{
		if (m_This == NULL)
			m_This = new Core;
		return m_This;
	}

	void Init(HWND hWnd);
	void Draw();
	void Update(const float& deltaTime);
};