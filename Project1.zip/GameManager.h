#pragma once
#include"Mecro.h"
#include"Card.h"

#define GameMgr GameManager::Get_Instance()
#define LINE_BREAK 5

class GameManager
{
private:
	GameManager();
	static GameManager* m_iThis;

	Card m_Card[IMAGE_END];

public:
	~GameManager();
	static GameManager* Get_Instance()
	{
		if (m_iThis == NULL)
			m_iThis = new GameManager;
		return m_iThis;
	}

	void Init(HWND hWnd);
	void Draw(HDC hdc);
};