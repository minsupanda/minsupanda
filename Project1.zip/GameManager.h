#pragma once
#include"Mecro.h"
#include"Card.h"
#include"Timer.h"

#define GameMgr GameManager::Get_Instance()
#define TIMER_ID 1
#define DEFAULT_TIME 1000
#define LINE_BREAK 4

struct Timer
{
	int m_iMin;
	int m_iSec;
};

class GameManager
{
private:
	GameManager();
	static GameManager* m_iThis;

	Card m_Card[IMAGE_END];
	Timer m_Timer;
public:
	~GameManager();
	static GameManager* Get_Instance()
	{
		if (m_iThis == NULL)
			m_iThis = new GameManager;
		return m_iThis;
	}

	void Init(HWND hWnd);
	void Draw(HDC hdc);
	void TimerCheck();
	void GameStart(POINT point);
};