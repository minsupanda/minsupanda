#pragma once
#include"Mecro.h"
#include"Card.h"

class GameManager
{
private:
	Card m_AllCard[CARD_END];
public:

};

