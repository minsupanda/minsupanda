#pragma once
#include"Mecro.h"
#include"Card.h"
#include"Timer.h"
#include<time.h>


#define GameMgr GameManager::Get_Instance()
#define TIMER_ID 1
#define DEFAULT_TIME 1000
#define NOT_SAME_CARD_TIME 3000
#define ALL_OPEN_CARD_TIME 5000
#define LINE_BREAK 4

enum TimerSecond
{
	Default_Time = 1,
	Not_SameCard_Time = 3,
	All_OpenCard_Time = 5
};

struct Timer
{
	int m_iMin;
	int m_iSec;
};

class GameManager
{
private:
	GameManager();
	static GameManager* m_iThis;

	Card m_Card[IMAGE_END];
	Card* m_ClickCard[2];
	Timer m_Timer;
	int m_StopTime;
	bool m_bGameStratCheck;
	Scene m_CurScene;
public:
	~GameManager();
	static GameManager* Get_Instance()
	{
		if (m_iThis == NULL)
			m_iThis = new GameManager;
		return m_iThis;
	}

	void Init(HWND hWnd);
	void Display_Draw(HDC hdc, Scene scene);
	void All_Display_Draw(HDC hdc);
	void AllCard_Draw(HDC hdc);
	void Time_Draw(HDC hdc);
	void TimerCheck();
	bool Card_Click_Check(POINT point);
	bool Same_Card_Check();
	void StopTime_Setting(int Sceond);
	void All_Card_Close();
	void All_Card_Open();
	inline Scene Get_CurScene() { return m_CurScene; }
	inline int Get_StopTime() { return m_StopTime; }
};