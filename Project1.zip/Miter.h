#pragma once
#include"Mecro.h"
#include"BitmapManager.h"

#define DEAFULT_X_COORD WIDTH * 0.03f
#define DEAFULT_Y_COORD HEIGHT * 0.83f

enum
{
	Max_Miter = 100
};

class Miter
{
private:
	Bitmap* m_MiterImage;
	SIZE m_Size;

	int m_CurMiter;

	float m_fx;
	float m_fy;
	

public:
	Miter();
	~Miter();

	void Init();
	void ContinuePlayUpdate(float ReturnDistance);
	void Draw(HDC m_backDC);
	void Update(float TotalMoveDistance, float CurMoveDistance);
};

