#include "Square.h"

Square::Square() {}

Square::~Square() {}

void Square::Init(Vector2 v)
{

}

void Square::Draw()
{

}
