#include "Square.h"

Square::Square() {}

Square::~Square() {}

void Square::Init(Vector2 v, Vector2 p)
{

}

void Square::Draw(HDC backDC)
{

}
