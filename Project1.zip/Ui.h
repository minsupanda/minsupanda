#pragma once
#include "Mecro.h"
#include "BitmapManager.h"

enum UiImage
{
	GameName,
	Select,
	Player1A,
	Player1B,
	Player2A,
	Player2B,
	Cursor,
	InterfaceBar,
	LifeImage,

	BlueStar = 0,
	RedStar = 1,
	YellowStar = 2,

	Star_Width_Number = 16,
	Star_Height_Nuber = 5,

	Pont_Size = 20
};

enum UiSize
{
	GameName_Size,
	Select_Size,
	Players_Size,
	Cursor_Size,
	InterfaceBar_Size,
	LifeImage_Size
};

class Ui
{
private:
	Bitmap* m_UiImage[9];
	SIZE* m_UiSize[6];

	Bitmap* m_StarImage[3];
	SIZE* m_StarSize;
	float m_StarChangeTime;

	float CursorPosition;

public:
	Ui();
	~Ui();

	void Init();
	void Update(const float& deltaTime);
	void Lobby_Draw(HDC backDC);
	void Playing_Draw(HDC backDC, const int* totalscore, const int* bonusscore, const int* life);
};

