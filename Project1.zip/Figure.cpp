#include "Figure.h"

Figure::Figure() {}

Figure::~Figure() {}

void Figure::Init(Vector2 v, Vector2 p, Vector2 f) {}

void Figure::Draw(HDC backDC) {}

void Figure::AddForce(Vector2 force)
{
	m_Velocity += force;
}

void Figure::Update(const float& deltaTime)
{
	m_Position += m_Velocity * deltaTime;
}
