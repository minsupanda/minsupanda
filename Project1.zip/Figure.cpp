#include "Figure.h"

Figure::Figure() {}

Figure::~Figure() {}

void Figure::Init(Vector2 v)
{

}

void Figure::Draw()
{

}

void Figure::AddForce()
{

}

void Figure::Update()
{

}
