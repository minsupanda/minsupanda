#include "Goal.h"
#include<string>

Goal::Goal()
{
}

Goal::~Goal()
{
}

void Goal::Init()
{
	m_GoalImage = BitmapMgr->Get_Image(IMAGE_GOAL);

	GoalSize = m_GoalImage->Get_Size();

	m_fx = WIDTH;
	m_fy = DEAFULT_Y_COORD;
	m_GoalRange.left = m_fx;
	m_GoalRange.right = m_fx + GoalSize->cx;
	m_GoalRange.top = m_fy - GoalSize->cy;
	m_GoalRange.bottom = m_fy;

	m_BackGroundWidth = WIDTH * 0.3f;
	m_GoalDrawDist = Character_Move_Coord - m_BackGroundWidth;

	m_DrawBaseX = 0;

	m_bDraw = false;
}

// ���ݱ��� ĳ���Ͱ� �󸶸�ŭ ���������� >= ��밡 ��Ÿ���� ����
// �̶����͸� �������� ĳ���Ͱ� �����̴� ��ŭ ��밡 �ٰ����� ����� �ȴ�.

void Goal::Update(float AllMoveDistance)
{
	if (AllMoveDistance >= m_GoalDrawDist)
	{
		m_bDraw = true;

		if (Character_Move_Coord <= AllMoveDistance) AllMoveDistance = Character_Move_Coord;

		while (AllMoveDistance - m_GoalDrawDist > m_BackGroundWidth)
			AllMoveDistance -= m_BackGroundWidth;

		m_DrawBaseX = -(AllMoveDistance - m_GoalDrawDist);

		m_GoalRange.left = m_fx + m_DrawBaseX;
		m_GoalRange.right = m_fx + GoalSize->cx;
	}
	else m_bDraw = false;
}

void Goal::Draw(HDC& m_backDC)
{
	if (m_bDraw == true)
	{
		std::wstring dist = L"left :" + std::to_wstring(m_GoalRange.left) + L" right:" + std::to_wstring(m_GoalRange.right) + L"top: " + std::to_wstring(m_GoalRange.top) + L"bottopm: " + std::to_wstring(m_GoalRange.bottom);
		TextOutW(m_backDC, 300, 1, dist.c_str(), dist.length());
		m_GoalImage->TransparentDraw(m_backDC, m_fx + m_DrawBaseX, m_fy, GoalSize->cx, GoalSize->cy);
	}
}

