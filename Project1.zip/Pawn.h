#pragma once
#include "Piece.h"

class Pawn : public Piece
{
private:

public:
	Pawn();
	Pawn(PieceColor color);
	~Pawn();

	virtual void MoveCheck(std::vector<RECT>& m_MoveblePosition) override;
};

