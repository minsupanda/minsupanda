#include "Pawn.h"

Pawn::Pawn() {}
Pawn::Pawn(PieceColor color)
{
	m_piece = PieceType::Pawn;
	m_color = color;
	m_pieceImage = BitmapMgr->Get_Image((int)PieceType::Pawn + (int)color);
}
Pawn::~Pawn()
{
}

void Pawn::MoveCheck(std::vector<RECT>& m_MoveblePosition)
{
	m_MoveblePosition.clear();
	RECT MovelbePosition;
	switch (m_color)
	{
	case BLACK:
		MovelbePosition = { m_BitmapRect.left, m_BitmapRect.top + m_height, m_BitmapRect.right, m_BitmapRect.bottom + m_height };
		m_MoveblePosition.push_back(MovelbePosition);
		break;
	
	case WHITE:
		MovelbePosition = { m_BitmapRect.left, m_BitmapRect.top - m_height, m_BitmapRect.right, m_BitmapRect.bottom - m_height };
		m_MoveblePosition.push_back(MovelbePosition);
		break;
	}
}
