#include "Pawn.h"

Pawn::Pawn()
{
}
Pawn::~Pawn()
{
}

void Pawn::MoveCheck()
{
}
