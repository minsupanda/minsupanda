#pragma once
#include "Mecro.h"
#include "BitmapManager.h"
#include "Piece.h"

#define GameBoardMgr GameBoardManager::Get_Instance()

enum TileColor
{
	SkinColor = 0,
	BrownColor = 1
};

struct TileCoord
{
	RECT BitmapRect;
	int m_ix;
	int m_iy;

	Piece* piece;
};

class GameBoardManager
{
private:
	GameBoardManager();

	static GameBoardManager* m_hThis;

	Bitmap* m_Image[2];
	int m_width;
	int m_height;

	TileCoord m_Tile[8][8];

public:
	~GameBoardManager();
	static GameBoardManager* Get_Instance()
	{
		if (m_hThis == NULL)
			m_hThis = new GameBoardManager;
		return m_hThis;
	}
	TileCoord* Point_in_TileRect_Check(POINT point);

	void Init(int x, int y, int width, int height);
	void Draw(HDC hdc);

	void Distory();
};

