#include "BitmapManager.h"

BitmapManager* BitmapManager::m_hThis = NULL;

BitmapManager::BitmapManager()
{
}


void BitmapManager::Init(HWND hWnd)
{
	char buf[256];
	HDC hdc = GetDC(hWnd);
	for (int i = IMAGE_START; i < IMAGE_END; i++)
	{
		if (i <= IMAGE_KING)
		{
			sprintf_s(buf, "block_b_%d", i);
			m_parrBitMap[i].Init(hdc, buf);
			sprintf_s(buf, "block_w_%d", i);
			m_parrBitMap[++i].Init(hdc, buf);
		}
		else if (i == IMAGE_SELECT)
		{
			sprintf_s(buf, "MoveableTileMask");
			m_parrBitMap[i].Init(hdc, buf);
		}
		else if(i == IMAGE_FRIST_TILE)
		{
			sprintf_s(buf, "tile_0");
			m_parrBitMap[i].Init(hdc, buf);
			sprintf_s(buf, "tile_1");
			m_parrBitMap[++i].Init(hdc, buf);
		}
	}

	ReleaseDC(hWnd, hdc);
}

BitmapManager::~BitmapManager()
{
	Distory();
}

void BitmapManager::Distory()
{
	if (m_hThis)
	{
		delete m_hThis;
		m_hThis = NULL;
	}
}
