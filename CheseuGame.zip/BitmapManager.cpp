#include "BitmapManager.h"

BitmapManager* BitmapManager::m_hThis = NULL;

BitmapManager::BitmapManager()
{
}


void BitmapManager::Init(HWND hWnd)
{
	char buf[256];
	HDC hdc = GetDC(hWnd);
	
	for (int i = IMAGE_START; i <= IMAGE_KING; i++)
	{
		//if (i <= IMAGE_KING)
		//Bitmap Image; ó���� �� �ߴ� ���
		//Image = new Bitmap;
		//m_parrBitMap[index].Init(hdc, buf);
		//++index;
		sprintf_s(buf, "block_b_%d.bmp", i);
		m_parrBitMap.push_back(Bitmap());
		m_parrBitMap.back().Init(hdc, buf);

		sprintf_s(buf, "block_w_%d.bmp", i);
		m_parrBitMap.push_back(Bitmap());
		m_parrBitMap.back().Init(hdc, buf); // ���� index���� �� �ʿ���� back���� ��� ������ ������ �ʱ�ȭ
	}

	for (int i = 0; i <= 1; i++)
	{
		sprintf_s(buf, "tile_%d.bmp", i);
		m_parrBitMap.push_back(Bitmap());
		m_parrBitMap.back().Init(hdc, buf);
	}

	sprintf_s(buf, "MoveableTileMask.bmp");
	m_parrBitMap.push_back(Bitmap());
	m_parrBitMap.back().Init(hdc, buf);

	ReleaseDC(hWnd, hdc);
}

BitmapManager::~BitmapManager()
{
	Distory();
}

void BitmapManager::Distory()
{
	if (m_hThis)
	{
		delete m_hThis;
		m_hThis = NULL;
	}
}
