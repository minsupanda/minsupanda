#pragma once
#include "Mecro.h"
#include "BitmapManager.h"

enum class PieceName
{
	Pawn,
	Bishop,
	Knight,
	Rook,
	Queen,
	King
};

class Piece
{
private:
	PieceName m_pieceName;
	Bitmap* m_pieceImage;

	int m_ix;
	int m_iy;
	int m_width;
	int m_height;
	RECT m_BitmapRect;

public:
	Piece();
	~Piece();
	
	void Init(int imageInedex, int x, int y, int width, int height);
};

