#pragma once
#include "Mecro.h"
#include "BitmapManager.h"

enum class PieceType
{
	Pawn = 0,
	Rook = 2,
	Knight = 4,
	Bishop = 6,
	Queen = 8,
	King = 10
};

class Piece abstract
{
protected:
	PieceType m_piece;
	Bitmap* m_pieceImage;

	int m_ix;
	int m_iy;
	int m_width;
	int m_height;
	RECT m_BitmapRect;

public:
	Piece();
	~Piece();
	
	virtual void MoveCheck() abstract = 0;

	bool Point_In_PieceRect_Check(POINT point)
	{
		if (PtInRect(&m_BitmapRect, point))
			return true;
	}

	void Init(int x, int y, int width, int height);
	void Draw(HDC hdc);
};

