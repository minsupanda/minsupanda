#pragma once
#include "Piece.h"

class Pawn : public Piece
{
private:

public:
	Pawn();
	~Pawn();

	virtual void MoveCheck() override;
};

