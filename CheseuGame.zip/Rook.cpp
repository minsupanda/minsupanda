#include "Rook.h"

Rook::Rook()
{
}

Rook::~Rook()
{
}

void Rook::MoveCheck()
{
}
