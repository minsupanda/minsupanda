#include "Rook.h"

Rook::Rook() {}
Rook::Rook(PieceColor color)
{
	m_piece = PieceType::Rook;
	m_color = color;
	m_pieceImage = BitmapMgr->Get_Image((int)PieceType::Rook + (int)color);
}

Rook::~Rook()
{
}

void Rook::MoveCheck(std::vector<RECT>& m_MoveblePosition)
{
}
