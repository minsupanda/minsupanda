#pragma once
#include "Piece.h"

class Knight : public Piece
{
private:

public:
	Knight();
	~Knight();

	virtual void MoveCheck() override;
};

