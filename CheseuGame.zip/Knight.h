#pragma once
#include "Piece.h"

class Knight : public Piece
{
private:

public:
	Knight();
	Knight(PieceColor color);
	~Knight();

	virtual void MoveCheck() override;
};

