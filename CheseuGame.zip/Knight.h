#pragma once
#include "Piece.h"

class Knight : public Piece
{
private:

public:
	Knight(PieceColor color);
	~Knight();

	virtual void MoveCheck(std::vector<TileIndex>& m_MoveblePosition) override;
	void MoveRectSave(int x, int y, std::vector<TileIndex>& m_MoveblePosition);
};

