#pragma once
#include "Piece.h"

class Knight : public Piece
{
private:

public:
	Knight();
	Knight(PieceColor color);
	~Knight();

	virtual void MoveCheck(std::vector<RECT>& m_MoveblePosition) override;
};

