#include "GameBoardManager.h"

GameBoardManager* GameBoardManager::m_hThis = NULL;

GameBoardManager::GameBoardManager() {}

void GameBoardManager::Init(int x, int y, int width, int height)
{
	m_Image[SkinColor] = BitmapMgr->Get_Image(IMAGE_FRIST_TILE);
	m_Image[BrownColor] = BitmapMgr->Get_Image(IMAGE_SECOND_TILE);
	m_width = width; // Window_Width * 0.12f;
	m_height = height; // Window_Height * 0.12f;

	for (int i = 0; i < 8; i++)
	{
		for (int j = 0; j < 8; j++)
		{
			m_Tile[i][j].m_ix = x;
			m_Tile[i][j].m_iy = y;
			m_Tile[i][j].BitmapRect.left = x;
			m_Tile[i][j].BitmapRect.top = y;
			m_Tile[i][j].BitmapRect.right = x + m_width;
			m_Tile[i][j].BitmapRect.bottom = y + m_width;
			// �ʿ� ���� : ���� ����� ������ �ð� ���⵵���� ���� ���⵵�� �� �켱���ϴ� ���� ȿ�����̱� ������ ����� �ʿ��Ҷ� ����ϱ�.

			m_Tile[i][j].piece = NULL;
			x += m_width;
		}
		x = 0;
		y += m_height;
	}
}

void GameBoardManager::PieceCoord_In_Tile_Save(std::vector<Piece*> Pieces[2])
{
	int x = 0;
	for(auto iter = Pieces[BLACK].begin(); iter != Pieces[BLACK].end(); iter++)
	{
		Piece* p = (*iter);
		m_Tile[p->GetCY()][p->GetCX()].piece = p;
		/*if ((*iter)->Get_PieceType() == PieceType::Pawn)
		{
			m_Tile[x++][1].piece = *iter++;
		}
		else if((*iter)->Get_PieceType() == PieceType::Rook)
		{
			m_Tile[0][0].piece = *iter++;
			m_Tile[7][0].piece = *iter++;
		}
		else if ((*iter)->Get_PieceType() == PieceType::Knight)
		{
			m_Tile[1][0].piece = *iter++;
			m_Tile[6][0].piece = *iter++;
		}
		else if ((*iter)->Get_PieceType() == PieceType::Bishop)
		{
			m_Tile[2][0].piece = *iter++;
			m_Tile[5][0].piece = *iter++;
		}
		else
		{
			m_Tile[3][0].piece = *iter++;
			m_Tile[4][0].piece = *iter++;
		}*/
	}
	x = 0;
	for (auto iter = Pieces[WHITE].begin(); iter != Pieces[WHITE].end(); iter++)
	{
		Piece* p = (*iter);
		m_Tile[p->GetCY()][p->GetCX()].piece = p;
		/*if ((*iter)->Get_PieceType() == PieceType::Pawn)
		{
			m_Tile[x++][6].piece = *iter++;
		}
		else if ((*iter)->Get_PieceType() == PieceType::Rook)
		{
			m_Tile[0][7].piece = *iter++;
			m_Tile[7][7].piece = *iter++;
		}
		else if ((*iter)->Get_PieceType() == PieceType::Knight)
		{
			m_Tile[1][7].piece = *iter++;
			m_Tile[6][7].piece = *iter++;
		}
		else if ((*iter)->Get_PieceType() == PieceType::Bishop)
		{
			m_Tile[2][7].piece = *iter++;
			m_Tile[5][7].piece = *iter++;
		}
		else
		{
			m_Tile[3][7].piece = *iter++;
			m_Tile[4][7].piece = *iter++;
		}*/
	}
}

void GameBoardManager::Draw(HDC hdc)
{ 
	int CurColor = SkinColor;
	int ChangeColor = BrownColor;
	for (int i = 0; i < 8; i++)
	{
		for (int j = 0; j < 8; j++)
		{
			m_Image[CurColor]->Draw(hdc, m_Tile[i][j].m_ix, m_Tile[i][j].m_iy, m_Tile[i][j].m_ix + m_width, m_Tile[i][j].m_iy + m_height);
			int tmpColor = CurColor;
			CurColor = ChangeColor;
			ChangeColor = tmpColor;
		}
		int tmpColor = CurColor;
		CurColor = ChangeColor;
		ChangeColor = tmpColor;
	}
}

TileCoord* GameBoardManager::Point_in_TileRect_Check(POINT point)
{
	for (int i = 0; i < 8; i++)
	{
		for (int j = 0; j < 8; j++)
		{
			TileCoord* tile = &m_Tile[i][j];
			if (PtInRect(&tile->BitmapRect, point))
				return tile;
		}
	}
	return nullptr;
}

void GameBoardManager::Distory()
{
	if (m_hThis)
	{
		delete m_hThis;
		m_hThis = NULL;
	}
}

GameBoardManager::~GameBoardManager()
{
	Distory();
}
