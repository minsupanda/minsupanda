#pragma once
#include"Mecro.h"
#include"Bitmap.h"
#include<vector>

#define BitmapMgr BitmapManager::Get_Instance()

enum IMAGE
{
	IMAGE_START,
	
	IMAGE_PAWN = 0,
	IMAGE_BISHOP,
	IMAGE_KNIGHT,
	IMAGE_ROOK, 
	IMAGE_QUEEN,
	IMAGE_KING, 

	IMAGE_FRIST_TILE, 
	IMAGE_SECOND_TILE, 

	IMAGE_SELECT,

	IMAGE_END
};


class BitmapManager
{
private:
	BitmapManager();

	static BitmapManager* m_hThis;

	std::vector<Bitmap> m_parrBitMap; // BitmapManager�� �÷����� �˰� ���� �ʿ䰡 ���� Bitmap ������ �˰� ������ �ȴ�.
	

public:
	static BitmapManager* Get_Instance()
	{
		if (m_hThis == NULL)
			m_hThis = new BitmapManager;
		return m_hThis;
	}
	Bitmap* Get_Image(int index) { return &m_parrBitMap[index]; }

	void Init(HWND hWnd);

	void Distory();
	~BitmapManager();
};

