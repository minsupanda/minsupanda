#include "PieceManager.h"

PieceManager* PieceManager::m_hThis = NULL;

PieceManager::PieceManager() {}

void PieceManager::Init()
{
	for (int i = 0; i <= IMAGE_KING; i++)
	{
		/*Pieces[BLACK][i]->Init(i, );*/
		//Pieces[WHITE][i]->Init(i + 1);
	}

}

void PieceManager::Distory()
{
	if (m_hThis)
	{
		delete m_hThis;
		m_hThis = NULL;
	}
}
PieceManager::~PieceManager()
{
	Distory();
}
