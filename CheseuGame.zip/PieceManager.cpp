#include "PieceManager.h"
#include "Pawn.h"
#include "Rook.h"
#include "Knight.h"
#include "Bishop.h"
#include "Queen.h"
#include "King.h"

PieceManager* PieceManager::m_hThis = NULL;

PieceManager::PieceManager() {}

void PieceManager::Init(int x, int y, int width, int height)
{
	for (int i = 0; i < 4; i++)
	{
		CoordInit<Pawn, Pawn>(BLACK, x, y + width, width, height, i);
		CoordInit<Pawn, Pawn>(WHITE, x, height * 6, width, height, i);
	}

	CoordInit<Rook, Rook>(BLACK, x, y, width, height, 0);
	CoordInit<Rook, Rook>(WHITE, x, height * 7, width, height, 0);

	CoordInit<Knight, Knight>(BLACK, x, y, width, height, 1);
	CoordInit<Knight, Knight>(WHITE, x, height * 7, width, height, 1);

	CoordInit<Bishop, Bishop>(BLACK, x, y, width, height, 2);
	CoordInit<Bishop, Bishop>(WHITE, x, height * 7, width, height, 2);
	
	CoordInit<Queen, King>(BLACK, x, y, width, height, 3);
	CoordInit<Queen, King>(WHITE, x, height * 7, width, height, 3);
}


void PieceManager::Draw(HDC hdc)
{
	for (Piece* p : Pieces[BLACK])p->Draw(hdc);

	for (Piece* p : Pieces[WHITE])p->Draw(hdc);
}

void PieceManager::Distory()
{
	if (m_hThis)
	{
		delete m_hThis;
		m_hThis = NULL;
	}
}
PieceManager::~PieceManager()
{
	Distory();
}
