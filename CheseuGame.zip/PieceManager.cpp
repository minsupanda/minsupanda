#include "PieceManager.h"
#include "Pawn.h"

PieceManager* PieceManager::m_hThis = NULL;

PieceManager::PieceManager() {}

void PieceManager::Init(int x, int y, int width, int height)
{
	for (int i = 0; i < 4; i++)
	{

		Pieces[BLACK].push_back(new Pawn()); // �����ϱ�
		Pieces[BLACK].back()->Init((int)PieceName::Pawn, x + (width * i), y + height, width, height);

		Pieces[BLACK].push_back(new Pawn());
		Pieces[BLACK].back()->Init((int)PieceName::Pawn, x + (width * (7 - i)), y + height, width, height);

		Pieces[WHITE].push_back(new Pawn());
		Pieces[WHITE].back()->Init((int)PieceName::Pawn + 1, x + (width * i), y + (height * 6), width, height);

		Pieces[WHITE].push_back(new Pawn());
		Pieces[WHITE].back()->Init((int)PieceName::Pawn + 1, x + (width * (7 - i)), y + (height * 6), width, height);
	}
}

void PieceManager::Draw(HDC hdc)
{
	for (Piece* p : Pieces[BLACK])p->Draw(hdc);

	for (Piece* p : Pieces[WHITE])p->Draw(hdc);
}

void PieceManager::Distory()
{
	if (m_hThis)
	{
		delete m_hThis;
		m_hThis = NULL;
	}
}
PieceManager::~PieceManager()
{
	Distory();
}
