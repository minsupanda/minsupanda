#pragma once
#include "Piece.h"

class Bishop : public Piece
{
private:

public:
	Bishop(PieceColor color);
	~Bishop();

	virtual void MoveCheck(std::vector<RECT>& m_MoveblePosition)override;

};

