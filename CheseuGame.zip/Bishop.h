#pragma once
#include "Piece.h"

class Bishop : public Piece
{
private:

public:
	Bishop(PieceColor color);
	~Bishop();

	virtual void MoveCheck(std::vector<TileIndex>& m_MoveblePosition)override;
	void DiagonalLineCheck(int x, int y, std::vector<TileIndex>& m_MoveblePosition);
	bool MoveRectSave(int x, int y, std::vector<TileIndex>& m_MoveblePosition);

};

