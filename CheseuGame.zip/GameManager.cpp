#include "GameManager.h"
#include "GameBoardManager.h"
#include "PieceManager.h"

GameManager* GameManager::m_hThis = NULL;

GameManager::GameManager()
{
}

GameManager::~GameManager()
{
}

void GameManager::Init(HWND hWnd)
{
	RECT rcClient;
	GetClientRect(hWnd, &rcClient);
	int ClientWidth = rcClient.right - rcClient.left;
	int ClientHeight = rcClient.bottom - rcClient.top;

	BitmapMgr->Init(hWnd);
	GameBoardMgr->Init(0, 0, ClientWidth / 8, ClientHeight / 8);
	PieceMgr->Init(0, 0, ClientWidth / 8, ClientHeight / 8);

	m_CurPlayColor = WHITE;
	m_ClickTileImage = BitmapMgr->Get_Image((int)IMAGE_SELECT);
}



bool GameManager::Click_Check(POINT Point)
{
	m_MoveblePosition.clear();

	auto tile = GameBoardMgr->Point_in_TileRect_Check(Point); 
	if (tile->piece != nullptr)
	{
		if (tile->piece->Get_Color() == m_CurPlayColor)
			tile->piece->MoveCheck(GameMgr->m_MoveblePosition);
	}
	return false;
}

void GameManager::Draw(HDC hdc)
{
	GameBoardMgr->Draw(hdc);
	PieceMgr->Draw(hdc);
	for (auto Position : m_MoveblePosition)
		m_ClickTileImage->MovableTileDraw(hdc, Position.left, Position.top, Position.right - Position.left, Position.bottom - Position.top);

}
