#include "GameManager.h"
#include "GameBoardManager.h"
#include "PieceManager.h"

GameManager* GameManager::m_hThis = NULL;

GameManager::GameManager()
{
}

GameManager::~GameManager()
{
}

void GameManager::Init(HWND hWnd)
{
	BitmapMgr->Init(hWnd);

	RECT rcClient;
    GetClientRect(hWnd, &rcClient);
    int ClientWidth = rcClient.right - rcClient.left;
    int ClientHeight = rcClient.bottom - rcClient.top;
	GameBoardMgr->Init(0, 0, ClientWidth / 8, ClientHeight / 8);

	PieceMgr->Init(0, 0, ClientWidth / 8, ClientHeight / 8);

}

bool GameManager::Click_Check(POINT Point)
{
	return true;
}

void GameManager::Draw(HDC hdc)
{
	GameBoardMgr->Draw(hdc);
	PieceMgr->Draw(hdc);
}
