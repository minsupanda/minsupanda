#include "GameManager.h"

GameManager* GameManager::m_hThis = NULL;

GameManager::GameManager()
{
}

GameManager::~GameManager()
{
}

void GameManager::Init()
{

}

bool GameManager::Click_Check(POINT Point)
{
	return true;
}

void GameManager::Draw()
{

}
