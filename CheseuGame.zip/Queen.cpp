#include "Queen.h"
#include "GameBoardManager.h"

Queen::Queen(PieceColor color)
{
	m_piece = PieceType::Queen;
	m_color = color;
	m_pieceImage = BitmapMgr->Get_Image((int)PieceType::Queen + (int)color);
}

Queen::~Queen()
{
}

void Queen::MoveCheck(std::vector<TileIndex>& m_MoveblePosition)
{
	m_MoveblePosition.clear(); // Ȥ�� �� ������ �����ϱ� ���� clear

	int x = GetCX();
	int y = GetCY();

	WidthLineCheck(x, y, m_MoveblePosition);
	HeightLineCheck(x, y, m_MoveblePosition);
	DiagonalLineCheck(x, y, m_MoveblePosition);
}

void Queen::WidthLineCheck(int x, int y, std::vector<TileIndex>& m_MoveblePosition)
{
	int CheckX = x;
	int CheckY = y;

	while (CheckX < 7)
	{
		++CheckX;
		if (MoveRectSave(CheckX, CheckY, m_MoveblePosition) == false)
			break;

	}

	CheckX = x;

	while (CheckX > 0)
	{
		--CheckX;
		if (MoveRectSave(CheckX, CheckY, m_MoveblePosition) == false)
			break;
	}

}

void Queen::HeightLineCheck(int x, int y, std::vector<TileIndex>& m_MoveblePosition)
{
	int CheckX = x;
	int CheckY = y;

	while (CheckY < 7)
	{
		++CheckY;
		if (MoveRectSave(CheckX, CheckY, m_MoveblePosition) == false)
			break;
	}

	CheckY = y;

	while (CheckY > 0)
	{
		--CheckY;
		if (MoveRectSave(CheckX, CheckY, m_MoveblePosition) == false)
			break;
	}

}

void Queen::DiagonalLineCheck(int x, int y, std::vector<TileIndex>& m_MoveblePosition)
{
	int CheckX = x;
	int CheckY = y;

	while (CheckX < 7 && CheckY < 7)
	{
		++CheckX;
		++CheckY;
		if (MoveRectSave(CheckX, CheckY, m_MoveblePosition) == false)
			break;

	}

	CheckX = x;
	CheckY = y;

	while (CheckX > 0 && CheckY < 7)
	{
		--CheckX;
		++CheckY;
		if (MoveRectSave(CheckX, CheckY, m_MoveblePosition) == false)
			break;

	}

	CheckX = x;
	CheckY = y;

	while (CheckX < 7 && CheckY > 0)
	{
		++CheckX;
		--CheckY;
		if (MoveRectSave(CheckX, CheckY, m_MoveblePosition) == false)
			break;
	}

	CheckX = x;
	CheckY = y;

	while (CheckX > 0 && CheckY > 0)
	{
		--CheckX;
		--CheckY;
		if (MoveRectSave(CheckX, CheckY, m_MoveblePosition) == false)
			break;
	}

}

bool Queen::MoveRectSave(int x, int y, std::vector<TileIndex>& m_MoveblePosition)
{
	TileCoord* Tile = GameBoardMgr->Get_Tile(x, y);
	if (Tile->piece != NULL)
	{
		if (Tile->piece->Get_Color() != m_color)
			m_MoveblePosition.push_back({ x, y });
		return false;
	}
	else
		m_MoveblePosition.push_back({ x, y });
	return true;
}