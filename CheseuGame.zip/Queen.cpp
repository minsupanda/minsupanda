#include "Queen.h"

Queen::Queen()
{
}

Queen::~Queen()
{
}

void Queen::MoveCheck()
{
}
