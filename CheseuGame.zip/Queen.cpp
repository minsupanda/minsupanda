#include "Queen.h"

Queen::Queen(PieceColor color)
{
	m_piece = PieceType::Queen;
	m_color = color;
	m_pieceImage = BitmapMgr->Get_Image((int)PieceType::Queen + (int)color);
}

Queen::~Queen()
{
}

void Queen::MoveCheck(std::vector<RECT>& m_MoveblePosition)
{
}
