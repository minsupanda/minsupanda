#include "Queen.h"

Queen::Queen() {}
Queen::Queen(PieceColor color)
{
	m_piece = PieceType::Queen;
	m_pieceImage = BitmapMgr->Get_Image((int)PieceType::Queen + (int)color);
}

Queen::~Queen()
{
}

void Queen::MoveCheck()
{
}
