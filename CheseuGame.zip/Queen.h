#pragma once
#include "Piece.h"

class Queen : public Piece
{
private:

public:
	Queen(PieceColor color);
	~Queen();

	virtual void MoveCheck(std::vector<TileIndex>& m_MoveblePosition) override;
	void WidthLineCheck(int x, int y, std::vector<TileIndex>& m_MoveblePosition);
	void HeightLineCheck(int x, int y, std::vector<TileIndex>& m_MoveblePosition);
	void DiagonalLineCheck(int x, int y, std::vector<TileIndex>& m_MoveblePosition);
	bool MoveRectSave(int x, int y, std::vector<TileIndex>& m_MoveblePosition);

};

