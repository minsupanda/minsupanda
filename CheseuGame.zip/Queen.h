#pragma once
#include "Piece.h"

class Queen : public Piece
{
private:

public:
	Queen();
	~Queen();

	virtual void MoveCheck() override;
};

