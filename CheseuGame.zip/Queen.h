#pragma once
#include "Piece.h"

class Queen : public Piece
{
private:

public:
	Queen();
	Queen(PieceColor color);
	~Queen();

	virtual void MoveCheck() override;
};

