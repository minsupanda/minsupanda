#include "King.h"

King::King()
{
}

King::~King()
{
}

void King::MoveCheck()
{
}
