#include "King.h"
#include "GameBoardManager.h"

King::King(PieceColor color)
{
	m_piece = PieceType::King;
	m_color = color;
	m_pieceImage = BitmapMgr->Get_Image((int)PieceType::King + (int)color);
}

King::~King()
{
}

void King::MoveCheck(std::vector<TileIndex>& m_MoveblePosition)
{
	m_MoveblePosition.clear(); // Ȥ�� �� ������ �����ϱ� ���� clear

	int x = GetCX();
	int y = GetCY();

	int CheckX = x;
	int CheckY = y + 1;
	if (CheckY >= 0 && CheckY <= 8)
		MoveRectSave(CheckX, CheckY, m_MoveblePosition);

	CheckY = y - 1;
	if (CheckY >= 0 && CheckY <= 8)
		MoveRectSave(CheckX, CheckY, m_MoveblePosition);

	CheckX = x + 1;
	CheckY = y;

	if (CheckX >= 0 && CheckX < 8)
		MoveRectSave(CheckX, CheckY, m_MoveblePosition);

	CheckX = x + 1;
	CheckY = y;

	if (CheckX >= 0 && CheckX < 8)
		MoveRectSave(CheckX, CheckY, m_MoveblePosition);

	CheckX = x + 1;
	CheckY = y + 1;

	if (CheckX >= 0 && CheckX < 8 && CheckY >= 0 && CheckY <= 8)
		MoveRectSave(CheckX, CheckY, m_MoveblePosition);

	CheckX = x + 1;
	CheckY = y - 1;

	if (CheckX >= 0 && CheckX < 8 && CheckY >= 0 && CheckY <= 8)
		MoveRectSave(CheckX, CheckY, m_MoveblePosition);
	
	 CheckX = x - 1;
	 CheckY = y + 1;

	if (CheckX >= 0 && CheckX < 8 && CheckY >= 0 && CheckY <= 8)
		MoveRectSave(CheckX, CheckY, m_MoveblePosition);

	CheckX = x - 1;
	CheckY = y - 1;

	if (CheckX >= 0 && CheckX < 8 && CheckY >= 0 && CheckY <= 8)
		MoveRectSave(CheckX, CheckY, m_MoveblePosition);



}

void King::MoveRectSave(int x, int y, std::vector<TileIndex>& m_MoveblePosition)
{
	TileCoord* Tile = GameBoardMgr->Get_Tile(x, y);
	if (Tile->piece != NULL)
	{
		if (Tile->piece->Get_Color() != m_color)
			m_MoveblePosition.push_back({ x, y });
	}
	else
		m_MoveblePosition.push_back({ x, y });
}
