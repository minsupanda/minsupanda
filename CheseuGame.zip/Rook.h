#pragma once
#include "Piece.h"

class Rook : public Piece
{
private:

public:
	Rook();
	Rook(PieceColor color);
	~Rook();

	virtual void MoveCheck() override;
};

