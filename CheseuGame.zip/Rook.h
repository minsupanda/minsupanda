#pragma once
#include "Piece.h"

class Rook : public Piece
{
private:

public:
	Rook();
	~Rook();

	virtual void MoveCheck() override;
};

