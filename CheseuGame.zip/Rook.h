#pragma once
#include "Piece.h"

class Rook : public Piece
{
private:

public:
	Rook(PieceColor color);
	~Rook();

	virtual void MoveCheck(std::vector<RECT>& m_MoveblePosition) override;

};

