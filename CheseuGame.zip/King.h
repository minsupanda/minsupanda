#pragma once
#include "Piece.h"

class King : public Piece
{
private:

public:
	King();
	~King();

	virtual void MoveCheck() override;
};

