#pragma once
#include "Piece.h"

class King : public Piece
{
private:

public:
	King(PieceColor color);
	~King();

	virtual void MoveCheck(std::vector<TileIndex>& m_MoveblePosition) override;
	void MoveRectSave(int x, int y, std::vector<TileIndex>& m_MoveblePosition);
};

