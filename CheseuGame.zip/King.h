#pragma once
#include "Piece.h"

class King : public Piece
{
private:

public:
	King();
	King(PieceColor color);
	~King();

	virtual void MoveCheck(std::vector<RECT>& m_MoveblePosition) override;
};

