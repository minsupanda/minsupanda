#include "Bishop.h"

Bishop::Bishop() {}
Bishop::Bishop(PieceColor color)
{
	m_piece = PieceType::Bishop;
	m_color = color;
	m_pieceImage = BitmapMgr->Get_Image((int)PieceType::Bishop + (int)color);
}

Bishop::~Bishop()
{
}

void Bishop::MoveCheck(std::vector<RECT>& m_MoveblePosition)
{
}
