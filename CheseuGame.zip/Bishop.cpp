#include "Bishop.h"

Bishop::Bishop()
{
}

Bishop::~Bishop()
{
}

void Bishop::MoveCheck()
{
}
