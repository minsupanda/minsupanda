#include "Bishop.h"
#include "GameBoardManager.h"

Bishop::Bishop(PieceColor color)
{
	m_piece = PieceType::Bishop;
	m_color = color;
	m_pieceImage = BitmapMgr->Get_Image((int)PieceType::Bishop + (int)color);
}

Bishop::~Bishop()
{
}

void Bishop::MoveCheck(std::vector<TileIndex>& m_MoveblePosition)
{
	m_MoveblePosition.clear(); // Ȥ�� �� ������ �����ϱ� ���� clear

	int x = GetCX();
	int y = GetCY();

	DiagonalLineCheck(x, y, m_MoveblePosition);
}

void Bishop::DiagonalLineCheck(int x, int y, std::vector<TileIndex>& m_MoveblePosition)
{
	int CheckX = x;
	int CheckY = y;

	while (CheckX < 7 && CheckY < 7)
	{
		++CheckX;
		++CheckY;
		if (MoveRectSave(CheckX, CheckY, m_MoveblePosition) == false)
			break;

	}

	CheckX = x;
	CheckY = y;

	while (CheckX > 0 && CheckY < 7)
	{
		--CheckX;
		++CheckY;
		if (MoveRectSave(CheckX, CheckY, m_MoveblePosition) == false)
			break;

	}

	CheckX = x;
	CheckY = y;

	while (CheckX < 7 && CheckY > 0)
	{
		++CheckX;
		--CheckY;
		if (MoveRectSave(CheckX, CheckY, m_MoveblePosition) == false)
			break;
	}

	CheckX = x;
	CheckY = y;

	while (CheckX > 0 && CheckY > 0)
	{
		--CheckX;
		--CheckY;
		if (MoveRectSave(CheckX, CheckY, m_MoveblePosition) == false)
			break;
	}

}

bool Bishop::MoveRectSave(int x, int y, std::vector<TileIndex>& m_MoveblePosition)
{
	TileCoord* Tile = GameBoardMgr->Get_Tile(x, y);
	if (Tile->piece != NULL)
	{
		if (Tile->piece->Get_Color() != m_color)
			m_MoveblePosition.push_back({ x, y });
		return false;
	}
	else
		m_MoveblePosition.push_back({ x, y });
	return true;
}
