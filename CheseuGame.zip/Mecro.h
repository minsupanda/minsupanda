#pragma once

#include<iostream>
#include<string>
#include<Windows.h>

enum SystemDate
{
	Window_X_COORD = 700,
	Window_Y_COORD = 160,
	Window_Width = 500,
	Window_Height = 500,
};