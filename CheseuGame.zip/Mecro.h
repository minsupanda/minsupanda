#pragma once

#include<iostream>
#include<string>
#include<Windows.h>
#include<vector>

enum SystemDate
{
	Window_X_COORD = 700,
	Window_Y_COORD = 160,
	Window_Width = 640,
	Window_Height = 640,
};

enum PieceColor
{
	BLACK,
	WHITE
};

enum class Scene
{
	PieceChoiceScene,
	PieceMoveScene
};

struct TileIndex
{
	int m_ix;
	int m_iy;
};