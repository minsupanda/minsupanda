#pragma once

#include<iostream>
#include<string>
#include<Windows.h>
#include<vector>

enum SystemDate
{
	Window_X_COORD = 700,
	Window_Y_COORD = 160,
	Window_Width = 640,
	Window_Height = 640,

	Start_Menu_X = (int)(Window_Width * 0.5f),
	Start_Menu_Y = (int)(Window_Height * 0.35f),
	End_Menu_X = (int)(Window_Width * 0.5f),
	End_Menu_Y = (int)(Window_Height * 0.5f),
};

enum PieceColor
{
	BLACK,
	WHITE
};

enum class Scene
{
	MainMenu,
	PieceChoiceScene,
	PieceMoveScene,
	PieceChangeScene,
	GameEnd
};

struct TileIndex
{
	int m_ix;
	int m_iy;
};

