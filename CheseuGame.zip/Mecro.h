#pragma once

#include<iostream>
#include<string>
#include<Windows.h>
#include<vector>

enum SystemDate
{
	Window_X_COORD = 700,
	Window_Y_COORD = 160,
	Window_Width = 640,
	Window_Height = 640,

	Start_Menu_X = (int)(Window_Width * 0.4f),
	Start_Menu_Y = (int)(Window_Height * 0.5f),
	End_Menu_X = (int)(Window_Width * 0.5f),
	End_Menu_Y = (int)(Window_Height * 0.5f),

	Butten_Between_Space = 10
};

enum PieceColor
{
	BLACK,
	WHITE
};

enum class Scene
{
	MainMenu,
	PieceChoiceScene,
	PieceMoveScene,
	PieceChangeScene,
	GameEnd
};

struct TileIndex
{
	int m_ix;
	int m_iy;
};

