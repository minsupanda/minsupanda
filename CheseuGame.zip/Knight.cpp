#include "Knight.h"

Knight::Knight()
{
}

Knight::~Knight()
{
}

void Knight::MoveCheck()
{
}
