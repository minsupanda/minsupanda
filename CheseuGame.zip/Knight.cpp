#include "Knight.h"

Knight::Knight() {}
Knight::Knight(PieceColor color)
{
	m_piece = PieceType::Knight;
	m_pieceImage = BitmapMgr->Get_Image((int)PieceType::Knight + (int)color);
}

Knight::~Knight()
{
}

void Knight::MoveCheck()
{
}
