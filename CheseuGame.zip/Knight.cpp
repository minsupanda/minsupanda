#include "Knight.h"

Knight::Knight(PieceColor color)
{
	m_piece = PieceType::Knight;
	m_color = color;
	m_pieceImage = BitmapMgr->Get_Image((int)PieceType::Knight + (int)color);
}

Knight::~Knight()
{
}

void Knight::MoveCheck(std::vector<RECT>& m_MoveblePosition)
{
	m_MoveblePosition.clear(); // Ȥ�� �� ������ �����ϱ� ���� clear
	RECT MovelbePosition;
	switch (m_color)
	{
	case BLACK:

		break;

	case WHITE:

		break;
	}
}
