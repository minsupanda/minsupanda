#pragma once
#include"Mecro.h"

class Bitmap
{
private:
	HDC MemDC;
	HBITMAP m_Bitmap;
	SIZE m_Size;

public:
	void Init(HDC hdc, const char* FileName);
	void Draw(HDC hdc, int x, int y, int width, int height);
	Bitmap();
	~Bitmap();
};

