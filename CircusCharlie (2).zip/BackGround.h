#pragma once
#include"Mecro.h"
#include"BitmapManager.h"

#define BACKGROUND_IAMGE_NUMBER 15

enum BackGroundImage
{
	Ground,
	Dark_Audience,
	light_Audience,
	Elephant,

	ImageEnd
};

class BackGround
{
private:
	Bitmap* m_BackGorundImage[BackGroundImage::ImageEnd];
	const SIZE* ImageSize[BackGroundImage::ImageEnd];
	int m_BackGroundWidth;
	float m_DrawBaseX;
	
	bool m_MoveDraw;

public:
	BackGround();
	~BackGround();

	void Init();
	void Update(const float CurMoveDistance);
	void Update(const float& ToalDistance, const float& CurMoveDistance);
	void Draw(HDC& m_backDC, float& DrawBaseY);
	inline void MoveDrawOnOff()
	{ 
		if (m_MoveDraw == true) m_MoveDraw = false;

		else m_MoveDraw = true;
	};

	bool Get_MoveDraw() { return m_MoveDraw; }
};

